#!/usr/bin/env bash
# Quirkle deploy: replace the WAR and restart Tomcat. Deletes any stale exploded
# webapp first (avoids the stale-WAR trap where old classes keep serving).
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
WAR="$HERE/build/quirkle.war"
[ -f "$WAR" ] || { echo "ERROR: $WAR not found. Run ./build.sh first."; exit 1; }

CATALINA_HOME="${CATALINA_HOME:-/opt/tomcat}"
APP="${QUIRKLE_APP_NAME:-quirkle}"

echo "Stopping Tomcat..."
"$CATALINA_HOME/bin/shutdown.sh" 2>/dev/null || true
sleep 3

echo "Removing stale exploded webapp..."
rm -rf "$CATALINA_HOME/webapps/${APP}" "$CATALINA_HOME/webapps/${APP}.war"

echo "Deploying WAR..."
cp "$WAR" "$CATALINA_HOME/webapps/${APP}.war"

echo "Starting Tomcat..."
"$CATALINA_HOME/bin/startup.sh"
echo "Deployed ${APP}.war. Verify: <base>/${APP}/api/health"
