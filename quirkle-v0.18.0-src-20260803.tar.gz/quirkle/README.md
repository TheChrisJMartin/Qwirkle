# Quirkle — v0.18.0 (Menu, About/Help, rejoin, +18 achievements, admin)

**Menu & flow**
- **New game** and **About & help** added to the in-game burger menu; "Online games" is now **My games**.
- **Quit** now asks for confirmation. A logged-in user's standard/progressive (solo) and network games are saved,
  so you can **rejoin** them from **My games** (which now lists in-progress solo *and* network games; finished
  games are no longer shown).
- **About & help** screen: how to play, the bot strategies, and the full achievement list with difficulty pips
  (served from a new public `/api/info`).

**Achievements — now 50** (was 32). New: Hoarder (hold all 3 of a tile), Qwirkle in the Hand (hold a Qwirkle on
your rack), Pacifist (pass 3 in a row), Blitz (a round in under 10s with 2+ humans), Networker / 網 Crusher (win
a network game / by 30+), Sesquicentury (150+), Out in Style (win by going out), Fresh Hand (swap all six),
Triple Threat (3 Qwirkles in a game), On Fire (5 wins in a row), Getting Started / Regular (10 / 25 games), and
progressive **level milestones 5/10/20/50/100**. ("Two Qwirkles in one move" was already **Double Trouble**.)

**Admin**
- New **`/admin`** dashboard: registered users with verified status, registered date, **last login**, games,
  wins, level and best score. Access limited to emails in **`QUIRKLE_ADMIN_EMAILS`** (comma-separated). Login
  now records `last_login`.

Schema: adds `app_user.last_login` (idempotent). New config: `QUIRKLE_ADMIN_EMAILS`. Redeploy the WAR.

---

# Quirkle — v0.17.0 (Scoreboard refinements)

Tightened the floating scoreboard from feedback:
- Much smaller and moved to the **bottom-right**, with tight single-line rows and no "whose go" header — the
  **active player is simply shown in yellow**.
- The **bag count** moved to the **bottom-left** as a small drawstring-pouch icon with the number beside it.

Frontend only. No schema change. Redeploy the WAR.

---

# Quirkle — v0.16.0 (Floating scoreboard + named-bot strategies)

- **Fix:** with 4 players the live scores overflowed the bottom bar and overlapped into an unreadable smear.
  Scores now live in a **compact panel floating over the board** (top-right): whose go it is, tiles left in the
  bag, and every player's score and tiles-in-hand, with the current player highlighted.
- **Named bots now each have a fixed strategy**, and easy/medium/hard field a *mix* of them so the combined
  challenge matches the level:
    - **Tilly** — plays the highest-scoring move.
    - **Lexi** — always plays as many tiles as she can.
    - **Edward** — builds the longest run of one colour or shape.
    - **Freda** — opens the board right up.
    - **Indigo** — keeps the board tight and compact.
    - **Nia** — hunts Qwirkles above all.
    - **Bob** — plays casually (anything legal).
  Easy fields the quirkier/weaker mix (Bob, Lexi, Freda, Indigo); Hard fields the sharp ones (Tilly, Nia, Edward,
  Freda). Every bot still opens with its best line so a starter uses the full line that justified it going first.

No schema change. Redeploy the WAR.

---

# Quirkle — v0.15.0 (Network polish: banner, narration, achievements, smart emails)

Round of fixes and polish for network play, from live testing:

- **Fix:** a Qwirkle by a bot/other player showed "QWIRKLE! You" — now attributed to the actual scorer.
- **See everyone's moves.** In a network game you now get a toast for each other player's move ("Sam +12",
  "Bob QWIRKLE!"), narrated from the event log as it arrives (via WebSocket or the poll below).
- **Persistent turn/score banner** above the rack: whose go it is, tiles left in the bag, and a compact line of
  every player's score and tiles-in-hand — small, so it barely uses screen space. This also means you always
  know it's your go even if you missed the toast.
- **Clearer buttons:** Play pulses **yellow** when it's your turn, **green** when your placement is legal; Reset
  pulses **red** and the offending tile gets a red outline when the move isn't legal.
- **Fix:** human players now earn **achievements** in network games (awarded to every human at game end; the
  progressive level ladder stays solo-only).
- **Smarter turn emails.** Instead of an email every turn, a background notifier emails a player only after a
  period of **inactivity** (default 10 min, `QUIRKLE_TURN_IDLE_MINUTES`), once per turn — so active games are
  quiet and only genuinely idle ones get nudged.
- **Resilience:** the client also polls its game every 60s as a safety net, so a missed WebSocket push can't
  leave a device stuck (it catches up without a manual refresh).

Config: `QUIRKLE_TURN_IDLE_MINUTES` (default 10) and `QUIRKLE_BASE_URL` (for links in turn emails). No schema
change. Redeploy the WAR.

---

# Quirkle — v0.14.0 (Network Phase 2: live WebSocket updates)

Online games now update **live** when everyone's connected, on top of the correspondence core.

- **Live push:** a `@ServerEndpoint("/ws/game/{id}")` groups the players/watchers of a game. When anyone
  moves, swaps or passes (or a seat is claimed), the server broadcasts a tiny `{"type":"update"}` ping and each
  client re-fetches **its own** perspective state over HTTP — so no hand data ever crosses the socket. The same
  game still works purely over HTTP if a client has no socket (correspondence unchanged).
- **Client:** connects when you open an online game, refreshes on each ping, announces "Your move" when the turn
  reaches you, and reconnects automatically if the socket drops. Moves still go over HTTP `POST /api/net/...`.
- **Menu:** online games are now reachable from the **New game** screen (Mode → Online) and the in‑game burger
  menu (**Online games**), as well as the landing.

Deploy notes: needs Tomcat's WebSocket support (same as the CB Radio app) and the reverse proxy to pass the
`Upgrade`/stream through for `/quirkle/ws/*` (mod_jk `JkMount` or `mod_proxy` with no buffering). Build now also
needs the Jakarta WebSocket API on the compile classpath — `build.sh` auto-detects it (override with `WS_API=`).
No schema change. Redeploy the WAR.

*Still later: presence indicators & per-turn timers, spectators, chat, resign/rematch (P3); ranked (P4).*

---

# Quirkle — v0.13.0 (Network multiplayer — Phase 1: correspondence)

First cut of **play against other people**, over hours or days, entirely over HTTP (live WebSockets are Phase 2).

- **Create an online game** ("Play online" on the landing): invite players by email, optionally add bots to fill
  seats (2–4 players total). You can start playing immediately; invitees join whenever.
- **Invites & joining:** each invitee gets an email link (`/quirkle/#join=<token>`); after signing in they claim
  their seat. Deep links `#g=<id>` open a specific game.
- **Correspondence play:** the game is the same event-sourced object as solo. After each human move, bots resolve
  server-side and the next human is emailed "it's your move" (debounced, one per turn). Everyone sees the game
  from **their own seat** (their hand, their turn) — `buildState` is now perspective-aware.
- **My games** list shows each game's opponents, whose turn it is, and your score.

Schema: adds `game.kind`, `game.host_user_id`, `game.notified_seq`, and a `game_invite` table (idempotent).
New endpoints under `/api/net/*`. Solo play is unchanged. Redeploy the WAR.

*Not yet (later phases): live WebSocket updates & presence (P2); spectators, chat, resign/rematch (P3); ranked
ladder (P4); per-player achievements in multiplayer.*

---

# Quirkle — v0.12.1 (Bag-emptier / finisher fix)

See delivery notes. No schema change.

---

# Quirkle — v0.12.0 (Opener plays its full line; achievements highlight)

- **Fix (D14-0005):** the opening player now plays its full opening line. Easy bots played a *random* legal move,
  so a bot that started "because it can play 4 tiles" often opened with 1. Easy bots now play their best line on
  the opening move (mid-game play stays casual/random); medium/hard were already optimal. The starter prompt and
  the actual opening now agree.
- **Achievements earned in the last game are highlighted green** (with a NEW badge) and sorted to the top of the
  Achievements view, so a post-game review makes it obvious what you just unlocked.

No schema change. Redeploy the WAR.

---

# Quirkle — v0.11.1 (Level display fix + replay earlier levels)

- **Fix:** Progressive setup always showed "Level 1" even after clearing levels. The level *was* saved
  correctly server-side, but `/api/user` wasn't including the `level` field in its stats object, so the UI
  fell back to 1. The field is now returned; the setup shows your real level.
- **Replay earlier levels.** The Progressive panel now shows "Your level: N / 100" with a level picker — pick
  any level from 1 up to your current one to play (you can't skip ahead). Replaying an earlier level won't
  change your level. New `GET /api/levels` endpoint feeds the picker with every level's objective.

No schema change. Redeploy the WAR (and, if any earlier stats look off, note the level column already exists
from v0.11.0's migration).

---

# Quirkle — v0.11.0 (Quirkle Levels, achievements fixes)

- **Quirkle Levels — progressive mode.** A 100-level ladder: each game must meet the level's objective to
  advance (L1 win a game … L100 win having played 10 Qwirkles). Bots scale Easy→Medium→Hard with the level.
  Two modes now: **Progressive** (climb the ladder, requires login so your level is saved) and **Free play**
  (casual). Achievements are earnable in **both**. Full ladder in the accompanying levels doc.
- **Achievements bug fixed.** The achievements list could vanish while you read it — an async race where the
  Stats "This game" fetch resolved late and overwrote the "You" tab. Fixed with a tab-token guard.
- **Achievements moved to their own burger item** with a dedicated view, and the game-over screen now offers
  **View achievements** when you unlocked some that game.
- **Performance:** the per-move analytics replay is gated off the hot path (the expensive missed-Qwirkle
  enumeration now only runs for stats/finalisation), making moves noticeably snappier.

Schema: adds `user_stats.level`, `game.mode`, `game.level` (idempotent). Redeploy the WAR.

---

# Quirkle — v0.10.0 (Starting player, Qwirkle fanfare, game-over screen)

- **Starting player is now decided by the Qwirkle rule** — whoever can open the longest line goes first. A
  prompt announces it: "<name> starts — can play N tiles" (ties break to the lowest seat). The choice is
  deterministic from the deal, so it survives reload and replays correctly.
- **Qwirkle fanfare.** Every Qwirkle (by anyone) pops a standout toast: "QWIRKLE!" with each letter in one of
  the six tile colours, on a dark panel with a gold glow, plus the scorer's name and a ×N when more than one.
- **Game-over screen.** When the game ends, a prompt shows the final scores and calls out the winner (or a
  tie). You can start a **New game** or **Dismiss** it to inspect the finished board.
- **Reset no longer sticks.** Reset was being left disabled after a submit (it was swept up with Play/Swap and
  never re-enabled). Reset is now always enabled and re-enabled on every render.

No schema changes — the starting player is derived from the deal, so just redeploy the WAR.

---

# Quirkle — v0.9.1 (Hotfix: tiles wouldn't drop)

**Fixes a showstopper introduced by the pan/zoom pointer handling:** on the board, the viewport captures the
pointer (`setPointerCapture`) for pan/pinch. Browsers have tightened how a captured pointer dispatches the
follow-up `click`, so the child "slot" element's click — which placement relied on — stopped firing. Tapping a
board cell no longer dropped a tile.

Fix: placement now happens from the pointer-**up** hit-test (`elementFromPoint` → nearest `.slot`), independent
of the native click and of pointer capture. The slot's `onclick` is kept as a fallback, and `placeAt` now
de-duplicates so the two paths can't double-place. The drag threshold was also relaxed (6→10px) so small finger
jitter on a tap isn't mistaken for a pan.

No backend or schema changes — redeploy the WAR.

---

# Quirkle — v0.9.0 (Turn toasts, snappier Play & random bot names)

- **Play/Swap no longer feel sticky.** A submit is guarded against double-taps: the bar disables the instant
  you tap, the move is validated client-side before sending, and a second tap during the round-trip is ignored
  — so you won't get the "you've already taken your turn" message from an accidental double press.
- **Close (×) on every pop-up.** Stats, Scores and the Game Log all show a working × top-right.
- **Removed** the "double-tap to centre" hint.
- **Whose-turn is now a toast**, not a fixed pill. "Your move" and "<Bot> is thinking…" appear as toasts, and
  the toaster **queues messages** so two in quick succession play one after the other instead of clobbering.
- **The bot who is thinking / moving is named** (e.g. "Indigo is thinking…", "Edward +12").
- **Bot names are randomised each game** from Lexi, Tilly, Bob, Indigo and Edward — so Edward now turns up
  regularly (~70% of 3-bot games).

No schema changes — just redeploy the WAR.

---

# Quirkle — v0.8.0 (Login screen, password reset & burger menu)

- **Dedicated login screen on load.** You now land on a Quirkle sign-in screen — log in, reset your password,
  or continue as a guest — *before* the New Game / setup screen. Logged-in players get a "View my stats"
  button right there.
- **Password recovery over SMTP.** "Forgot password?" emails a one-hour reset link using the app's existing
  STARTTLS mailer; the link opens a set-new-password screen. Requests never reveal whether an email is
  registered, and reset tokens are single-use and expire.
- **Burger menu in-game.** A ☰ menu top-left now holds Game Log, Scores, Stats and Quit. The bottom bar is
  trimmed to Play / Swap / Reset.
- **Achievement timestamps.** Each achievement now records when it was earned and shows "Unlocked <date>" in
  the You tab.
- **New achievement — Flawless Victory:** win a game without missing a single Qwirkle.

Schema: adds `password_reset` (idempotent). Password reset emails use the same `SMTP_*` env vars as the rest
of the app; if SMTP isn't configured, "Forgot password?" returns a clear error rather than failing silently.

---

# Quirkle — v0.7.0 (Accounts, achievements & bot personalities)

Headline additions:
- **Accounts + guest play.** Register / log in on the New Game screen (PBKDF2-hashed passwords, 30-day
  session cookie), or keep playing as a guest. Only logged-in games are tracked.
- **User stats ("You" tab).** A second tab on the Stats screen collects lifetime figures for the signed-in
  player: games, wins, win %, current & best streak, best game, best move, tiles, Qwirkles, missed Qwirkles.
- **Achievements (Xbox-style).** 31 achievements, 28 currently earnable, each with a 1–5 difficulty rating and
  shown as a locked/unlocked grid with difficulty pips. Unlocks pop up as toasts when earned.
- **Named bots with personalities.** Bots are now Lexi, Tilly, Bob, Indigo and Edward. Each has a personality
  (Sharp / Steady / Casual / Spreader / Wily) tuning difficulty plus two behaviour dials — how often it opens
  the board out, and how often it declines an available Qwirkle. Logged-in players can set each bot's
  personality at the New Game screen.
- **Missed-Qwirkle tracking.** The engine now records when a player could have completed a Qwirkle and didn't;
  shown per-player in the (now tabular) game stats and in your lifetime totals.
- **Toaster fix.** Your move's score toast now stays visible before the bots take their turns.
- **Think time is server-side.** Per-move think time is recorded on the game, so "average think" and the
  think-based achievements are persistent rather than browser-only.

Schema: adds `user_stats`, `user_achievement`, `game.human_think_ms/human_think_moves`, `game.finalized`,
`game_seat.personality` (all idempotent `IF NOT EXISTS` migrations; safe over the existing DB).

---

# Quirkle — v0.6.0 (Play feedback & richer history)

Refinements from play-testing:
- **Play flashes green** when your pending tiles form a legal move; **Reset flashes red** when they don't
  (client-side validator, verified to match the engine's scoring exactly).
- **Recent moves outlined on the board** — the last move in white, the one before in light grey, and the one
  before that in dark grey, so you can see what was just played.
- **Move log** now opens with **GAME STARTED**, shows **whose turn is next** at the top ("Waiting for Chris …"),
  and each row shows the tiles played (mini symbols), the **points scored**, and a **QWIRKLE** badge when earned.
- **Scores** gained a **Qwirkles** figure per player plus a total.
- **Stats** expanded: tiles in bag, total Qwirkles, highest score, **your average think time**, opens/closes
  leaders, and a per-player breakdown (moves, average points/move, best move, tiles placed, Qwirkles, opens/closes).

No schema changes; the stats/log figures are derived by replaying the event log.

---

# Quirkle — v0.5.0 (Mobile-first play)

Reworked for phones and added session information:
- **Full-screen board** with pan and pinch/wheel zoom; double-tap to recentre. The board is the whole
  screen above a **fixed bottom bar** holding the six-tile rack and the buttons Play, Swap, Reset, Scores,
  Stats, Log, Quit. Quit returns to the new-game prompt.
- **Paced bots** — after your turn each AI takes ~2s, announced by a top toaster that shows the tiles it
  played (mini symbols) and the points scored, then fades.
- **Scores** — every player, the combined score, and tiles left in the bag.
- **Stats** (session) — tiles in bag, total Qwirkles, highest score, and who opens vs closes the board most,
  plus a per-player breakdown. (Opens = moves that expand the board's area; closes = moves that fill within it.)
- **Log** — a blurred pop-up listing what each player played, as mini tile symbols.
- Forced pass handled automatically when you have no move and the bag is empty.

API additions: `GET /api/game/{id}/stats`, `POST /api/game/{id}/pass`; `advance` now plays exactly one AI
seat so the client can pace them; state carries the event log and `youHaveMove`.

---

# Quirkle — v0.4.0 (Playable web client — MVP)

The MVP is here: create a game and play it in the browser against the bots.

- **F14-0050 Game API** — `service.GameService` (HTTP-independent, so it is tested directly) plus a thin
  `web.GameApiServlet`. `POST /api/game` (create), `GET /api/game/{id}` (state, opponents' hands hidden),
  `POST /api/game/{id}/move|swap|advance`. After a human action the service runs the AI seats through to
  the human's next turn. Verified end-to-end against PostgreSQL: create -> human moves + AI advance -> finish,
  with turn ownership and illegal moves rejected (400).
- **F14-0051 Board & rack rendering** — dependency-free SPA (`index.html`); tiles are SVG glyphs on glossy
  black over a felt table; the board grows as tiles are laid.
- **F14-0052 Tile placement** — pick a rack tile, tap an empty slot; only slots that keep your placed tiles
  in one line are offered. The server remains authoritative and surfaces any rejection.
- **F14-0053 Turn actions & feedback** — Play / Swap, a points toast, per-seat scores, and a move log that
  includes the bots' narration.
- **F14-0054 New-game setup** — choose 1-3 opponents and difficulty; you play first. This is the home screen.

Play locally: put the JDBC driver in Tomcat's lib/, set the DB vars in setenv.sh, deploy, then open the app
and start a game. Note: the SPA was syntax-checked and its tile art rendered here, but full browser click-through
is to be confirmed on your server.

---

# Quirkle — v0.3.0 (AI opponents)

New in this build (Phase C):
- **F14-0043 AI framework & legal-move enumeration** — `ai.LegalMoves` enumerates every legal move
  (opening subsets, and mid-game via per-axis window scanning with per-cell tile pruning). Verified
  complete against brute force for all 1- and 2-tile moves; every enumerated move validates.
- **F14-0044 Greedy baseline** — `HeuristicAi` (medium) always plays the highest-scoring legal move,
  swapping or passing when stuck. Deterministic given the game seed.
- **F14-0045 Difficulty tiers** — easy (random legal move), medium (greedy), hard (greedy with a
  defensive penalty for leaving a line of five open). Over 20 games, medium beat easy 20-0.
- `ai.AiTurns` drives AI seats (`playOne`, `playUntilHumanOrEnd`) with short narration lines — the
  hook the future game feed (F14-0046) and the /advance endpoint will use.

Run the AI tests:
```
javac --release 17 -d build/ai-test \
  $(find src/uk/co/donotpassgo/quirkle/{engine,ai} -name '*.java') test/uk/co/donotpassgo/quirkle/ai/AiTest.java
java -cp build/ai-test uk.co.donotpassgo.quirkle.ai.AiTest
```

---

# Quirkle — v0.2.0 (Game persistence & mail transport)

New in this build:
- **F14-0042 Game persistence** — `GameStore` saves games to PostgreSQL and resumes them by
  replaying the event log over the seeded bag (exact reconstruction). Supports create, incremental
  append, load/resume and list. Verified with a live round-trip against PostgreSQL 16.
- **Event log** in the engine (`GameEvent`/`EventCodec`/`GameReplay`) — the source of truth for resume.
- **SMTP mailer** — dependency-free `Mailer` (STARTTLS/implicit TLS/plain, AUTH LOGIN) reading the
  bare `SMTP_*` variables. Run `uk.co.donotpassgo.quirkle.tools.MailTest <recipient>` on the server to
  verify delivery. This is the transport the later email-verification feature (F14-0048) will use.
- Schema additions applied idempotently on boot: `game_seat.name`, `game_event.detail`.

Run the store round-trip test (needs a reachable DB and the JDBC driver on the classpath):
```
javac --release 17 -cp /path/to/postgresql.jar -d build/store-test \
  $(find src/uk/co/donotpassgo/quirkle/{engine,store,config} -name '*.java') \
  src/uk/co/donotpassgo/quirkle/Version.java test/uk/co/donotpassgo/quirkle/store/StoreTest.java
QUIRKLE_DB_URL=... QUIRKLE_DB_USER=... QUIRKLE_DB_PASS=... \
  java -cp build/store-test:/path/to/postgresql.jar uk.co.donotpassgo.quirkle.store.StoreTest
```

---

# Quirkle — v0.1.0 (Foundation & game engine)

A JVM (Jakarta servlet WAR + PostgreSQL 16) reimplementation of the tile-laying game Qwirkle.
ReqSuite epic **E014**. This release delivers the deployable platform shell and the complete,
unit-tested core game engine. No web client yet — that arrives in Phase E.

## What's in this release
**Phase A — Platform foundation**
- `F14-0032` WAR skeleton & build pipeline (`javac`/`jar`, no Maven), health-check servlet.
- `F14-0033` Configuration via `setenv.sh` environment variables.
- `F14-0034` PostgreSQL schema & idempotent boot migrations (`schema_version` ledger).

**Phase B — Core game engine (headless, deterministic, unit-tested)**
- `F14-0035` Tile & bag model (108 tiles = 6 colours x 6 shapes x 3; seeded shuffle).
- `F14-0036` Sparse unbounded board.
- `F14-0037` Move validation (single line, contiguity, connection, colour/shape rules, no duplicates, max 6).
- `F14-0038` Scoring (per-tile line scoring, intersection double-count, +6 Qwirkle bonus).
- `F14-0039` Turn & game-state lifecycle (place, refill, advance).
- `F14-0040` Swap/exchange action.
- `F14-0041` End-of-game detection & final scoring (+6 last-tile bonus, stalemate).

## Layout
```
src/  uk/co/donotpassgo/quirkle/{engine,web,config,store}  Java sources
web/  index.html, WEB-INF/web.xml                          static + descriptor
test/ EngineTests.java                                     assertion harness (not shipped in the WAR)
build.sh / deploy.sh (+ .txt twins)                        build & deploy
setenv.sh.example                                          configuration template
```

## Build
```
./build.sh                 # auto-detects the Jakarta Servlet API, or:
SERVLET_API=/path/to/jakarta.servlet-api.jar ./build.sh
```
Produces `build/quirkle.war`. Requires JDK 17+ (built and tested here on JDK 21, `--release 17`).

## Run the engine tests
```
javac --release 17 -d build/test-classes $(find src/uk/co/donotpassgo/quirkle/engine test -name '*.java') src/uk/co/donotpassgo/quirkle/Version.java
java -cp build/test-classes uk.co.donotpassgo.quirkle.engine.EngineTests
```
All checks pass, including a full self-playing game that holds the 108-tile invariant every turn.

## Deploy
1. Put the PostgreSQL JDBC driver in `$CATALINA_HOME/lib/`.
2. Copy `setenv.sh.example` to `$CATALINA_HOME/bin/setenv.sh` and set the DB credentials.
3. Create the database/role, then `./deploy.sh` (deletes any stale exploded webapp first).
4. Verify `<base>/quirkle/api/health` returns `{"status":"ok","version":"0.1.0","db":true,...}`.

## Notes
- The engine has **zero external dependencies** and is fully deterministic given a seed.
- The Servlet API is compile-only; the JDBC driver lives in Tomcat's `lib/`, never in the WAR.
- Migrations are idempotent (`IF NOT EXISTS` + ledger) and re-running boot is a no-op.
- Deferred to the next build: `F14-0042` game persistence (DAO to store/resume games), then Phase C AI.
