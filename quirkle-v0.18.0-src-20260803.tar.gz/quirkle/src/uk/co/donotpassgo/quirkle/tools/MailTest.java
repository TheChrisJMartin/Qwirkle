package uk.co.donotpassgo.quirkle.tools;

import uk.co.donotpassgo.quirkle.config.Config;
import uk.co.donotpassgo.quirkle.mail.Mailer;

/**
 * Command-line SMTP check. Run on the server with the same environment as Tomcat:
 *   java -cp "WEB-INF/classes" uk.co.donotpassgo.quirkle.tools.MailTest you@example.com
 * No HTTP surface, so it is safe to leave in the build.
 */
public final class MailTest {
    public static void main(String[] args) throws Exception {
        if (args.length < 1) { System.err.println("usage: MailTest <recipient>"); System.exit(2); }
        String to = args[0];
        System.out.println("SMTP " + Config.smtpHost() + ":" + Config.smtpPort()
                + " (" + Config.smtpTls() + ") as " + Config.smtpUser() + " -> " + to);
        Mailer.send(to, "Quirkle SMTP test", "This is a test message from the Quirkle mail configuration.");
        System.out.println("Sent OK.");
    }
}
