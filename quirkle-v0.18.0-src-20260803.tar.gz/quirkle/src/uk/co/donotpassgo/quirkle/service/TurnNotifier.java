package uk.co.donotpassgo.quirkle.service;

import uk.co.donotpassgo.quirkle.mail.Mailer;
import uk.co.donotpassgo.quirkle.store.Db;

import java.sql.*;
import java.util.concurrent.*;

/**
 * Background nudge for correspondence games: once a minute, find games where it's a human's turn and
 * nothing has happened for a while, and email that player exactly once per turn. This replaces the old
 * "email on every turn" behaviour — an actively-playing pair gets no email; only genuine inactivity does.
 */
public final class TurnNotifier {
    private static final long IDLE_MINUTES = Long.parseLong(System.getenv().getOrDefault("QUIRKLE_TURN_IDLE_MINUTES", "10"));
    private static final String BASE = System.getenv().getOrDefault("QUIRKLE_BASE_URL", "https://games.donotpassgo.co.uk/quirkle/");
    private static ScheduledExecutorService exec;
    private TurnNotifier() {}

    public static synchronized void start() {
        if (exec != null) return;
        exec = Executors.newSingleThreadScheduledExecutor(r -> { Thread t = new Thread(r, "quirkle-turn-notifier"); t.setDaemon(true); return t; });
        exec.scheduleWithFixedDelay(TurnNotifier::sweep, 60, 60, TimeUnit.SECONDS);
    }
    public static synchronized void stop() { if (exec != null) { exec.shutdownNow(); exec = null; } }

    public static void sweep() {
        String sql =
            "SELECT g.id, g.notified_seq, u.email, " +
            "  (SELECT COUNT(*) FROM game_event e WHERE e.game_id = g.id) AS evc " +
            "FROM game g " +
            "JOIN game_seat gs ON gs.game_id = g.id AND gs.seat_index = g.current_seat " +
            "JOIN app_user u ON u.id = gs.user_id " +
            "WHERE g.kind = 'CORRESPONDENCE' AND g.status = 'IN_PROGRESS' " +
            "  AND gs.user_id IS NOT NULL AND u.email IS NOT NULL " +
            "  AND g.updated_at < now() - (? * interval '1 minute')";
        try (Connection c = Db.connection()) {
            java.util.List<long[]> toMark = new java.util.ArrayList<>();
            java.util.List<String[]> mails = new java.util.ArrayList<>();
            try (PreparedStatement ps = c.prepareStatement(sql)) {
                ps.setLong(1, IDLE_MINUTES);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        long id = rs.getLong(1); int notified = rs.getInt(2); String email = rs.getString(3); int evc = rs.getInt(4);
                        if (notified >= evc) continue;               // already nudged for this turn
                        mails.add(new String[]{email, String.valueOf(id)});
                        toMark.add(new long[]{id, evc});
                    }
                }
            }
            for (String[] m : mails) {
                String body = "It's your move in your Quirkle game.\n\nOpen it: " + BASE + "#g=" + m[1] + "\n\n— Quirkle";
                try { Mailer.send(m[0], "Your move in Quirkle", body); } catch (Exception ignored) {}
            }
            try (PreparedStatement ps = c.prepareStatement("UPDATE game SET notified_seq=? WHERE id=?")) {
                for (long[] mk : toMark) { ps.setInt(1, (int) mk[1]); ps.setLong(2, mk[0]); ps.addBatch(); }
                ps.executeBatch();
            }
        } catch (SQLException ignored) {}
    }
}
