package uk.co.donotpassgo.quirkle.service;

import java.util.List;

/** What a single AI (or forced human pass) step did, for the toaster. */
public record StepInfo(int seat, String name, String kind, List<String> tiles, int points) {}
