package uk.co.donotpassgo.quirkle.service;

import uk.co.donotpassgo.quirkle.engine.*;
import uk.co.donotpassgo.quirkle.store.Db;
import java.sql.*;
import java.util.*;

/** Aggregate user stats and achievement unlocking at game end. */
public final class UserService {
    private UserService() {}

    /** If the game just ended and the human is logged in, record stats and unlock achievements (once). */
    public static List<Achievements.Def> finishGameIfEnded(GameState g) {
        if (g.status != GameStatus.FINISHED) return List.of();
        int human = humanSeat(g);
        if (human < 0 || g.seats.get(human).userId == null) return List.of();
        long uid = g.seats.get(human).userId;
        try (Connection c = Db.connection()) {
            c.setAutoCommit(false);
            if (!claim(c, g.id)) { c.rollback(); return List.of(); }
            Analytics a = Analytics.compute(g);
            List<Achievements.Def> newly = finalizeSeat(c, g, a, human, uid, true, false);
            c.commit();
            return newly;
        } catch (SQLException e) { return List.of(); }
    }

    /** Network games: award stats + achievements to every human seat (no progressive level). Returns the acting player's new unlocks. */
    public static List<Achievements.Def> finalizeNetworkGame(GameState g, Long actingUserId) {
        if (g.status != GameStatus.FINISHED) return List.of();
        try (Connection c = Db.connection()) {
            c.setAutoCommit(false);
            if (!claim(c, g.id)) { c.rollback(); return List.of(); }
            Analytics a = Analytics.compute(g);
            int humans = 0; for (Seat s : g.seats) if (!s.ai && s.userId != null) humans++;
            boolean blitz = humans >= 2 && fastestRoundMs(c, g.id, g.seats.size()) < 10_000L;
            List<Achievements.Def> actorNewly = new ArrayList<>();
            for (int i = 0; i < g.seats.size(); i++) {
                Long uid = g.seats.get(i).userId;
                if (g.seats.get(i).ai || uid == null) continue;
                List<Achievements.Def> newly = finalizeSeat(c, g, a, i, uid, false, blitz);
                if (actingUserId != null && uid.equals(actingUserId)) actorNewly = newly;
            }
            c.commit();
            return actorNewly;
        } catch (SQLException e) { return List.of(); }
    }

    /** Smallest wall-clock span (ms) covering any window of nSeats consecutive events — i.e. the quickest full round. */
    private static long fastestRoundMs(Connection c, long gameId, int nSeats) throws SQLException {
        java.util.List<Long> ts = new java.util.ArrayList<>();
        try (PreparedStatement ps = c.prepareStatement(
                "SELECT created_at FROM game_event WHERE game_id=? ORDER BY seq")) {
            ps.setLong(1, gameId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) { java.sql.Timestamp t = rs.getTimestamp(1); if (t != null) ts.add(t.getTime()); }
            }
        }
        if (ts.size() < nSeats) return Long.MAX_VALUE;
        long best = Long.MAX_VALUE;
        for (int i = 0; i + nSeats - 1 < ts.size(); i++) best = Math.min(best, ts.get(i + nSeats - 1) - ts.get(i));
        return best;
    }

    private static boolean claim(Connection c, long gameId) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("UPDATE game SET finalized=TRUE WHERE id=? AND finalized=FALSE")) {
            ps.setLong(1, gameId); return ps.executeUpdate() > 0;
        }
    }

    /** Update one seat's lifetime stats + achievements from a finished game. allowLevel advances the progressive ladder (solo only). */
    private static List<Achievements.Def> finalizeSeat(Connection c, GameState g, Analytics a, int seat, long uid, boolean allowLevel, boolean blitz) throws SQLException {
        int score = g.seats.get(seat).score;
        int secondBest = Integer.MIN_VALUE;
        boolean allBotsHard = true, edward = false;
        for (int i = 0; i < g.seats.size(); i++) {
            if (i == seat) continue;
            secondBest = Math.max(secondBest, g.seats.get(i).score);
            if (!g.seats.get(i).ai || !"hard".equalsIgnoreCase(g.seats.get(i).aiDifficulty)) allBotsHard = false;
            if ("Edward".equals(g.seats.get(i).name)) edward = true;
        }
        boolean won = score > secondBest;
        long avgThink = (allowLevel && g.humanThinkMoves > 0) ? g.humanThinkMs / g.humanThinkMoves : 0;

        int[] cur = readStats(c, uid);
        int games = cur[0] + 1;
        int wins = cur[1] + (won ? 1 : 0);
        int streak = won ? cur[2] + 1 : 0;
        int bestStreak = Math.max(cur[3], streak);
        int bestScore = Math.max(cur[4], score);
        int bestMove = Math.max(cur[5], a.best[seat]);
        int tiles = cur[6] + a.tilesPlaced[seat];
        int quirkles = cur[7] + a.quirkles[seat];
        int missed = cur[8] + a.missedQwirkles[seat];
        int curLevel = Math.max(1, cur[9]);
        int newLevel = curLevel;
        if (allowLevel && "progressive".equals(g.mode)) {
            boolean met = Levels.meets(g.level, won, score - secondBest, score,
                    a.quirkles[seat], a.best[seat], a.missedQwirkles[seat], a.swaps[seat], a.bagEmptierSeat == seat);
            if (met && g.level == curLevel) newLevel = Math.min(Levels.MAX, curLevel + 1);
        }
        upsertStats(c, uid, games, wins, streak, bestStreak, bestScore, bestMove, tiles, quirkles, missed, newLevel);

        Achievements.Ctx ctx = new Achievements.Ctx(
            won, score, score - secondBest, a.best[seat], a.maxMoveQwirkles[seat],
            a.quirkles[seat], a.missedQwirkles[seat], a.swaps[seat], a.bagEmptierSeat == seat,
            a.leaderOpens() == seat && a.opens[seat] > 0, a.leaderCloses() == seat && a.closes[seat] > 0,
            allBotsHard, edward, avgThink, a.held5Colour[seat], a.held5Shape[seat], a.held6Colour[seat],
            a.held6DiffColour[seat], a.held6DiffShape[seat], a.purpleQwirkle[seat], a.star8Qwirkle[seat],
            games, streak,
            g.kind != null && !"SOLO".equals(g.kind), newLevel, blitz, a.finisherSeat == seat,
            a.held3Same[seat], a.heldQwirkleRack[seat], a.maxConsecPasses[seat], a.maxSwapSize[seat]);

        Set<String> earned = Achievements.earned(ctx);
        Set<String> already = readAchievements(c, uid);
        List<Achievements.Def> newly = new ArrayList<>();
        try (PreparedStatement ps = c.prepareStatement(
                "INSERT INTO user_achievement(user_id, code) VALUES (?,?) ON CONFLICT DO NOTHING")) {
            for (String code : earned) {
                if (already.contains(code)) continue;
                ps.setLong(1, uid); ps.setString(2, code); ps.addBatch();
                Achievements.Def d = Achievements.byCode(code); if (d != null) newly.add(d);
            }
            ps.executeBatch();
        }
        return newly;
    }

    public static String readJson(long uid) throws SQLException {
        try (Connection c = Db.connection()) {
            int[] st = readStats(c, uid);
            java.util.Map<String,String> ach = readAchievementTimes(c, uid);
            int games = st[0], wins = st[1];
            String winRate = games > 0 ? String.valueOf(Math.round(100.0 * wins / games)) : "0";
            StringBuilder b = new StringBuilder("{\"stats\":{");
            b.append("\"games\":").append(st[0]).append(",\"wins\":").append(st[1])
             .append(",\"winRate\":").append(winRate)
             .append(",\"winStreak\":").append(st[2]).append(",\"bestStreak\":").append(st[3])
             .append(",\"bestScore\":").append(st[4]).append(",\"bestMove\":").append(st[5])
             .append(",\"tilesPlaced\":").append(st[6]).append(",\"quirkles\":").append(st[7])
             .append(",\"missedQwirkles\":").append(st[8])
             .append(",\"level\":").append(Math.max(1, st[9]))
             .append(",\"levelObjective\":\"").append(Json.esc(Levels.objective(Math.max(1, st[9])))).append("\"},");
            b.append("\"unlocked\":").append(ach.size()).append(",\"total\":").append(Achievements.ALL.size()).append(',');
            b.append("\"achievements\":").append(Achievements.allJson(ach));
            b.append('}');
            return b.toString();
        }
    }

    private static int humanSeat(GameState g) {
        for (int i = 0; i < g.seats.size(); i++) if (!g.seats.get(i).ai) return i;
        return -1;
    }
    private static int[] readStats(Connection c, long uid) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(
                "SELECT games,wins,win_streak,best_streak,best_score,best_move,tiles_placed,quirkles,missed_quirkles,level FROM user_stats WHERE user_id=?")) {
            ps.setLong(1, uid);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return new int[]{0,0,0,0,0,0,0,0,0,1};
                return new int[]{rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getInt(4), rs.getInt(5),
                                 rs.getInt(6), rs.getInt(7), rs.getInt(8), rs.getInt(9), Math.max(1, rs.getInt(10))};
            }
        }
    }
    private static void upsertStats(Connection c, long uid, int games, int wins, int streak, int bestStreak,
                                    int bestScore, int bestMove, int tiles, int quirkles, int missed, int level) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(
                "INSERT INTO user_stats(user_id,games,wins,win_streak,best_streak,best_score,best_move,tiles_placed,quirkles,missed_quirkles,level,updated_at) " +
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,now()) " +
                "ON CONFLICT (user_id) DO UPDATE SET games=?,wins=?,win_streak=?,best_streak=?,best_score=?,best_move=?,tiles_placed=?,quirkles=?,missed_quirkles=?,level=?,updated_at=now()")) {
            int i = 1;
            ps.setLong(i++, uid);
            ps.setInt(i++, games); ps.setInt(i++, wins); ps.setInt(i++, streak); ps.setInt(i++, bestStreak);
            ps.setInt(i++, bestScore); ps.setInt(i++, bestMove); ps.setInt(i++, tiles); ps.setInt(i++, quirkles); ps.setInt(i++, missed); ps.setInt(i++, level);
            ps.setInt(i++, games); ps.setInt(i++, wins); ps.setInt(i++, streak); ps.setInt(i++, bestStreak);
            ps.setInt(i++, bestScore); ps.setInt(i++, bestMove); ps.setInt(i++, tiles); ps.setInt(i++, quirkles); ps.setInt(i++, missed); ps.setInt(i++, level);
            ps.executeUpdate();
        }
    }

    public static int currentLevel(long uid) {
        try (Connection c = Db.connection()) { return Math.max(1, readStats(c, uid)[9]); }
        catch (SQLException e) { return 1; }
    }
    private static java.util.LinkedHashMap<String,String> readAchievementTimes(Connection c, long uid) throws SQLException {
        java.util.LinkedHashMap<String,String> m = new java.util.LinkedHashMap<>();
        try (PreparedStatement ps = c.prepareStatement("SELECT code, unlocked_at FROM user_achievement WHERE user_id=?")) {
            ps.setLong(1, uid);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    java.time.OffsetDateTime t = rs.getObject(2, java.time.OffsetDateTime.class);
                    m.put(rs.getString(1), t == null ? null : t.toString());
                }
            }
        }
        return m;
    }
    private static Set<String> readAchievements(Connection c, long uid) throws SQLException {
        Set<String> s = new HashSet<>();
        try (PreparedStatement ps = c.prepareStatement("SELECT code FROM user_achievement WHERE user_id=?")) {
            ps.setLong(1, uid);
            try (ResultSet rs = ps.executeQuery()) { while (rs.next()) s.add(rs.getString(1)); }
        }
        return s;
    }
}
