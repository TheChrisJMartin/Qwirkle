package uk.co.donotpassgo.quirkle.service;

import uk.co.donotpassgo.quirkle.ai.*;
import uk.co.donotpassgo.quirkle.engine.*;
import uk.co.donotpassgo.quirkle.store.GameStore;

import java.sql.SQLException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Playable API logic, independent of HTTP. The human is seat 0; opponents are AI.
 * The human plays via {@link #move}/{@link #swap}; the client then steps the bots one at a time
 * through {@link #advance} (so each can be paced and announced). {@link #stats} reports session figures.
 */
public final class GameService {
    private static final int HUMAN = 0;
    private static final Map<Long, Object> LOCKS = new ConcurrentHashMap<>();
    private GameService() {}
    private static Object lockFor(long id) { return LOCKS.computeIfAbsent(id, k -> new Object()); }

    public static String createGame(Long userId, int aiCount, String difficulty, String humanName,
                                    String personasCsv, String namesCsv, String mode, Integer reqLevel) {
        boolean progressive = "progressive".equalsIgnoreCase(mode);
        int progLevel = 0;
        if (progressive) {
            if (userId == null) throw GameException.badRequest("Log in to play Progressive mode.");
            int cur = UserService.currentLevel(userId);
            progLevel = (reqLevel == null) ? cur : Math.max(1, Math.min(cur, reqLevel)); // replay <= current, never skip
            aiCount = 3;
            difficulty = Levels.botDifficulty(progLevel);
            personasCsv = null; // standard bots at the level's difficulty
        }
        if (aiCount < 1 || aiCount > 3) throw GameException.badRequest("Choose 1 to 3 opponents.");
        String globalDiff = difficulty == null ? null : normaliseDifficulty(difficulty);
        String[] personas = (personasCsv == null || personasCsv.isBlank()) ? null : personasCsv.split(",");
        boolean custom = personas != null; // logged-in per-bot personalities
        String name = (humanName == null || humanName.isBlank()) ? "You" : humanName.trim();
        java.util.Random rnd = new java.util.Random();

        java.util.List<String> botNames;
        if (namesCsv != null && !namesCsv.isBlank()) {
            botNames = new ArrayList<>();
            for (String n : namesCsv.split(",")) if (!n.isBlank()) botNames.add(n.trim());
        } else {
            botNames = uk.co.donotpassgo.quirkle.ai.Bots.pick(globalDiff, aiCount, rnd); // curated mix by difficulty
        }
        while (botNames.size() < aiCount) botNames.add(Personalities.nameFor(botNames.size()));

        List<Seat> seats = new ArrayList<>();
        Seat you = Seat.human(name); you.userId = userId; seats.add(you);
        for (int i = 0; i < aiCount; i++) {
            String botName = botNames.get(i);
            if (custom) {
                String key = (personas.length > i && Personalities.isKey(personas[i].trim()))
                        ? personas[i].trim() : Personalities.keyForName(botName);
                Personalities.Preset p = Personalities.get(key);
                Seat bot = Seat.ai(botName, p.difficulty());
                bot.personality = key;
                seats.add(bot);
            } else {
                Seat bot = Seat.ai(botName, globalDiff != null ? globalDiff : "medium");
                bot.personality = null; // neutral behaviour for guest/quick games
                seats.add(bot);
            }
        }
        GameState g = GameState.newGame(rnd.nextLong(), seats);
        g.mode = progressive ? "progressive" : "free";
        g.level = progressive ? progLevel : 0;
        try { GameStore.create(g); } catch (SQLException e) { throw dbError(e); }
        return buildState(g, 0, null, List.of());
    }

    public static String state(long id) { return buildState(loadOr404(id), 0, null, List.of()); }

    public static String move(long id, String placements, long thinkMs) {
        synchronized (lockFor(id)) {
            GameState g = loadOr404(id);
            requireHumanTurn(g);
            Move m;
            try { m = EventCodec.decodeMove(placements == null ? "" : placements); }
            catch (Exception e) { throw GameException.badRequest("Could not read the placement."); }
            if (m.placements().isEmpty()) throw GameException.badRequest("Place at least one tile.");
            int before = g.seats.get(HUMAN).score;
            try { g.applyMove(HUMAN, m); }
            catch (RuntimeException e) { throw GameException.badRequest(cleanEngineMessage(e.getMessage())); }
            g.humanThinkMs += Math.max(0, thinkMs); g.humanThinkMoves++;
            saveOr500(g);
            var unlocked = UserService.finishGameIfEnded(g);
            return buildState(g, g.seats.get(HUMAN).score - before, null, unlocked);
        }
    }

    public static String swap(long id, String tilesCsv, long thinkMs) {
        synchronized (lockFor(id)) {
            GameState g = loadOr404(id);
            requireHumanTurn(g);
            List<Tile> tiles;
            try { tiles = EventCodec.decodeTiles(tilesCsv == null ? "" : tilesCsv); }
            catch (Exception e) { throw GameException.badRequest("Could not read the tiles to swap."); }
            if (tiles.isEmpty()) throw GameException.badRequest("Choose at least one tile to swap.");
            try { g.swap(HUMAN, tiles); }
            catch (RuntimeException e) { throw GameException.badRequest(cleanEngineMessage(e.getMessage())); }
            g.humanThinkMs += Math.max(0, thinkMs); g.humanThinkMoves++;
            saveOr500(g);
            var unlocked = UserService.finishGameIfEnded(g);
            return buildState(g, 0, null, unlocked);
        }
    }

    /** Forced pass: only when the human has no legal move and the bag is empty. */
    public static String pass(long id) {
        synchronized (lockFor(id)) {
            GameState g = loadOr404(id);
            requireHumanTurn(g);
            if (!LegalMoves.enumerate(g.board, g.seats.get(HUMAN).hand).isEmpty())
                throw GameException.conflict("You still have a legal move.");
            if (!g.bag.isEmpty()) throw GameException.conflict("You can still swap tiles.");
            g.pass(HUMAN);
            saveOr500(g);
            var unlocked = UserService.finishGameIfEnded(g);
            return buildState(g, 0, new StepInfo(HUMAN, g.seats.get(HUMAN).name, "PASS", List.of(), 0), unlocked);
        }
    }

    /** Play exactly one step: one AI seat, or a forced human pass. Returns state plus that step's info. */
    public static String advance(long id) {
        synchronized (lockFor(id)) {
            GameState g = loadOr404(id);
            StepInfo step = null;
            if (g.status == GameStatus.IN_PROGRESS) {
                Seat cur = g.seats.get(g.current);
                if (cur.ai) step = playOneAi(g);
            }
            saveOr500(g);
            var unlocked = UserService.finishGameIfEnded(g);
            return buildState(g, 0, step, unlocked);
        }
    }

    private static StepInfo playOneAi(GameState g) {
        int si = g.current;
        Seat seat = g.seats.get(si);
        AiDecision d = Ai.of(seat.aiDifficulty, seat.personality, g.seed).decide(g, si);
        int before = seat.score;
        List<String> tiles = new ArrayList<>();
        String kind;
        switch (d.kind()) {
            case AiDecision.PLAY -> {
                for (Placement p : d.move().placements()) tiles.add(p.tile().code());
                g.applyMove(si, d.move()); kind = "MOVE";
            }
            case AiDecision.SWAP -> {
                for (Tile t : d.swapTiles()) tiles.add(t.code());
                g.swap(si, d.swapTiles()); kind = "SWAP";
            }
            default -> { g.pass(si); kind = "PASS"; }
        }
        return new StepInfo(si, seat.name, kind, tiles, seat.score - before);
    }

    // --- session stats ---
    public static String stats(long id) {
        GameState g = loadOr404(id);
        int n = g.seats.size();
        Analytics a = Analytics.compute(g);
        int hi = -1, hiSeat = 0;
        for (int i = 0; i < n; i++) if (g.seats.get(i).score > hi) { hi = g.seats.get(i).score; hiSeat = i; }
        int oLead = a.leaderOpens(), cLead = a.leaderCloses();

        StringBuilder b = new StringBuilder("{");
        b.append("\"bag\":").append(g.bag.size()).append(',');
        b.append("\"quirkles\":").append(a.totalQuirkles).append(',');
        b.append("\"highestScore\":").append(hi).append(',');
        b.append("\"highestScorer\":\"").append(Json.esc(g.seats.get(hiSeat).name)).append("\",");
        b.append("\"opensLeader\":\"").append(Json.esc(g.seats.get(oLead).name)).append("\",");
        b.append("\"closesLeader\":\"").append(Json.esc(g.seats.get(cLead).name)).append("\",");
        b.append("\"seats\":[");
        for (int i = 0; i < n; i++) {
            if (i > 0) b.append(',');
            Seat s = g.seats.get(i);
            b.append("{\"name\":\"").append(Json.esc(s.name)).append('"')
             .append(",\"ai\":").append(s.ai)
             .append(",\"difficulty\":").append(s.aiDifficulty == null ? "null" : "\"" + Json.esc(s.aiDifficulty) + "\"")
             .append(",\"score\":").append(s.score)
             .append(",\"moves\":").append(a.moves[i])
             .append(",\"movePoints\":").append(a.movePoints[i])
             .append(",\"best\":").append(a.best[i])
             .append(",\"tilesPlaced\":").append(a.tilesPlaced[i])
             .append(",\"quirkles\":").append(a.quirkles[i])
             .append(",\"missedQwirkles\":").append(a.missedQwirkles[i])
             .append(",\"swaps\":").append(a.swaps[i])
             .append(",\"opens\":").append(a.opens[i])
             .append(",\"closes\":").append(a.closes[i]).append('}');
        }
        b.append("]}");
        return b.toString();
    }

    // --- state JSON ---
    static String buildState(GameState g, int lastPoints, StepInfo lastMove, java.util.List<Achievements.Def> unlocked) {
        return buildState(g, HUMAN, lastPoints, lastMove, unlocked);
    }
    static String buildState(GameState g, int viewerSeat, int lastPoints, StepInfo lastMove, java.util.List<Achievements.Def> unlocked) {
        boolean humanTurn = g.status == GameStatus.IN_PROGRESS && g.current == viewerSeat && !g.seats.get(viewerSeat).ai;
        boolean youHaveMove = humanTurn && !LegalMoves.enumerate(g.board, g.seats.get(viewerSeat).hand).isEmpty();
        Analytics an = Analytics.compute(g, false);
        java.util.List<Seat> fresh0 = new ArrayList<>();
        for (Seat s0 : g.seats) fresh0.add(s0.ai ? Seat.ai(s0.name, s0.aiDifficulty) : Seat.human(s0.name));
        GameState deal0 = GameState.newGame(g.seed, fresh0);
        int starterSeat = deal0.current;
        int starterTiles = GameState.openingCount(fresh0.get(starterSeat).hand);
        String starterName = g.seats.get(starterSeat).name;

        StringBuilder b = new StringBuilder("{");
        b.append("\"id\":").append(g.id).append(',');
        b.append("\"status\":\"").append(g.status.name()).append("\",");
        b.append("\"kind\":\"").append(g.kind == null ? "SOLO" : g.kind).append("\",");
        b.append("\"current\":").append(g.current).append(',');
        b.append("\"yourSeat\":").append(viewerSeat).append(',');
        b.append("\"firstMove\":").append(g.isFirstMove()).append(',');
        b.append("\"bag\":").append(g.bag.size()).append(',');
        b.append("\"lastPoints\":").append(lastPoints).append(',');
        b.append("\"youHaveMove\":").append(youHaveMove).append(',');
        b.append("\"totalQuirkles\":").append(an.totalQuirkles).append(',');
        b.append("\"starter\":{\"seat\":").append(starterSeat)
         .append(",\"name\":\"").append(Json.esc(starterName)).append("\",\"tiles\":").append(starterTiles).append("},");
        boolean progressive = "progressive".equals(g.mode);
        b.append("\"gameMode\":\"").append(g.mode == null ? "free" : g.mode).append("\",");
        b.append("\"gameLevel\":").append(g.level).append(',');
        b.append("\"levelObjective\":\"").append(progressive ? Json.esc(Levels.objective(g.level)) : "").append("\",");
        if (progressive && g.status == GameStatus.FINISHED) {
            int hs = -1; for (int i = 0; i < g.seats.size(); i++) if (!g.seats.get(i).ai) { hs = i; break; }
            if (hs >= 0) {
                int humanScore = g.seats.get(hs).score, secondBest = Integer.MIN_VALUE;
                for (int i = 0; i < g.seats.size(); i++) if (i != hs) secondBest = Math.max(secondBest, g.seats.get(i).score);
                boolean won = humanScore > secondBest;
                boolean met = Levels.meets(g.level, won, humanScore - secondBest, humanScore,
                        an.quirkles[hs], an.best[hs], an.missedQwirkles[hs], an.swaps[hs], an.bagEmptierSeat == hs);
                b.append("\"levelMet\":").append(met).append(',');
            }
        }

        b.append("\"board\":[");
        boolean first = true;
        for (Map.Entry<Coord, Tile> e : g.board.view().entrySet()) {
            if (!first) b.append(','); first = false;
            b.append("{\"x\":").append(e.getKey().x()).append(",\"y\":").append(e.getKey().y())
             .append(",\"t\":\"").append(e.getValue().code()).append("\"}");
        }
        b.append("],");

        b.append("\"seats\":[");
        for (int i = 0; i < g.seats.size(); i++) {
            Seat s = g.seats.get(i);
            if (i > 0) b.append(',');
            b.append("{\"index\":").append(i)
             .append(",\"name\":\"").append(Json.esc(s.name)).append('"')
             .append(",\"ai\":").append(s.ai)
             .append(",\"difficulty\":").append(s.aiDifficulty == null ? "null" : "\"" + Json.esc(s.aiDifficulty) + "\"")
             .append(",\"score\":").append(s.score)
             .append(",\"handCount\":").append(s.hand.size())
             .append(",\"quirkles\":").append(an.quirkles[i]).append('}');
        }
        b.append("],");

        b.append("\"hand\":[");
        List<Tile> hand = g.seats.get(viewerSeat).hand;
        for (int i = 0; i < hand.size(); i++) { if (i > 0) b.append(','); b.append('"').append(hand.get(i).code()).append('"'); }
        b.append("],");

        b.append("\"events\":[");
        List<GameEvent> ev = new ArrayList<>(g.events);
        ev.sort(Comparator.comparingInt(GameEvent::seq));
        for (int i = 0; i < ev.size(); i++) {
            GameEvent e = ev.get(i);
            if (i > 0) b.append(',');
            String nm = e.seatIndex() >= 0 && e.seatIndex() < g.seats.size() ? g.seats.get(e.seatIndex()).name : "?";
            int pts = an.eventPoints.getOrDefault(e.seq(), 0);
            int qwc = an.eventQwirkles.getOrDefault(e.seq(), 0); boolean qw = qwc > 0;
            b.append("{\"seat\":").append(e.seatIndex())
             .append(",\"name\":\"").append(Json.esc(nm)).append('"')
             .append(",\"kind\":\"").append(e.kind()).append('"')
             .append(",\"points\":").append(pts)
             .append(",\"qwirkle\":").append(qw).append(",\"qwCount\":").append(qwc)
             .append(",\"tiles\":[");
            List<String> ts = eventTiles(e.kind(), e.detail());
            for (int j = 0; j < ts.size(); j++) { if (j > 0) b.append(','); b.append('"').append(ts.get(j)).append('"'); }
            b.append("],\"cells\":[");
            List<int[]> cells = eventCells(e.kind(), e.detail());
            for (int j = 0; j < cells.size(); j++) { if (j > 0) b.append(','); b.append("{\"x\":").append(cells.get(j)[0]).append(",\"y\":").append(cells.get(j)[1]).append('}'); }
            b.append("]}");
        }
        b.append("]");

        if (lastMove != null) {
            b.append(",\"lastMove\":{\"seat\":").append(lastMove.seat())
             .append(",\"name\":\"").append(Json.esc(lastMove.name())).append('"')
             .append(",\"kind\":\"").append(lastMove.kind()).append('"')
             .append(",\"points\":").append(lastMove.points()).append(",\"tiles\":[");
            for (int j = 0; j < lastMove.tiles().size(); j++) { if (j > 0) b.append(','); b.append('"').append(lastMove.tiles().get(j)).append('"'); }
            b.append("]}");
        } else {
            b.append(",\"lastMove\":null");
        }

        int lastQ = 0; String lastScorer = "";
        for (int i = ev.size() - 1; i >= 0; i--) {
            GameEvent e = ev.get(i);
            if (GameEvent.MOVE.equals(e.kind())) {
                lastQ = an.eventQwirkles.getOrDefault(e.seq(), 0);
                int si = e.seatIndex();
                lastScorer = (si >= 0 && si < g.seats.size()) ? g.seats.get(si).name : "";
                break;
            }
        }
        b.append(",\"lastQwirkles\":").append(lastQ)
         .append(",\"lastScorer\":\"").append(Json.esc(lastScorer)).append("\"");

        b.append(",\"unlocked\":[");
        if (unlocked != null) for (int i = 0; i < unlocked.size(); i++) {
            Achievements.Def d = unlocked.get(i);
            if (i > 0) b.append(',');
            b.append("{\"code\":\"").append(d.code()).append('"')
             .append(",\"name\":\"").append(Json.esc(d.name())).append('"')
             .append(",\"difficulty\":").append(d.difficulty()).append('}');
        }
        b.append(']');

        b.append('}');
        return b.toString();
    }

    private static List<String> eventTiles(String kind, String detail) {
        List<String> out = new ArrayList<>();
        if (detail == null || detail.isBlank()) return out;
        if (GameEvent.MOVE.equals(kind)) {
            for (String part : detail.split(";")) { String[] f = part.split(","); if (f.length == 3) out.add(f[2]); }
        } else if (GameEvent.SWAP.equals(kind)) {
            for (String c : detail.split(",")) if (!c.isBlank()) out.add(c.trim());
        }
        return out;
    }

    private static List<int[]> eventCells(String kind, String detail) {
        List<int[]> out = new ArrayList<>();
        if (GameEvent.MOVE.equals(kind) && detail != null && !detail.isBlank()) {
            for (String part : detail.split(";")) {
                String[] f = part.split(",");
                if (f.length == 3) out.add(new int[]{Integer.parseInt(f[0]), Integer.parseInt(f[1])});
            }
        }
        return out;
    }

    // --- helpers ---
    private static void requireHumanTurn(GameState g) {
        if (g.status != GameStatus.IN_PROGRESS) throw GameException.conflict("This game is over.");
        if (g.current != HUMAN || g.seats.get(HUMAN).ai) throw GameException.conflict("It isn't your turn yet.");
    }
    private static GameState loadOr404(long id) {
        GameState g;
        try { g = GameStore.load(id); } catch (SQLException e) { throw dbError(e); }
        if (g == null) throw GameException.notFound("No game with id " + id + ".");
        return g;
    }
    private static void saveOr500(GameState g) { try { GameStore.save(g); } catch (SQLException e) { throw dbError(e); } }
    private static GameException dbError(SQLException e) { return new GameException(500, "Database error: " + e.getMessage()); }
    private static String normaliseDifficulty(String d) {
        if (d == null) return "medium";
        return switch (d.toLowerCase()) { case "easy", "medium", "hard" -> d.toLowerCase(); default -> "medium"; };
    }
    private static String cleanEngineMessage(String m) { return m == null ? "That move isn't legal." : m.replace("Illegal move: ", ""); }
}
