package uk.co.donotpassgo.quirkle.service;

import uk.co.donotpassgo.quirkle.engine.*;
import java.util.*;

/**
 * Replays a game's event log once and derives per-move and per-seat figures used by the
 * state (log annotations, per-seat Qwirkle counts) and the stats endpoint.
 */
public final class Analytics {
    public final int n;
    public final int[] moves, swaps, passes, tilesPlaced, movePoints, quirkles, best, opens, closes, missedQwirkles, maxMoveQwirkles;
    public int finisherSeat = -1;   // went out (played last tile)
    public int bagEmptierSeat = -1; // drew the last tile from the bag
    public final boolean[] held5Colour, held5Shape, held6Colour, held6DiffColour, held6DiffShape, purpleQwirkle, star8Qwirkle;
    public final boolean[] held3Same, heldQwirkleRack;
    public final int[] maxConsecPasses, maxSwapSize;
    private final int[] consecPass;
    public int totalQuirkles = 0;
    public final Map<Integer, Integer> eventPoints = new HashMap<>();   // seq -> points
    public final Map<Integer, Integer> eventQwirkles = new HashMap<>(); // seq -> qwirkle count

    private Analytics(int n) {
        this.n = n;
        moves = new int[n]; swaps = new int[n]; passes = new int[n];
        tilesPlaced = new int[n]; movePoints = new int[n]; quirkles = new int[n];
        best = new int[n]; opens = new int[n]; closes = new int[n]; missedQwirkles = new int[n]; maxMoveQwirkles = new int[n];
        held5Colour = new boolean[n]; held5Shape = new boolean[n]; held6Colour = new boolean[n];
        held6DiffColour = new boolean[n]; held6DiffShape = new boolean[n];
        purpleQwirkle = new boolean[n]; star8Qwirkle = new boolean[n];
        held3Same = new boolean[n]; heldQwirkleRack = new boolean[n];
        maxConsecPasses = new int[n]; maxSwapSize = new int[n]; consecPass = new int[n];
    }

    public static Analytics compute(GameState g) { return compute(g, true); }
    /** deep=false skips the per-move legal-move enumeration (missed-Qwirkle + hand flags) for the hot path. */
    public static Analytics compute(GameState g, boolean deep) {
        Analytics a = new Analytics(g.seats.size());
        List<Seat> fresh = new ArrayList<>();
        for (Seat s : g.seats) fresh.add(s.ai ? Seat.ai(s.name, s.aiDifficulty) : Seat.human(s.name));
        GameState r = GameState.newGame(g.seed, fresh);
        if (deep) for (int i = 0; i < a.n; i++) a.noteHand(i, r.seats.get(i).hand);
        List<GameEvent> events = new ArrayList<>(g.events);
        events.sort(Comparator.comparingInt(GameEvent::seq));
        if (!events.isEmpty()) r.current = events.get(0).seatIndex();
        for (GameEvent e : events) {
            int si = e.seatIndex();
            switch (e.kind()) {
                case GameEvent.MOVE -> {
                    Move m = EventCodec.decodeMove(e.detail());
                    long areaBefore = bbox(r.board);
                    ValidationResult vr = MoveValidator.validate(r.board, m, r.board.isEmpty());
                    int pts = Scorer.score(vr, m);
                    int q = 0;
                    for (Line l : vr.scoringLines()) if (l.length() == 6) q++;
                    if (deep && q == 0 && qwirkleWasAvailable(r, si)) a.missedQwirkles[si]++;
                    if (deep) a.noteQwirkleLines(si, vr);
                    if (q > a.maxMoveQwirkles[si]) a.maxMoveQwirkles[si] = q;
                    int bagBefore = r.bag.size();
                    r.applyMove(si, m);
                    if (bagBefore > 0 && r.bag.isEmpty()) a.bagEmptierSeat = si;   // drew the last tile(s)
                    if (r.status == uk.co.donotpassgo.quirkle.engine.GameStatus.FINISHED
                            && r.seats.get(si).hand.isEmpty() && r.bag.isEmpty()) a.finisherSeat = si; // went out
                    if (deep) a.noteHand(si, r.seats.get(si).hand);
                    long areaAfter = bbox(r.board);
                    a.moves[si]++; a.tilesPlaced[si] += m.size(); a.movePoints[si] += pts;
                    a.quirkles[si] += q; a.totalQuirkles += q;
                    if (pts > a.best[si]) a.best[si] = pts;
                    if (areaAfter > areaBefore) a.opens[si]++; else a.closes[si]++;
                    a.eventPoints.put(e.seq(), pts);
                    a.eventQwirkles.put(e.seq(), q);
                    a.consecPass[si] = 0;
                }
                case GameEvent.SWAP -> { java.util.List<Tile> sw = EventCodec.decodeTiles(e.detail()); r.swap(si, sw); a.swaps[si]++; a.consecPass[si] = 0; if (sw.size() > a.maxSwapSize[si]) a.maxSwapSize[si] = sw.size(); if (deep) a.noteHand(si, r.seats.get(si).hand); }
                default -> { r.pass(si); a.passes[si]++; a.consecPass[si]++; if (a.consecPass[si] > a.maxConsecPasses[si]) a.maxConsecPasses[si] = a.consecPass[si]; }
            }
        }
        return a;
    }

    public int leaderOpens() { return leader(opens); }
    public int leaderCloses() { return leader(closes); }

    private static int leader(int[] arr) { int i = 0; for (int k = 1; k < arr.length; k++) if (arr[k] > arr[i]) i = k; return i; }

    private void noteHand(int si, java.util.List<Tile> hand) {
        int[] cc = new int[6]; int[] sc = new int[6];
        java.util.Set<Integer> cols = new java.util.HashSet<>(), shps = new java.util.HashSet<>();
        for (Tile t : hand) { cc[t.colour().ordinal()]++; sc[t.shape().ordinal()]++; cols.add(t.colour().ordinal()); shps.add(t.shape().ordinal()); }
        for (int v : cc) { if (v >= 5) held5Colour[si] = true; if (v >= 6) held6Colour[si] = true; }
        for (int v : sc) if (v >= 5) held5Shape[si] = true;
        if (cols.size() >= 6) held6DiffColour[si] = true;
        if (shps.size() >= 6) held6DiffShape[si] = true;
        java.util.Map<String,Integer> exact = new java.util.HashMap<>();
        for (Tile t : hand) { String k = t.colour().ordinal()+"-"+t.shape().ordinal(); exact.merge(k, 1, Integer::sum); }
        for (int v : exact.values()) if (v >= 3) held3Same[si] = true;
        if (hand.size() >= 6) {
            boolean oneColour = cols.size() == 1 && shps.size() >= 6;   // 6 of one colour, all shapes distinct
            boolean oneShape  = shps.size() == 1 && cols.size() >= 6;   // 6 of one shape, all colours distinct
            if (oneColour || oneShape) heldQwirkleRack[si] = true;
        }
    }
    private void noteQwirkleLines(int si, ValidationResult vr) {
        for (Line l : vr.scoringLines()) {
            if (l.length() != 6) continue;
            boolean sameColour = true, sameShape = true;
            Colour c0 = l.tiles().get(0).colour(); Shape s0 = l.tiles().get(0).shape();
            for (Tile t : l.tiles()) { if (t.colour() != c0) sameColour = false; if (t.shape() != s0) sameShape = false; }
            if (sameColour && c0 == Colour.PURPLE) purpleQwirkle[si] = true;
            if (sameShape && s0 == Shape.STAR8) star8Qwirkle[si] = true;
        }
    }

    private static boolean qwirkleWasAvailable(GameState r, int si) {
        for (Move cand : uk.co.donotpassgo.quirkle.ai.LegalMoves.enumerate(r.board, r.seats.get(si).hand)) {
            ValidationResult vr = MoveValidator.validate(r.board, cand, r.board.isEmpty());
            for (Line l : vr.scoringLines()) if (l.length() == 6) return true;
        }
        return false;
    }

    private static long bbox(Board b) {
        if (b.isEmpty()) return 0;
        int minx = Integer.MAX_VALUE, miny = Integer.MAX_VALUE, maxx = Integer.MIN_VALUE, maxy = Integer.MIN_VALUE;
        for (Coord c : b.view().keySet()) {
            minx = Math.min(minx, c.x()); maxx = Math.max(maxx, c.x());
            miny = Math.min(miny, c.y()); maxy = Math.max(maxy, c.y());
        }
        return (long) (maxx - minx + 1) * (maxy - miny + 1);
    }
}
