package uk.co.donotpassgo.quirkle.service;

import java.util.*;

/** Achievement catalogue, difficulty ratings, and the per-game evaluator. */
public final class Achievements {
    private Achievements() {}

    /** difficulty 1 (easy) .. 5 (brutal); impl=false means designed but not yet earnable. */
    public record Def(String code, String name, String desc, int difficulty, boolean impl) {}

    /** Everything the evaluator needs about one finished game (from the human's perspective). */
    public record Ctx(
        boolean won, int humanScore, int marginOverSecond, int bestMove, int maxMoveQwirkles,
        int quirklesThisGame, int missedThisGame, int swaps, boolean bagEmptierIsHuman,
        boolean opensLeader, boolean closesLeader, boolean allBotsHard, boolean edwardPresent,
        long avgThinkMs, boolean held5Colour, boolean held5Shape, boolean held6Colour,
        boolean held6DiffColour, boolean held6DiffShape, boolean purpleQwirkle, boolean star8Qwirkle,
        int totalGames, int winStreak,
        boolean network, int level, boolean blitz, boolean wentOut,
        boolean held3Same, boolean heldQwirkleRack, int maxConsecPasses, int maxSwapSize) {}

    public static final List<Def> ALL = List.of(
        new Def("FIRST_QWIRKLE",  "Qwirkle!",            "Complete your first Qwirkle.", 1, true),
        new Def("FIRST_BLOOD",    "First Blood",         "Win your first game.", 1, true),
        new Def("MISSED_IT",      "Missed It By That Much","Fail to play an available Qwirkle.", 1, true),
        new Def("CENTURY",        "Century",             "Score 100+ in a single game.", 2, true),
        new Def("BAG_EMPTIER",    "Bag Emptier",         "Draw the last tile from the bag.", 2, true),
        new Def("BOARD_ARCHITECT","Board Architect",     "Open the board the most in a game.", 2, true),
        new Def("CLOSER",         "The Closer",          "Close the board the most in a game.", 2, true),
        new Def("TILE_MISER",     "Tile Miser",          "Win a game without ever swapping.", 2, true),
        new Def("RAINBOW_RACK",   "Rainbow Rack",        "Hold six tiles of six different colours.", 2, true),
        new Def("ONE_OF_EACH",    "One of Each",         "Hold six tiles of six different shapes.", 2, true),
        new Def("ZEN",            "Zen Master",          "Win with an average think time over 60s.", 2, true),
        new Def("EDWARDS_NEMESIS","Edward's Nemesis",    "Win a game that Edward was playing in.", 2, true),
        new Def("BIG_SWINGER",    "Big Swinger",         "Score 20+ points in a single move.", 3, true),
        new Def("CLEAN_SWEEP",    "Clean Sweep",         "Win by 50 points or more.", 3, true),
        new Def("BUTTERFINGERS",  "Butterfingers",       "Miss 5+ Qwirkles in a single game.", 3, true),
        new Def("MONOCHROME_HAND","Monochrome Hand",     "Hold five tiles of the same colour.", 3, true),
        new Def("SHAPE_SHIFTER",  "Shape Shifter",       "Hold five tiles of the same shape.", 3, true),
        new Def("SNAP_DECISION",  "Snap Decision",       "Win with an average think time under 10s.", 3, true),
        new Def("HAT_TRICK",      "Hat Trick",           "Win three games in a row.", 3, true),
        new Def("MARATHON",       "Marathon",            "Play 50 games.", 3, true),
        new Def("FLAWLESS",       "Flawless Victory",    "Win a game without missing a single Qwirkle.", 3, true),
        new Def("DOUBLE_TROUBLE", "Double Trouble",      "Score two Qwirkles in a single move.", 4, true),
        new Def("GIANT_SLAYER",   "Giant Slayer",        "Beat a table of all-Hard bots.", 4, true),
        new Def("PURELY_PURPLE",  "Purely Purple",       "Complete a Qwirkle entirely of purple tiles.", 4, true),
        new Def("STAR_GAZER",     "Star Gazer",          "Complete a Qwirkle of eight-point stars.", 4, true),
        new Def("CENTURION",      "Centurion",           "Play 100 games.", 4, true),
        new Def("PERFECT",        "Perfect Placement",   "Score 30+ points in a single move.", 5, true),
        new Def("DOUBLE_CENTURY", "Double Century",      "Score 200+ in a single game.", 5, true),
        new Def("FULL_HOUSE",     "Full House",          "Hold six tiles of the same colour.", 5, true),
        new Def("HOARDER",       "Hoarder",             "Hold all three copies of one tile.", 2, true),
        new Def("HOLD_QWIRKLE",  "Qwirkle in the Hand", "Hold a complete Qwirkle on your rack.", 4, true),
        new Def("PACIFIST",      "Pacifist",            "Pass three turns in a row.", 2, true),
        new Def("BLITZ",         "Blitz",               "Finish a round (2+ humans and bots) in under 10 seconds.", 3, true),
        new Def("NETWORKER",     "Networker",           "Win a network game against other people.", 2, true),
        new Def("NET_CRUSHER",   "網 Crusher",          "Win a network game by 30 points or more.", 3, true),
        new Def("SESQUI",        "Sesquicentury",       "Score 150+ in a single game.", 3, true),
        new Def("GO_OUT",        "Out in Style",        "Win by playing your last tile to end the game.", 2, true),
        new Def("FULL_SWAP",     "Fresh Hand",          "Swap all six tiles in a single turn.", 2, true),
        new Def("TRIPLE_QWIRKLE","Triple Threat",       "Complete three Qwirkles in one game.", 4, true),
        new Def("ON_FIRE",       "On Fire",             "Win five games in a row.", 4, true),
        new Def("GETTING_STARTED","Getting Started",    "Play ten games.", 1, true),
        new Def("REGULAR",       "Regular",             "Play twenty-five games.", 2, true),
        new Def("LEVEL_5",       "Climbing",            "Reach level 5 in Progressive play.", 1, true),
        new Def("LEVEL_10",      "Double Digits",       "Reach level 10 in Progressive play.", 2, true),
        new Def("LEVEL_20",      "Ascendant",           "Reach level 20 in Progressive play.", 3, true),
        new Def("LEVEL_50",      "Halfway to the Top",  "Reach level 50 in Progressive play.", 4, true),
        new Def("LEVEL_100",     "Centurion of Levels", "Reach level 100 in Progressive play.", 5, true),
        // designed, not yet earnable (need per-career tile tracking / mid-game snapshots)
        new Def("YELLOW_FEVER",   "Yellow Fever",        "Play the yellow diamond 100 times.", 3, false),
        new Def("FULL_SET",       "Full Set",            "Play at least one of every one of the 36 tiles.", 3, false),
        new Def("COMEBACK_KID",   "Comeback Kid",        "Win after being last at the halfway mark.", 4, false)
    );

    public static Set<String> earned(Ctx c) {
        Set<String> e = new LinkedHashSet<>();
        if (c.quirklesThisGame() >= 1) e.add("FIRST_QWIRKLE");
        if (c.won()) e.add("FIRST_BLOOD");
        if (c.missedThisGame() >= 1) e.add("MISSED_IT");
        if (c.humanScore() >= 100) e.add("CENTURY");
        if (c.bagEmptierIsHuman()) e.add("BAG_EMPTIER");
        if (c.opensLeader()) e.add("BOARD_ARCHITECT");
        if (c.closesLeader()) e.add("CLOSER");
        if (c.won() && c.swaps() == 0) e.add("TILE_MISER");
        if (c.held6DiffColour()) e.add("RAINBOW_RACK");
        if (c.held6DiffShape()) e.add("ONE_OF_EACH");
        if (c.won() && c.avgThinkMs() > 60_000) e.add("ZEN");
        if (c.won() && c.edwardPresent()) e.add("EDWARDS_NEMESIS");
        if (c.bestMove() >= 20) e.add("BIG_SWINGER");
        if (c.won() && c.marginOverSecond() >= 50) e.add("CLEAN_SWEEP");
        if (c.missedThisGame() >= 5) e.add("BUTTERFINGERS");
        if (c.held5Colour()) e.add("MONOCHROME_HAND");
        if (c.held5Shape()) e.add("SHAPE_SHIFTER");
        if (c.won() && c.avgThinkMs() > 0 && c.avgThinkMs() < 10_000) e.add("SNAP_DECISION");
        if (c.winStreak() >= 3) e.add("HAT_TRICK");
        if (c.totalGames() >= 50) e.add("MARATHON");
        if (c.won() && c.missedThisGame() == 0) e.add("FLAWLESS");
        if (c.maxMoveQwirkles() >= 2) e.add("DOUBLE_TROUBLE");
        if (c.won() && c.allBotsHard()) e.add("GIANT_SLAYER");
        if (c.purpleQwirkle()) e.add("PURELY_PURPLE");
        if (c.star8Qwirkle()) e.add("STAR_GAZER");
        if (c.totalGames() >= 100) e.add("CENTURION");
        if (c.bestMove() >= 30) e.add("PERFECT");
        if (c.humanScore() >= 200) e.add("DOUBLE_CENTURY");
        if (c.held6Colour()) e.add("FULL_HOUSE");
        if (c.held3Same()) e.add("HOARDER");
        if (c.heldQwirkleRack()) e.add("HOLD_QWIRKLE");
        if (c.maxConsecPasses() >= 3) e.add("PACIFIST");
        if (c.blitz()) e.add("BLITZ");
        if (c.won() && c.network()) e.add("NETWORKER");
        if (c.won() && c.network() && c.marginOverSecond() >= 30) e.add("NET_CRUSHER");
        if (c.humanScore() >= 150) e.add("SESQUI");
        if (c.won() && c.wentOut()) e.add("GO_OUT");
        if (c.maxSwapSize() >= 6) e.add("FULL_SWAP");
        if (c.quirklesThisGame() >= 3) e.add("TRIPLE_QWIRKLE");
        if (c.winStreak() >= 5) e.add("ON_FIRE");
        if (c.totalGames() >= 10) e.add("GETTING_STARTED");
        if (c.totalGames() >= 25) e.add("REGULAR");
        if (c.level() >= 5) e.add("LEVEL_5");
        if (c.level() >= 10) e.add("LEVEL_10");
        if (c.level() >= 20) e.add("LEVEL_20");
        if (c.level() >= 50) e.add("LEVEL_50");
        if (c.level() >= 100) e.add("LEVEL_100");
        return e;
    }

    public static Def byCode(String code) { for (Def d : ALL) if (d.code().equals(code)) return d; return null; }

    /** All achievements as JSON, marking which are unlocked and when. */
    public static String allJson(java.util.Map<String,String> unlockedAt) {
        StringBuilder b = new StringBuilder("[");
        for (int i = 0; i < ALL.size(); i++) {
            Def d = ALL.get(i);
            boolean unl = unlockedAt.containsKey(d.code());
            String at = unl ? unlockedAt.get(d.code()) : null;
            if (i > 0) b.append(',');
            b.append("{\"code\":\"").append(d.code()).append('"')
             .append(",\"name\":\"").append(Json.esc(d.name())).append('"')
             .append(",\"desc\":\"").append(Json.esc(d.desc())).append('"')
             .append(",\"difficulty\":").append(d.difficulty())
             .append(",\"impl\":").append(d.impl())
             .append(",\"unlocked\":").append(unl)
             .append(",\"unlockedAt\":").append(at == null ? "null" : "\"" + Json.esc(at) + "\"").append('}');
        }
        return b.append(']').toString();
    }
}
