package uk.co.donotpassgo.quirkle.service;

/** A service error carrying an HTTP status for the adapter to surface. */
public final class GameException extends RuntimeException {
    public final int status;
    public GameException(int status, String message) { super(message); this.status = status; }
    public static GameException notFound(String m) { return new GameException(404, m); }
    public static GameException forbidden(String m) { return new GameException(403, m); }
    public static GameException badRequest(String m) { return new GameException(400, m); }
    public static GameException conflict(String m) { return new GameException(409, m); }
}
