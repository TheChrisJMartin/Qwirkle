package uk.co.donotpassgo.quirkle.service;

import java.util.*;

/** Progressive "Quirkle Levels" ladder: 100 levels, each a win plus escalating criteria. */
public final class Levels {
    public static final int MAX = 100;
    public record Req(int level, String objective, int margin, int score, int quirkles, int best,
                      boolean flawless, boolean noSwap, boolean finisher, String botDifficulty) {}
    private static final Req[] L = new Req[]{
        new Req(1, "Win a game", 0, 0, 0, 0, false, false, false, "easy"),
        new Req(2, "Win a game with a lead of 20+ points", 20, 0, 0, 0, false, false, false, "easy"),
        new Req(3, "Win a game playing 1+ Qwirkle", 0, 0, 1, 0, false, false, false, "easy"),
        new Req(4, "Win a game with a single move of 10+ points", 0, 0, 0, 10, false, false, false, "easy"),
        new Req(5, "Win a game scoring 44+ points, without missing a Qwirkle", 0, 44, 0, 0, true, false, false, "easy"),
        new Req(6, "Win a game scoring 44+ points, without swapping", 0, 44, 0, 0, false, true, false, "easy"),
        new Req(7, "Win a game scoring 39+ points, and empty the bag yourself", 0, 39, 0, 0, false, false, true, "easy"),
        new Req(8, "Win a game scoring 66+ points", 0, 66, 0, 0, false, false, false, "easy"),
        new Req(9, "Win a game with a lead of 20+ points", 20, 0, 0, 0, false, false, false, "easy"),
        new Req(10, "Win a game playing 2+ Qwirkles", 0, 0, 2, 0, false, false, false, "easy"),
        new Req(11, "Win a game with a single move of 11+ points", 0, 0, 0, 11, false, false, false, "easy"),
        new Req(12, "Win a game scoring 49+ points, without missing a Qwirkle", 0, 49, 0, 0, true, false, false, "easy"),
        new Req(13, "Win a game scoring 50+ points, without swapping", 0, 50, 0, 0, false, true, false, "easy"),
        new Req(14, "Win a game scoring 43+ points, and empty the bag yourself", 0, 43, 0, 0, false, false, true, "easy"),
        new Req(15, "Win a game scoring 76+ points", 0, 76, 0, 0, false, false, false, "easy"),
        new Req(16, "Win a game with a lead of 24+ points", 24, 0, 0, 0, false, false, false, "easy"),
        new Req(17, "Win a game playing 2+ Qwirkles", 0, 0, 2, 0, false, false, false, "easy"),
        new Req(18, "Win a game with a single move of 13+ points", 0, 0, 0, 13, false, false, false, "easy"),
        new Req(19, "Win a game scoring 55+ points, without missing a Qwirkle", 0, 55, 0, 0, true, false, false, "easy"),
        new Req(20, "Win a game with a lead of 40+ points", 40, 0, 0, 0, false, false, false, "easy"),
        new Req(21, "Win a game scoring 47+ points, and empty the bag yourself", 0, 47, 0, 0, false, false, true, "easy"),
        new Req(22, "Win a game scoring 86+ points", 0, 86, 0, 0, false, false, false, "easy"),
        new Req(23, "Win a game with a lead of 28+ points", 28, 0, 0, 0, false, false, false, "easy"),
        new Req(24, "Win a game playing 2+ Qwirkles", 0, 0, 2, 0, false, false, false, "easy"),
        new Req(25, "Win a game with a single move of 14+ points", 0, 0, 0, 14, false, false, false, "easy"),
        new Req(26, "Win a game scoring 60+ points, without missing a Qwirkle", 0, 60, 0, 0, true, false, false, "medium"),
        new Req(27, "Win a game scoring 61+ points, without swapping", 0, 61, 0, 0, false, true, false, "medium"),
        new Req(28, "Win a game scoring 51+ points, and empty the bag yourself", 0, 51, 0, 0, false, false, true, "medium"),
        new Req(29, "Win a game scoring 96+ points", 0, 96, 0, 0, false, false, false, "medium"),
        new Req(30, "Win a game scoring 120+ points", 0, 120, 0, 0, false, false, false, "medium"),
        new Req(31, "Win a game playing 3+ Qwirkles", 0, 0, 3, 0, false, false, false, "medium"),
        new Req(32, "Win a game with a single move of 15+ points", 0, 0, 0, 15, false, false, false, "medium"),
        new Req(33, "Win a game scoring 66+ points, without missing a Qwirkle", 0, 66, 0, 0, true, false, false, "medium"),
        new Req(34, "Win a game scoring 67+ points, without swapping", 0, 67, 0, 0, false, true, false, "medium"),
        new Req(35, "Win a game scoring 56+ points, and empty the bag yourself", 0, 56, 0, 0, false, false, true, "medium"),
        new Req(36, "Win a game scoring 105+ points", 0, 105, 0, 0, false, false, false, "medium"),
        new Req(37, "Win a game with a lead of 35+ points", 35, 0, 0, 0, false, false, false, "medium"),
        new Req(38, "Win a game playing 3+ Qwirkles", 0, 0, 3, 0, false, false, false, "medium"),
        new Req(39, "Win a game with a single move of 16+ points", 0, 0, 0, 16, false, false, false, "medium"),
        new Req(40, "Win a game scoring 100+ points, without missing a Qwirkle", 0, 100, 0, 0, true, false, false, "medium"),
        new Req(41, "Win a game scoring 72+ points, without swapping", 0, 72, 0, 0, false, true, false, "medium"),
        new Req(42, "Win a game scoring 60+ points, and empty the bag yourself", 0, 60, 0, 0, false, false, true, "medium"),
        new Req(43, "Win a game scoring 115+ points", 0, 115, 0, 0, false, false, false, "medium"),
        new Req(44, "Win a game with a lead of 39+ points", 39, 0, 0, 0, false, false, false, "medium"),
        new Req(45, "Win a game playing 4+ Qwirkles", 0, 0, 4, 0, false, false, false, "medium"),
        new Req(46, "Win a game with a single move of 17+ points", 0, 0, 0, 17, false, false, false, "medium"),
        new Req(47, "Win a game scoring 77+ points, without missing a Qwirkle", 0, 77, 0, 0, true, false, false, "medium"),
        new Req(48, "Win a game scoring 78+ points, without swapping", 0, 78, 0, 0, false, true, false, "medium"),
        new Req(49, "Win a game scoring 64+ points, and empty the bag yourself", 0, 64, 0, 0, false, false, true, "medium"),
        new Req(50, "Win a game playing 3+ Qwirkles", 0, 0, 3, 0, false, false, false, "medium"),
        new Req(51, "Win a game with a lead of 43+ points", 43, 0, 0, 0, false, false, false, "medium"),
        new Req(52, "Win a game playing 4+ Qwirkles", 0, 0, 4, 0, false, false, false, "medium"),
        new Req(53, "Win a game with a single move of 18+ points", 0, 0, 0, 18, false, false, false, "medium"),
        new Req(54, "Win a game scoring 83+ points, without missing a Qwirkle", 0, 83, 0, 0, true, false, false, "medium"),
        new Req(55, "Win a game scoring 84+ points, without swapping", 0, 84, 0, 0, false, true, false, "medium"),
        new Req(56, "Win a game scoring 68+ points, and empty the bag yourself", 0, 68, 0, 0, false, false, true, "medium"),
        new Req(57, "Win a game scoring 135+ points", 0, 135, 0, 0, false, false, false, "medium"),
        new Req(58, "Win a game with a lead of 47+ points", 47, 0, 0, 0, false, false, false, "medium"),
        new Req(59, "Win a game playing 5+ Qwirkles", 0, 0, 5, 0, false, false, false, "medium"),
        new Req(60, "Win a game with a single move of 20+ points", 0, 0, 0, 20, false, false, false, "medium"),
        new Req(61, "Win a game scoring 88+ points, without missing a Qwirkle", 0, 88, 0, 0, true, false, false, "hard"),
        new Req(62, "Win a game scoring 89+ points, without swapping", 0, 89, 0, 0, false, true, false, "hard"),
        new Req(63, "Win a game scoring 72+ points, and empty the bag yourself", 0, 72, 0, 0, false, false, true, "hard"),
        new Req(64, "Win a game scoring 145+ points", 0, 145, 0, 0, false, false, false, "hard"),
        new Req(65, "Win a game with a lead of 51+ points", 51, 0, 0, 0, false, false, false, "hard"),
        new Req(66, "Win a game playing 5+ Qwirkles", 0, 0, 5, 0, false, false, false, "hard"),
        new Req(67, "Win a game with a single move of 21+ points", 0, 0, 0, 21, false, false, false, "hard"),
        new Req(68, "Win a game scoring 94+ points, without missing a Qwirkle", 0, 94, 0, 0, true, false, false, "hard"),
        new Req(69, "Win a game scoring 95+ points, without swapping", 0, 95, 0, 0, false, true, false, "hard"),
        new Req(70, "Win a game scoring 130+ points, without swapping", 0, 130, 0, 0, false, true, false, "hard"),
        new Req(71, "Win a game scoring 154+ points", 0, 154, 0, 0, false, false, false, "hard"),
        new Req(72, "Win a game with a lead of 55+ points", 55, 0, 0, 0, false, false, false, "hard"),
        new Req(73, "Win a game playing 6+ Qwirkles", 0, 0, 6, 0, false, false, false, "hard"),
        new Req(74, "Win a game with a single move of 22+ points", 0, 0, 0, 22, false, false, false, "hard"),
        new Req(75, "Win a game scoring 100+ points, without missing a Qwirkle", 0, 100, 0, 0, true, false, false, "hard"),
        new Req(76, "Win a game scoring 100+ points, without swapping", 0, 100, 0, 0, false, true, false, "hard"),
        new Req(77, "Win a game scoring 81+ points, and empty the bag yourself", 0, 81, 0, 0, false, false, true, "hard"),
        new Req(78, "Win a game scoring 164+ points", 0, 164, 0, 0, false, false, false, "hard"),
        new Req(79, "Win a game with a lead of 58+ points", 58, 0, 0, 0, false, false, false, "hard"),
        new Req(80, "Win a game with a lead of 40+ points, and empty the bag yourself", 40, 0, 0, 0, false, false, true, "hard"),
        new Req(81, "Win a game with a single move of 23+ points", 0, 0, 0, 23, false, false, false, "hard"),
        new Req(82, "Win a game scoring 105+ points, without missing a Qwirkle", 0, 105, 0, 0, true, false, false, "hard"),
        new Req(83, "Win a game scoring 106+ points, without swapping", 0, 106, 0, 0, false, true, false, "hard"),
        new Req(84, "Win a game scoring 85+ points, and empty the bag yourself", 0, 85, 0, 0, false, false, true, "hard"),
        new Req(85, "Win a game scoring 174+ points", 0, 174, 0, 0, false, false, false, "hard"),
        new Req(86, "Win a game with a lead of 62+ points", 62, 0, 0, 0, false, false, false, "hard"),
        new Req(87, "Win a game playing 7+ Qwirkles", 0, 0, 7, 0, false, false, false, "hard"),
        new Req(88, "Win a game with a single move of 24+ points", 0, 0, 0, 24, false, false, false, "hard"),
        new Req(89, "Win a game scoring 111+ points, without missing a Qwirkle", 0, 111, 0, 0, true, false, false, "hard"),
        new Req(90, "Win a game playing 5+ Qwirkles", 0, 0, 5, 0, false, false, false, "hard"),
        new Req(91, "Win a game scoring 89+ points, and empty the bag yourself", 0, 89, 0, 0, false, false, true, "hard"),
        new Req(92, "Win a game scoring 184+ points", 0, 184, 0, 0, false, false, false, "hard"),
        new Req(93, "Win a game with a lead of 66+ points", 66, 0, 0, 0, false, false, false, "hard"),
        new Req(94, "Win a game playing 7+ Qwirkles", 0, 0, 7, 0, false, false, false, "hard"),
        new Req(95, "Win a game with a single move of 25+ points", 0, 0, 0, 25, false, false, false, "hard"),
        new Req(96, "Win a game scoring 116+ points, without missing a Qwirkle", 0, 116, 0, 0, true, false, false, "hard"),
        new Req(97, "Win a game scoring 117+ points, without swapping", 0, 117, 0, 0, false, true, false, "hard"),
        new Req(98, "Win a game scoring 93+ points, and empty the bag yourself", 0, 93, 0, 0, false, false, true, "hard"),
        new Req(99, "Win a game scoring 194+ points", 0, 194, 0, 0, false, false, false, "hard"),
        new Req(100, "Win a game playing 10+ Qwirkles", 0, 0, 10, 0, false, false, false, "hard"),
    };
    private Levels() {}
    public static int clamp(int level) { return level < 1 ? 1 : (level > MAX ? MAX : level); }
    public static Req at(int level) { return L[clamp(level) - 1]; }
    public static String objective(int level) { return at(level).objective(); }
    public static String botDifficulty(int level) { return at(level).botDifficulty(); }
    public static boolean meets(int level, boolean won, int margin, int score, int quirkles,
                                int best, int missed, int swaps, boolean finisher) {
        Req q = at(level);
        if (!won) return false;
        if (margin < q.margin() || score < q.score() || quirkles < q.quirkles() || best < q.best()) return false;
        if (q.flawless() && missed > 0) return false;
        if (q.noSwap() && swaps > 0) return false;
        if (q.finisher() && !finisher) return false;
        return true;
    }
}