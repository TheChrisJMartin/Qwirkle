package uk.co.donotpassgo.quirkle.service;

import uk.co.donotpassgo.quirkle.ai.AiTurns;
import uk.co.donotpassgo.quirkle.ai.Personalities;
import uk.co.donotpassgo.quirkle.engine.*;
import uk.co.donotpassgo.quirkle.mail.Mailer;
import uk.co.donotpassgo.quirkle.store.Db;
import uk.co.donotpassgo.quirkle.store.GameStore;

import java.io.IOException;
import java.sql.*;
import java.security.SecureRandom;
import java.util.*;

/**
 * Phase-1 "correspondence" multiplayer: humans occupy seats, bots fill the rest and resolve
 * server-side after each human move; players are nudged by email when it becomes their turn.
 * A game is the same event-sourced object as solo play — this only adds membership, invites
 * and notification on top.
 */
public final class NetService {
    private static final Object LOCK = new Object();
    private static final SecureRandom RND = new SecureRandom();
    private NetService() {}

    /* ---------------- create ---------------- */

    /** Host creates a correspondence game: seat 0 is the host, one seat per invited email, then bots. */
    public static String create(long hostUserId, int botCount, String difficulty,
                                List<String> inviteEmails, String linkBase) {
        List<String> invites = new ArrayList<>();
        for (String e : inviteEmails) { String t = e == null ? "" : e.trim(); if (!t.isEmpty()) invites.add(t); }
        int total = 1 + invites.size() + Math.max(0, botCount);
        if (total < 2 || total > 4) throw GameException.badRequest("A game needs 2 to 4 players in total.");
        if (invites.isEmpty()) throw GameException.badRequest("Invite at least one other player.");

        String hostName = userName(hostUserId);
        List<Seat> seats = new ArrayList<>();
        Seat host = Seat.human(hostName == null ? "Host" : hostName);
        host.userId = hostUserId;
        seats.add(host);
        for (String em : invites) seats.add(Seat.human(shortName(em)));   // unclaimed human seats
        String diff = normaliseDifficulty(difficulty);
        List<String> botNames = uk.co.donotpassgo.quirkle.ai.Bots.pick(diff, Math.max(0, botCount), new Random(RND.nextLong()));
        for (int i = 0; i < botCount; i++) seats.add(Seat.ai(botNames.get(i), diff));

        GameState g = GameState.newGame(RND.nextLong(), seats);
        g.kind = "CORRESPONDENCE";
        g.hostUserId = hostUserId;

        synchronized (LOCK) {
            try { GameStore.create(g); } catch (SQLException e) { throw dbError(e); }
            long id = g.id;
            for (int i = 0; i < invites.size(); i++) {
                int seatIndex = 1 + i;
                String token = newToken();
                try { insertInvite(id, seatIndex, invites.get(i), token); } catch (SQLException e) { throw dbError(e); }
                sendInvite(invites.get(i), hostName, linkBase, token);
            }
            AiTurns.playUntilHumanOrEnd(g);          // if the opener is a bot, resolve up to the first human
            try { GameStore.save(g); } catch (SQLException e) { throw dbError(e); }
            return GameService.buildState(g, 0, 0, null, List.of());
        }
    }

    /* ---------------- join ---------------- */

    /** Claim an invited seat. Returns {gameId, seatIndex}. */
    public static long[] join(String token, long userId) {
        if (token == null || token.isBlank()) throw GameException.badRequest("Missing invite token.");
        synchronized (LOCK) {
            try (Connection c = Db.connection()) {
                long gameId; int seat; String status; Long invitedUser;
                try (PreparedStatement ps = c.prepareStatement(
                        "SELECT game_id, seat_index, status FROM game_invite WHERE token=?")) {
                    ps.setString(1, token);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) throw GameException.notFound("This invite link isn't valid.");
                        gameId = rs.getLong(1); seat = rs.getInt(2); status = rs.getString(3);
                    }
                }
                // If this user already holds a seat in this game, just return it (idempotent).
                Integer existing = seatOfInDb(c, gameId, userId);
                if (existing != null) return new long[]{gameId, existing};
                if (!"PENDING".equals(status)) throw GameException.conflict("This invite has already been used.");

                String name = userName(userId);
                try (PreparedStatement ps = c.prepareStatement(
                        "UPDATE game_seat SET user_id=?, name=? WHERE game_id=? AND seat_index=?")) {
                    ps.setLong(1, userId); ps.setString(2, name == null ? "Player" : name);
                    ps.setLong(3, gameId); ps.setInt(4, seat); ps.executeUpdate();
                }
                try (PreparedStatement ps = c.prepareStatement(
                        "UPDATE game_invite SET status='ACCEPTED', invited_user_id=? WHERE token=?")) {
                    ps.setLong(1, userId); ps.setString(2, token); ps.executeUpdate();
                }
                return new long[]{gameId, seat};
            } catch (SQLException e) { throw dbError(e); }
        }
    }

    /* ---------------- play (seat-aware) ---------------- */

    public static String move(long gameId, long userId, String placements, long thinkMs, String linkBase) {
        synchronized (LOCK) {
            GameState g = load(gameId);
            int seat = requireMemberTurn(g, userId);
            Move m;
            try { m = EventCodec.decodeMove(placements == null ? "" : placements); }
            catch (Exception e) { throw GameException.badRequest("Could not read the placement."); }
            if (m.placements().isEmpty()) throw GameException.badRequest("Place at least one tile.");
            int before = g.seats.get(seat).score;
            try { g.applyMove(seat, m); }
            catch (RuntimeException e) { throw GameException.badRequest(clean(e.getMessage())); }
            AiTurns.playUntilHumanOrEnd(g);
            save(g);
            List<Achievements.Def> unlocked = g.status == GameStatus.FINISHED ? UserService.finalizeNetworkGame(g, userId) : List.of();
            return GameService.buildState(g, seat, g.seats.get(seat).score - before, null, unlocked);
        }
    }

    public static String swap(long gameId, long userId, String tilesCsv, String linkBase) {
        synchronized (LOCK) {
            GameState g = load(gameId);
            int seat = requireMemberTurn(g, userId);
            List<Tile> tiles;
            try { tiles = EventCodec.decodeTiles(tilesCsv == null ? "" : tilesCsv); }
            catch (Exception e) { throw GameException.badRequest("Could not read the tiles to swap."); }
            try { g.swap(seat, tiles); }
            catch (RuntimeException e) { throw GameException.badRequest(clean(e.getMessage())); }
            AiTurns.playUntilHumanOrEnd(g);
            save(g);
            List<Achievements.Def> unlocked = g.status == GameStatus.FINISHED ? UserService.finalizeNetworkGame(g, userId) : List.of();
            return GameService.buildState(g, seat, 0, null, unlocked);
        }
    }

    public static String pass(long gameId, long userId, String linkBase) {
        synchronized (LOCK) {
            GameState g = load(gameId);
            int seat = requireMemberTurn(g, userId);
            try { g.pass(seat); }
            catch (RuntimeException e) { throw GameException.badRequest(clean(e.getMessage())); }
            AiTurns.playUntilHumanOrEnd(g);
            save(g);
            List<Achievements.Def> unlocked = g.status == GameStatus.FINISHED ? UserService.finalizeNetworkGame(g, userId) : List.of();
            return GameService.buildState(g, seat, 0, null, unlocked);
        }
    }

    /** Current state from this member's perspective. */
    public static String state(long gameId, long userId) {
        GameState g = load(gameId);
        int seat = seatOf(g, userId);
        if (seat < 0) throw GameException.forbidden("You aren't a player in this game.");
        return GameService.buildState(g, seat, 0, null, List.of());
    }

    /* ---------------- my games ---------------- */

    /** A compact list of the caller's network games. */
    public static String mine(long userId) {
        List<Long> ids = new ArrayList<>();
        try (Connection c = Db.connection();
             PreparedStatement ps = c.prepareStatement(
                 "SELECT DISTINCT s.game_id FROM game_seat s JOIN game g ON g.id = s.game_id " +
                 "WHERE s.user_id=? AND g.status <> 'FINISHED' ORDER BY s.game_id DESC")) {
            ps.setLong(1, userId);
            try (ResultSet rs = ps.executeQuery()) { while (rs.next()) ids.add(rs.getLong(1)); }
        } catch (SQLException e) { throw dbError(e); }

        StringBuilder b = new StringBuilder("{\"games\":[");
        boolean first = true;
        for (long id : ids) {
            GameState g;
            try { g = GameStore.load(id); } catch (SQLException e) { continue; }
            if (g == null) continue;
            int seat = seatOf(g, userId);
            boolean over = g.status == GameStatus.FINISHED;
            boolean yourTurn = !over && g.current == seat;
            String currentName = g.seats.get(g.current).name;
            List<String> others = new ArrayList<>();
            for (int i = 0; i < g.seats.size(); i++) if (i != seat) others.add(g.seats.get(i).name);
            if (!first) b.append(',');
            first = false;
            b.append('{')
             .append("\"id\":").append(id)
             .append(",\"kind\":\"").append(g.kind == null ? "SOLO" : g.kind).append('"')
             .append(",\"status\":\"").append(g.status.name()).append('"')
             .append(",\"yourTurn\":").append(yourTurn)
             .append(",\"yourScore\":").append(g.seats.get(seat).score)
             .append(",\"current\":\"").append(Json.esc(currentName)).append('"')
             .append(",\"opponents\":\"").append(Json.esc(String.join(", ", others))).append('"')
             .append('}');
        }
        b.append("]}");
        return b.toString();
    }

    /* ---------------- helpers ---------------- */

    private static int requireMemberTurn(GameState g, long userId) {
        int seat = seatOf(g, userId);
        if (seat < 0) throw GameException.forbidden("You aren't a player in this game.");
        if (g.status != GameStatus.IN_PROGRESS) throw GameException.conflict("This game is over.");
        if (g.current != seat) throw GameException.conflict("It isn't your turn yet.");
        return seat;
    }

    private static int seatOf(GameState g, long userId) {
        for (int i = 0; i < g.seats.size(); i++) {
            Long uid = g.seats.get(i).userId;
            if (uid != null && uid == userId) return i;
        }
        return -1;
    }

    private static Integer seatOfInDb(Connection c, long gameId, long userId) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(
                "SELECT seat_index FROM game_seat WHERE game_id=? AND user_id=?")) {
            ps.setLong(1, gameId); ps.setLong(2, userId);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? rs.getInt(1) : null; }
        }
    }

    private static void sendInvite(String email, String hostName, String linkBase, String token) {
        String host = hostName == null ? "A friend" : hostName;
        String body = host + " has invited you to a game of Quirkle.\n\n"
                + "Tap to join (sign in or create a free account first):\n"
                + linkBase + "#join=" + token + "\n\n— Quirkle";
        try { Mailer.send(email, host + " invited you to Quirkle", body); } catch (IOException ignored) {}
    }

    private static void insertInvite(long gameId, int seatIndex, String email, String token) throws SQLException {
        try (Connection c = Db.connection();
             PreparedStatement ps = c.prepareStatement(
                 "INSERT INTO game_invite(game_id, seat_index, email, token) VALUES (?,?,?,?)")) {
            ps.setLong(1, gameId); ps.setInt(2, seatIndex); ps.setString(3, email); ps.setString(4, token);
            ps.executeUpdate();
        }
    }

    private static String userName(long id) { return userField(id, "display_name"); }
    private static String userEmail(long id) { return userField(id, "email"); }
    private static String userField(long id, String col) {
        try (Connection c = Db.connection();
             PreparedStatement ps = c.prepareStatement("SELECT " + col + " FROM app_user WHERE id=?")) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? rs.getString(1) : null; }
        } catch (SQLException e) { return null; }
    }

    private static GameState load(long id) {
        GameState g;
        try { g = GameStore.load(id); } catch (SQLException e) { throw dbError(e); }
        if (g == null) throw GameException.notFound("That game doesn't exist.");
        if (!"CORRESPONDENCE".equals(g.kind) && !"LIVE".equals(g.kind))
            throw GameException.badRequest("That isn't a network game.");
        return g;
    }
    private static void save(GameState g) { try { GameStore.save(g); } catch (SQLException e) { throw dbError(e); } }

    private static String shortName(String email) {
        int at = email.indexOf('@');
        String s = at > 0 ? email.substring(0, at) : email;
        return s.length() > 20 ? s.substring(0, 20) : s;
    }
    private static String gameLink(String linkBase, long id) {
        return (linkBase == null ? "" : linkBase) + "#g=" + id;
    }
    private static String newToken() {
        byte[] b = new byte[24]; RND.nextBytes(b);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(b);
    }
    private static String normaliseDifficulty(String d) {
        if (d == null) return "medium";
        String s = d.trim().toLowerCase();
        return (s.equals("easy") || s.equals("medium") || s.equals("hard")) ? s : "medium";
    }
    private static String clean(String m) { return m == null ? "That move isn't legal." : m.replace("java.lang.IllegalStateException:", "").replace("java.lang.IllegalArgumentException:", "").trim(); }
    private static GameException dbError(SQLException e) { return GameException.badRequest("Database error: " + e.getMessage()); }
}
