package uk.co.donotpassgo.quirkle.config;

/** Single configuration surface. Every value comes from an environment variable (set via setenv.sh). */
public final class Config {
    private Config() {}

    public static String get(String key, String def) {
        String v = System.getenv(key);
        return (v == null || v.isBlank()) ? def : v.trim();
    }
    public static String require(String key) {
        String v = System.getenv(key);
        if (v == null || v.isBlank()) throw new IllegalStateException("Missing required environment variable: " + key);
        return v.trim();
    }
    public static int getInt(String key, int def) {
        try { String v = System.getenv(key); return (v == null || v.isBlank()) ? def : Integer.parseInt(v.trim()); }
        catch (NumberFormatException e) { return def; }
    }

    public static String dbUrl()  { return get("QUIRKLE_DB_URL", "jdbc:postgresql://localhost:5432/quirkle"); }
    public static String dbUser() { return get("QUIRKLE_DB_USER", "quirkle"); }
    public static String dbPass() { return get("QUIRKLE_DB_PASS", ""); }
    public static int aiSeatsDefault() { return getInt("QUIRKLE_AI_SEATS_DEFAULT", 3); }

    // SMTP: prefer the bare SMTP_* names, falling back to QUIRKLE_SMTP_* for backward compatibility.
    private static String smtp(String bare, String def) {
        return get(bare, get("QUIRKLE_" + bare, def));
    }
    public static String smtpHost() { return smtp("SMTP_HOST", ""); }
    public static int    smtpPort() {
        String v = get("SMTP_PORT", get("QUIRKLE_SMTP_PORT", "587"));
        try { return Integer.parseInt(v.trim()); } catch (NumberFormatException e) { return 587; }
    }
    public static String smtpUser() { return smtp("SMTP_USER", ""); }
    public static String smtpPass() { return smtp("SMTP_PASS", ""); }
    public static String smtpFrom() { return smtp("SMTP_FROM", "noreply@donotpassgo.co.uk"); }
    /** starttls (587), tls (implicit, 465), or none. */
    public static String smtpTls()  { return smtp("SMTP_TLS", "starttls").toLowerCase(); }
}
