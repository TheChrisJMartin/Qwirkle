package uk.co.donotpassgo.quirkle.auth;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.SecureRandom;
import java.util.Base64;

/** PBKDF2 password hashing (HMAC-SHA256), matching the house convention. */
public final class Passwords {
    private static final int ITERATIONS = 210_000, SALT_BYTES = 16, KEY_BITS = 256;
    private static final SecureRandom RNG = new SecureRandom();
    private Passwords() {}

    public static String hash(String password) {
        byte[] salt = new byte[SALT_BYTES]; RNG.nextBytes(salt);
        byte[] dk = pbkdf2(password.toCharArray(), salt, ITERATIONS);
        return ITERATIONS + ":" + b64(salt) + ":" + b64(dk);
    }

    public static boolean verify(String password, String stored) {
        try {
            String[] p = stored.split(":");
            int iter = Integer.parseInt(p[0]);
            byte[] salt = unb64(p[1]), expected = unb64(p[2]);
            byte[] dk = pbkdf2(password.toCharArray(), salt, iter);
            return constantEquals(dk, expected);
        } catch (Exception e) { return false; }
    }

    private static byte[] pbkdf2(char[] pw, byte[] salt, int iter) {
        try {
            var spec = new PBEKeySpec(pw, salt, iter, KEY_BITS);
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        } catch (Exception e) { throw new IllegalStateException(e); }
    }
    private static boolean constantEquals(byte[] a, byte[] b) {
        if (a.length != b.length) return false;
        int r = 0; for (int i = 0; i < a.length; i++) r |= a[i] ^ b[i]; return r == 0;
    }
    public static String token() { byte[] t = new byte[32]; RNG.nextBytes(t); return b64url(t); }
    private static String b64(byte[] b) { return Base64.getEncoder().encodeToString(b); }
    private static byte[] unb64(String s) { return Base64.getDecoder().decode(s); }
    private static String b64url(byte[] b) { return Base64.getUrlEncoder().withoutPadding().encodeToString(b); }
}
