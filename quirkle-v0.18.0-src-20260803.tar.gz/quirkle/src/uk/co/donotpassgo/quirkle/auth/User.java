package uk.co.donotpassgo.quirkle.auth;

/** A resolved account. */
public record User(long id, String email, String displayName) {}
