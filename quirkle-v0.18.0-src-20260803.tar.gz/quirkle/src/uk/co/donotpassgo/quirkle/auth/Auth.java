package uk.co.donotpassgo.quirkle.auth;

import uk.co.donotpassgo.quirkle.store.Db;
import java.sql.*;
import java.time.OffsetDateTime;

/** Registration, login, session tokens and resolution. Guest use needs none of this. */
public final class Auth {
    public static final int SESSION_DAYS = 30;
    private Auth() {}

    public static User register(String email, String displayName, String password) throws SQLException {
        email = norm(email);
        if (email.isEmpty() || !email.contains("@")) throw new IllegalArgumentException("Enter a valid email.");
        if (password == null || password.length() < 6) throw new IllegalArgumentException("Password must be at least 6 characters.");
        String name = (displayName == null || displayName.isBlank()) ? email.substring(0, email.indexOf('@')) : displayName.trim();
        try (Connection c = Db.connection()) {
            try (PreparedStatement ps = c.prepareStatement("SELECT 1 FROM app_user WHERE email=?")) {
                ps.setString(1, email);
                try (ResultSet rs = ps.executeQuery()) { if (rs.next()) throw new IllegalArgumentException("That email is already registered."); }
            }
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO app_user(email, display_name, pw_hash, verified) VALUES (?,?,?,TRUE) RETURNING id")) {
                ps.setString(1, email); ps.setString(2, name); ps.setString(3, Passwords.hash(password));
                try (ResultSet rs = ps.executeQuery()) { rs.next(); return new User(rs.getLong(1), email, name); }
            }
        }
    }

    public static String login(String email, String password) throws SQLException {
        email = norm(email);
        try (Connection c = Db.connection()) {
            long id; String hash, name;
            try (PreparedStatement ps = c.prepareStatement("SELECT id, pw_hash, display_name FROM app_user WHERE email=?")) {
                ps.setString(1, email);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) throw new IllegalArgumentException("No account for that email.");
                    id = rs.getLong(1); hash = rs.getString(2); name = rs.getString(3);
                }
            }
            if (hash == null || !Passwords.verify(password, hash)) throw new IllegalArgumentException("Wrong email or password.");
            String token = Passwords.token();
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO session_token(token, user_id, expires_at) VALUES (?,?,?)")) {
                ps.setString(1, token); ps.setLong(2, id);
                ps.setObject(3, OffsetDateTime.now().plusDays(SESSION_DAYS));
                ps.executeUpdate();
            }
            try (PreparedStatement ps = c.prepareStatement("UPDATE app_user SET last_login=now() WHERE id=?")) {
                ps.setLong(1, id); ps.executeUpdate();
            }
            return token;
        }
    }

    public static User resolve(String token) {
        if (token == null || token.isBlank()) return null;
        try (Connection c = Db.connection();
             PreparedStatement ps = c.prepareStatement(
                 "SELECT u.id, u.email, u.display_name FROM session_token s JOIN app_user u ON u.id=s.user_id " +
                 "WHERE s.token=? AND s.expires_at > now()")) {
            ps.setString(1, token);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return new User(rs.getLong(1), rs.getString(2), rs.getString(3));
            }
        } catch (SQLException e) { /* treat as guest */ }
        return null;
    }

    /** Create a password-reset token for the email, or null if no such account (no enumeration to callers). */
    public static String createResetToken(String email) throws SQLException {
        email = norm(email);
        try (Connection c = Db.connection()) {
            long id;
            try (PreparedStatement ps = c.prepareStatement("SELECT id FROM app_user WHERE email=?")) {
                ps.setString(1, email);
                try (ResultSet rs = ps.executeQuery()) { if (!rs.next()) return null; id = rs.getLong(1); }
            }
            String token = Passwords.token();
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO password_reset(token, user_id, expires_at) VALUES (?,?,?)")) {
                ps.setString(1, token); ps.setLong(2, id);
                ps.setObject(3, OffsetDateTime.now().plusHours(1));
                ps.executeUpdate();
            }
            return token;
        }
    }

    public static void resetPassword(String token, String newPassword) throws SQLException {
        if (newPassword == null || newPassword.length() < 6) throw new IllegalArgumentException("Password must be at least 6 characters.");
        try (Connection c = Db.connection()) {
            c.setAutoCommit(false);
            long uid;
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT user_id FROM password_reset WHERE token=? AND used=FALSE AND expires_at > now()")) {
                ps.setString(1, token);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) { c.rollback(); throw new IllegalArgumentException("This reset link is invalid or has expired."); }
                    uid = rs.getLong(1);
                }
            }
            try (PreparedStatement ps = c.prepareStatement("UPDATE app_user SET pw_hash=? WHERE id=?")) {
                ps.setString(1, Passwords.hash(newPassword)); ps.setLong(2, uid); ps.executeUpdate();
            }
            try (PreparedStatement ps = c.prepareStatement("UPDATE password_reset SET used=TRUE WHERE token=?")) {
                ps.setString(1, token); ps.executeUpdate();
            }
            try (PreparedStatement ps = c.prepareStatement("DELETE FROM session_token WHERE user_id=?")) {
                ps.setLong(1, uid); ps.executeUpdate();
            }
            c.commit();
        }
    }

    public static void logout(String token) {
        if (token == null) return;
        try (Connection c = Db.connection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM session_token WHERE token=?")) {
            ps.setString(1, token); ps.executeUpdate();
        } catch (SQLException ignored) {}
    }

    private static String norm(String e) { return e == null ? "" : e.trim().toLowerCase(); }
}
