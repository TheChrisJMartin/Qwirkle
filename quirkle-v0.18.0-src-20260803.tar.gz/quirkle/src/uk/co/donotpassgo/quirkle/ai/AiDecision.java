package uk.co.donotpassgo.quirkle.ai;

import uk.co.donotpassgo.quirkle.engine.Move;
import uk.co.donotpassgo.quirkle.engine.Tile;
import java.util.List;

/** What an AI chose to do this turn: play a move, swap tiles, or pass. */
public record AiDecision(String kind, Move move, List<Tile> swapTiles) {
    public static final String PLAY = "PLAY", SWAP = "SWAP", PASS = "PASS";
    public static AiDecision play(Move m) { return new AiDecision(PLAY, m, null); }
    public static AiDecision swap(List<Tile> t) { return new AiDecision(SWAP, null, t); }
    public static AiDecision pass() { return new AiDecision(PASS, null, null); }
}
