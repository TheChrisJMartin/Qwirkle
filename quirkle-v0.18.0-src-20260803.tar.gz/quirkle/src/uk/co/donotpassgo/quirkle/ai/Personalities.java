package uk.co.donotpassgo.quirkle.ai;

import java.util.*;

/** Named bot personalities. Each preset tunes the base difficulty with two behaviour dials. */
public final class Personalities {
    public record Preset(String difficulty, double missQwirkle, double openness, String blurb) {}
    private Personalities() {}

    public static final String[] ROSTER_NAMES = {"Lexi", "Tilly", "Bob", "Indigo", "Edward"};
    public static final String[] ROSTER_KEYS  = {"sharp", "steady", "casual", "spreader", "wily"};

    private static final Map<String, Preset> PRESETS = new HashMap<>();
    static {
        PRESETS.put("sharp",    new Preset("hard",   0.00, 0.0, "ruthless and greedy"));
        PRESETS.put("steady",   new Preset("medium", 0.00, 0.0, "solid and dependable"));
        PRESETS.put("casual",   new Preset("easy",   0.25, 0.1, "relaxed, often misses Qwirkles"));
        PRESETS.put("spreader", new Preset("medium", 0.00, 0.6, "opens the board out"));
        PRESETS.put("wily",     new Preset("hard",   0.15, 0.2, "strong but occasionally slips"));
    }

    public static Preset get(String key) { return PRESETS.getOrDefault(key == null ? "steady" : key, PRESETS.get("steady")); }
    public static String defaultKeyFor(int index) { return ROSTER_KEYS[index % ROSTER_KEYS.length]; }
    public static String nameFor(int index) { return ROSTER_NAMES[index % ROSTER_NAMES.length]; }
    public static boolean isKey(String k) { return k != null && PRESETS.containsKey(k); }
    public static String keyForName(String name) {
        for (int i = 0; i < ROSTER_NAMES.length; i++) if (ROSTER_NAMES[i].equals(name)) return ROSTER_KEYS[i];
        return "steady";
    }
    public static java.util.List<String> randomNames(int n, java.util.Random rnd) {
        java.util.List<String> names = new java.util.ArrayList<>(java.util.Arrays.asList(ROSTER_NAMES));
        java.util.Collections.shuffle(names, rnd);
        return new java.util.ArrayList<>(names.subList(0, Math.min(n, names.size())));
    }
}
