package uk.co.donotpassgo.quirkle.ai;

import uk.co.donotpassgo.quirkle.engine.*;
import java.util.*;

/**
 * Enumerates every legal move for a hand on a board, efficiently and completely.
 *
 * A legal move fills every empty cell between its extreme placed cells (otherwise there is a gap),
 * so a move corresponds to a window [start..end] along one axis whose two ends are empty and which
 * contains a board anchor. For each such window we fill all its empty cells, trying only tiles that
 * locally fit each cell (colour/shape against existing neighbours), and confirm with the validator.
 */
public final class LegalMoves {
    private static final int[][] DIRS = {{1,0},{-1,0},{0,1},{0,-1}};
    private LegalMoves() {}

    public static List<Move> enumerate(Board board, List<Tile> hand) {
        Map<String, Move> out = new LinkedHashMap<>();
        List<Tile> tiles = distinct(hand);
        if (board.isEmpty()) { openingMoves(tiles, out); return new ArrayList<>(out.values()); }

        Set<Coord> anchors = boardAdjacentEmpties(board);
        int maxLen = Math.min(6, tiles.size());
        for (Axis axis : Axis.values()) {
            for (Coord a : anchors) {
                int aAlong = along(a, axis);
                for (int s = aAlong - (maxLen - 1); s <= aAlong; s++) {
                    for (int e = aAlong; e <= s + (maxLen - 1); e++) {
                        if (e < aAlong) continue;
                        Coord startCell = cell(a, axis, s), endCell = cell(a, axis, e);
                        if (board.contains(startCell) || board.contains(endCell)) continue; // ends must be placed
                        List<Coord> empties = new ArrayList<>();
                        boolean ok = true;
                        for (int v = s; v <= e; v++) {
                            Coord c = cell(a, axis, v);
                            if (!board.contains(c)) empties.add(c);
                        }
                        if (empties.isEmpty() || empties.size() > tiles.size()) continue;
                        if (!containsCoord(empties, a)) continue; // anchor must be filled
                        assign(board, empties, 0, tiles, new boolean[tiles.size()], new Placement[empties.size()], out);
                    }
                }
            }
        }
        return new ArrayList<>(out.values());
    }

    // --- assignment of distinct hand tiles to the empty cells of a window ---
    private static void assign(Board board, List<Coord> empties, int idx, List<Tile> tiles,
                               boolean[] used, Placement[] chosen, Map<String, Move> out) {
        if (idx == empties.size()) {
            List<Placement> ps = Arrays.asList(chosen.clone());
            Move m = new Move(new ArrayList<>(ps));
            if (MoveValidator.validate(board, m, false).legal()) out.putIfAbsent(key(ps), m);
            return;
        }
        Coord cell = empties.get(idx);
        for (int i = 0; i < tiles.size(); i++) {
            if (used[i]) continue;
            Tile t = tiles.get(i);
            if (!locallyFits(board, cell, t)) continue;
            used[i] = true; chosen[idx] = new Placement(cell, t);
            assign(board, empties, idx + 1, tiles, used, chosen, out);
            used[i] = false;
        }
    }

    /** Conservative filter: t must be consistent with the existing tiles on both lines through cell. */
    private static boolean locallyFits(Board board, Coord cell, Tile t) {
        for (Axis ax : Axis.values()) {
            List<Tile> line = new ArrayList<>();
            Coord c = cell.step(ax, -1);
            Deque<Tile> left = new ArrayDeque<>();
            while (board.contains(c)) { left.push(board.get(c)); c = c.step(ax, -1); }
            line.addAll(left);
            line.add(t);
            c = cell.step(ax, 1);
            while (board.contains(c)) { line.add(board.get(c)); c = c.step(ax, 1); }
            if (!validLine(line)) return false;
        }
        return true;
    }

    // --- opening (empty board): any valid subset laid along +x from origin ---
    private static void openingMoves(List<Tile> tiles, Map<String, Move> out) {
        int n = tiles.size();
        for (int mask = 1; mask < (1 << n); mask++) {
            List<Tile> subset = new ArrayList<>();
            for (int i = 0; i < n; i++) if ((mask & (1 << i)) != 0) subset.add(tiles.get(i));
            if (!validLine(subset)) continue;
            List<Placement> ps = new ArrayList<>();
            for (int i = 0; i < subset.size(); i++) ps.add(new Placement(new Coord(i, 0), subset.get(i)));
            out.putIfAbsent(key(ps), new Move(ps));
        }
    }

    private static boolean validLine(List<Tile> ts) {
        if (ts.isEmpty() || ts.size() > 6) return false;
        Set<String> seen = new HashSet<>();
        boolean sameColour = true, sameShape = true;
        Colour c0 = ts.get(0).colour(); Shape s0 = ts.get(0).shape();
        for (Tile t : ts) {
            if (!seen.add(t.code())) return false;
            if (t.colour() != c0) sameColour = false;
            if (t.shape() != s0) sameShape = false;
        }
        return sameColour || sameShape;
    }

    // --- geometry helpers ---
    private static int along(Coord c, Axis a) { return a == Axis.HORIZONTAL ? c.x() : c.y(); }
    private static Coord cell(Coord ref, Axis a, int alongVal) {
        return a == Axis.HORIZONTAL ? new Coord(alongVal, ref.y()) : new Coord(ref.x(), alongVal);
    }
    private static boolean containsCoord(List<Coord> cs, Coord c) { for (Coord x : cs) if (x.equals(c)) return true; return false; }

    private static Set<Coord> boardAdjacentEmpties(Board board) {
        Set<Coord> a = new LinkedHashSet<>();
        for (Coord c : board.view().keySet())
            for (int[] d : DIRS) {
                Coord n = new Coord(c.x() + d[0], c.y() + d[1]);
                if (!board.contains(n)) a.add(n);
            }
        return a;
    }

    private static String key(List<Placement> ps) {
        List<Placement> s = new ArrayList<>(ps);
        s.sort((a, b) -> a.coord().x() != b.coord().x()
                ? Integer.compare(a.coord().x(), b.coord().x())
                : Integer.compare(a.coord().y(), b.coord().y()));
        StringBuilder sb = new StringBuilder();
        for (Placement p : s) sb.append(p.coord().x()).append(',').append(p.coord().y()).append(',').append(p.tile().code()).append(';');
        return sb.toString();
    }

    private static List<Tile> distinct(List<Tile> hand) {
        Map<String, Tile> m = new LinkedHashMap<>();
        for (Tile t : hand) m.putIfAbsent(t.code(), t);
        return new ArrayList<>(m.values());
    }
}
