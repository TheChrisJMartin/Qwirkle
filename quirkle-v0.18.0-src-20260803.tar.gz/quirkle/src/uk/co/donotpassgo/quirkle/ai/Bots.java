package uk.co.donotpassgo.quirkle.ai;

import java.util.*;

/** The named-bot roster: each bot has a fixed strategy and a strength tier. A game's difficulty
 *  picks a *mix* of bots whose combined challenge matches easy / medium / hard. */
public final class Bots {
    public record Def(String name, BotBrain brain, int tier, String blurb) {}
    private Bots() {}

    private static final Def[] ROSTER = {
        new Def("Tilly",  BotBrain.MAX_SCORE, 3, "plays the highest-scoring move she can"),
        new Def("Nia",    BotBrain.QWIRKLE,   3, "hunts Qwirkles above all"),
        new Def("Edward", BotBrain.MONO_RUN,  2, "builds the longest run of one colour or shape"),
        new Def("Lexi",   BotBrain.MAX_TILES, 2, "always plays as many tiles as she can"),
        new Def("Freda",  BotBrain.OPENER,    2, "opens the board right up"),
        new Def("Indigo", BotBrain.CLOSER,    2, "keeps the board tight and compact"),
        new Def("Bob",    BotBrain.RANDOM,    1, "plays casually — anything legal"),
    };
    private static final Map<String, Def> BY_NAME = new HashMap<>();
    static { for (Def d : ROSTER) BY_NAME.put(d.name(), d); }

    // Difficulty pools: which bots may appear at each level (the mix decides the challenge).
    private static final String[] EASY   = {"Bob", "Lexi", "Freda", "Indigo"};
    private static final String[] MEDIUM = {"Lexi", "Edward", "Freda", "Indigo"};
    private static final String[] HARD   = {"Tilly", "Nia", "Edward", "Freda"};

    public static BotBrain strategyFor(String name) {
        Def d = name == null ? null : BY_NAME.get(name);
        return d == null ? BotBrain.MAX_SCORE : d.brain();
    }
    public static String blurb(String name) { Def d = BY_NAME.get(name); return d == null ? "" : d.blurb(); }
    public static boolean isBot(String name) { return name != null && BY_NAME.containsKey(name); }

    /** Public roster for the About/Help screen. */
    public static String rosterJson() {
        StringBuilder b = new StringBuilder("[");
        for (int i = 0; i < ROSTER.length; i++) {
            Def d = ROSTER[i];
            if (i > 0) b.append(',');
            b.append("{\"name\":\"").append(d.name()).append("\",\"blurb\":\"").append(d.blurb())
             .append("\",\"tier\":").append(d.tier()).append('}');
        }
        return b.append(']').toString();
    }

    /** Pick a mix of distinct bot names for a game of the given difficulty. */
    public static List<String> pick(String difficulty, int count, Random rnd) {
        String[] pool = switch (difficulty == null ? "medium" : difficulty.toLowerCase()) {
            case "easy" -> EASY; case "hard" -> HARD; default -> MEDIUM;
        };
        List<String> bag = new ArrayList<>(Arrays.asList(pool));
        Collections.shuffle(bag, rnd);
        List<String> out = new ArrayList<>();
        for (int i = 0; i < count; i++) out.add(bag.get(i % bag.size()));
        return out;
    }
}
