package uk.co.donotpassgo.quirkle.ai;

import uk.co.donotpassgo.quirkle.engine.*;
import java.util.*;

/** Drives AI seats: applies one AI turn, or plays through consecutive AI seats until a human or game end. */
public final class AiTurns {
    private AiTurns() {}

    /** Play the current seat (which must be an AI) and return a short narration line. */
    public static String playOne(GameState g) {
        int si = g.current;
        Seat seat = g.seats.get(si);
        if (!seat.ai) throw new IllegalStateException("Current seat is not an AI");
        int before = seat.score;
        AiDecision d = Ai.forSeat(seat, g.seed).decide(g, si);
        switch (d.kind()) {
            case AiDecision.PLAY -> {
                g.applyMove(si, d.move());
                return seat.name + " played " + d.move().size() + " tile(s) for " + (seat.score - before) + ".";
            }
            case AiDecision.SWAP -> {
                g.swap(si, d.swapTiles());
                return seat.name + " swapped " + d.swapTiles().size() + " tile(s).";
            }
            default -> {
                g.pass(si);
                return seat.name + " passed.";
            }
        }
    }

    /** Advance through any AI seats until it is a human's turn or the game ends. Returns narration lines. */
    public static List<String> playUntilHumanOrEnd(GameState g) {
        List<String> notes = new ArrayList<>();
        int guard = 0;
        while (g.status == GameStatus.IN_PROGRESS && g.seats.get(g.current).ai && guard++ < 10000) {
            notes.add(playOne(g));
        }
        return notes;
    }
}
