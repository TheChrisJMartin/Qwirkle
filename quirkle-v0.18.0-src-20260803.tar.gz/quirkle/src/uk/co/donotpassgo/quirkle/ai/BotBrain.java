package uk.co.donotpassgo.quirkle.ai;

import uk.co.donotpassgo.quirkle.engine.*;
import java.util.*;

/** A bot's fixed playing objective. Each named bot always plays one of these. */
public enum BotBrain {
    MAX_SCORE,   // highest-scoring move
    MAX_TILES,   // place as many tiles as possible
    MONO_RUN,    // build the longest single line (most of one colour or shape)
    OPENER,      // open the board up (create the most new space)
    CLOSER,      // keep the board tight (create the least new space)
    QWIRKLE,     // complete a Qwirkle whenever possible
    RANDOM;      // casual — any legal move

    /** Choose among legal, non-empty moves. */
    public Move choose(Board board, List<Move> moves, Random rnd) {
        if (this == RANDOM || moves.size() == 1) return moves.get(rnd.nextInt(moves.size()));
        Move best = null; double bestP = Double.NEGATIVE_INFINITY; int bestScore = -1;
        boolean opening = board.isEmpty();
        for (Move m : moves) {
            ValidationResult vr = MoveValidator.validate(board, m, opening);
            if (!vr.legal()) continue;
            int sc = Scorer.score(vr, m);
            double p = primary(board, m, vr, sc);
            if (p > bestP || (p == bestP && sc > bestScore) || (p == bestP && sc == bestScore && rnd.nextBoolean())) {
                bestP = p; bestScore = sc; best = m;
            }
        }
        return best != null ? best : moves.get(rnd.nextInt(moves.size()));
    }

    private double primary(Board b, Move m, ValidationResult vr, int sc) {
        switch (this) {
            case MAX_SCORE: return sc;
            case MAX_TILES: return m.size();
            case MONO_RUN:  return longestLine(vr);
            case QWIRKLE:   return qwirkles(vr) * 1000 + sc;   // strongly prefer completing a Qwirkle
            case OPENER:    return frontier(b, m);
            case CLOSER:    return -frontier(b, m);
            default:        return sc;
        }
    }

    private static int longestLine(ValidationResult vr) {
        int mx = 0; for (Line l : vr.scoringLines()) mx = Math.max(mx, l.length()); return mx;
    }
    private static int qwirkles(ValidationResult vr) {
        int q = 0; for (Line l : vr.scoringLines()) if (l.length() == 6) q++; return q;
    }
    /** Count of empty cells orthogonally adjacent to any tile after the move — a measure of how "open" the board is. */
    private static int frontier(Board b, Move m) {
        Board c = b.copy();
        for (Placement p : m.placements()) c.place(p.coord(), p.tile());
        Set<Coord> empties = new HashSet<>();
        int[][] d = {{1,0},{-1,0},{0,1},{0,-1}};
        for (Coord o : c.view().keySet())
            for (int[] dd : d) { Coord n = new Coord(o.x()+dd[0], o.y()+dd[1]); if (!c.contains(n)) empties.add(n); }
        return empties.size();
    }
}
