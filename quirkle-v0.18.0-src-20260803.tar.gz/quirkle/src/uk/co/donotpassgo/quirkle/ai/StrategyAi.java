package uk.co.donotpassgo.quirkle.ai;

import uk.co.donotpassgo.quirkle.engine.*;
import java.util.*;

/** An AI that always plays a single fixed strategy — except the opening move, which is always the
 *  strongest line available so a starter uses the full line that justified it going first. */
public final class StrategyAi implements AiPlayer {
    private final BotBrain brain;
    private final long salt;
    public StrategyAi(BotBrain brain, long salt) { this.brain = brain == null ? BotBrain.MAX_SCORE : brain; this.salt = salt; }

    @Override
    public AiDecision decide(GameState g, int seatIndex) {
        Seat seat = g.seats.get(seatIndex);
        List<Move> moves = LegalMoves.enumerate(g.board, seat.hand);
        Random rnd = new Random(salt * 1000003L + seatIndex * 31L + g.events.size());
        if (moves.isEmpty()) {
            if (!g.bag.isEmpty() && !seat.hand.isEmpty()) return AiDecision.swap(new ArrayList<>(seat.hand));
            return AiDecision.pass();
        }
        BotBrain use = g.board.isEmpty() ? BotBrain.MAX_SCORE : brain;   // always open strongly
        return AiDecision.play(use.choose(g.board, moves, rnd));
    }
}
