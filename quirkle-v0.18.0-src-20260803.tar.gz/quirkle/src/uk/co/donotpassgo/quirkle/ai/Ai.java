package uk.co.donotpassgo.quirkle.ai;

/** Factory for AI strategies by difficulty and personality preset. */
public final class Ai {
    private Ai() {}
    /** Build the AI for a seat: a named-bot fixed strategy, unless an explicit persona key is set (custom games). */
    public static AiPlayer forSeat(uk.co.donotpassgo.quirkle.engine.Seat seat, long salt) {
        if (seat.personality != null && Personalities.isKey(seat.personality))
            return of(seat.aiDifficulty, seat.personality, salt);
        return new StrategyAi(Bots.strategyFor(seat.name), salt + (seat.name == null ? 0 : seat.name.hashCode()));
    }

    public static AiPlayer of(String difficulty, String personality, long salt) {
        Personalities.Preset p = Personalities.get(personality);
        return new HeuristicAi(difficulty, p.missQwirkle(), p.openness(), salt);
    }
}
