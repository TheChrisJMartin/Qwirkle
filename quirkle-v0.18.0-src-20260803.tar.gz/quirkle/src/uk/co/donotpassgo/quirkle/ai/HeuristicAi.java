package uk.co.donotpassgo.quirkle.ai;

import uk.co.donotpassgo.quirkle.engine.*;
import java.util.*;

/**
 * Baseline AI with difficulty tiers plus two personality dials:
 *  - missQwirkle: chance of declining a Qwirkle-completing move when a decent alternative exists;
 *  - openness: preference for moves that expand the board's frontier.
 */
public final class HeuristicAi implements AiPlayer {
    private final String difficulty;
    private final double missQwirkle, openness;
    private final long salt;

    public HeuristicAi(String difficulty, double missQwirkle, double openness, long salt) {
        this.difficulty = difficulty == null ? "medium" : difficulty.toLowerCase();
        this.missQwirkle = missQwirkle; this.openness = openness; this.salt = salt;
    }

    @Override
    public AiDecision decide(GameState g, int seatIndex) {
        Seat seat = g.seats.get(seatIndex);
        List<Move> moves = LegalMoves.enumerate(g.board, seat.hand);
        Random rnd = new Random(salt * 1000003L + seatIndex * 31L + g.events.size());
        if (moves.isEmpty()) {
            if (!g.bag.isEmpty() && !seat.hand.isEmpty()) return AiDecision.swap(new ArrayList<>(seat.hand));
            return AiDecision.pass();
        }
        // Easy bots play randomly — except the opening move, which should use the longest line
        // that justified the starting-player choice, so an opener actually plays its full line.
        if ("easy".equals(difficulty) && !g.board.isEmpty()) return AiDecision.play(moves.get(rnd.nextInt(moves.size())));

        int[] bb = bbox(g.board);
        Move best = null, bestNonQ = null;
        int bestVal = Integer.MIN_VALUE, bestNonQVal = Integer.MIN_VALUE;
        boolean bestIsQ = false;
        for (Move m : moves) {
            ValidationResult vr = MoveValidator.validate(g.board, m, g.board.isEmpty());
            int score = Scorer.score(vr, m);
            boolean isQ = false, open5 = false;
            for (Line l : vr.scoringLines()) { if (l.length() == 6) isQ = true; if (l.length() == 5) open5 = true; }
            int val = score;
            if ("hard".equals(difficulty) && open5) val -= 3;                 // defensive
            if (openness > 0 && expands(m, bb)) val += (int) Math.round(openness * 4);
            if (val > bestVal || (val == bestVal && rnd.nextBoolean())) { bestVal = val; best = m; bestIsQ = isQ; }
            if (!isQ && val > bestNonQVal) { bestNonQVal = val; bestNonQ = m; }
        }
        if (bestIsQ && missQwirkle > 0 && bestNonQ != null && rnd.nextDouble() < missQwirkle) return AiDecision.play(bestNonQ);
        return AiDecision.play(best);
    }

    private static int[] bbox(Board b) {
        if (b.isEmpty()) return null;
        int minx = Integer.MAX_VALUE, miny = Integer.MAX_VALUE, maxx = Integer.MIN_VALUE, maxy = Integer.MIN_VALUE;
        for (Coord c : b.view().keySet()) {
            minx = Math.min(minx, c.x()); maxx = Math.max(maxx, c.x());
            miny = Math.min(miny, c.y()); maxy = Math.max(maxy, c.y());
        }
        return new int[]{minx, miny, maxx, maxy};
    }
    private static boolean expands(Move m, int[] bb) {
        if (bb == null) return false;
        for (Placement p : m.placements())
            if (p.coord().x() < bb[0] || p.coord().x() > bb[2] || p.coord().y() < bb[1] || p.coord().y() > bb[3]) return true;
        return false;
    }
}
