package uk.co.donotpassgo.quirkle.ai;

import uk.co.donotpassgo.quirkle.engine.GameState;

/** A strategy that decides an AI seat's turn. */
public interface AiPlayer {
    AiDecision decide(GameState g, int seatIndex);
}
