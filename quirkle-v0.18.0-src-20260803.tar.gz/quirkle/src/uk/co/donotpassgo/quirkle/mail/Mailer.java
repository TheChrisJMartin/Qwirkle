package uk.co.donotpassgo.quirkle.mail;

import uk.co.donotpassgo.quirkle.config.Config;

import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;

/**
 * Dependency-free SMTP client supporting STARTTLS (port 587), implicit TLS (465) and plain.
 * Uses AUTH LOGIN when a username is configured. Configuration comes from the SMTP_* variables.
 */
public final class Mailer {
    private Mailer() {}

    public static void send(String to, String subject, String body) throws IOException {
        String host = Config.smtpHost();
        if (host.isBlank()) throw new IOException("SMTP_HOST is not configured");
        int port = Config.smtpPort();
        String mode = Config.smtpTls();      // starttls | tls | none
        String user = Config.smtpUser();
        String pass = Config.smtpPass();
        String from = Config.smtpFrom();

        Socket socket = "tls".equals(mode)
                ? ((SSLSocketFactory) SSLSocketFactory.getDefault()).createSocket(host, port)
                : new Socket(host, port);
        try {
            SmtpChannel ch = new SmtpChannel(socket);
            ch.expect(220);
            ch.cmd("EHLO donotpassgo.co.uk", 250);

            if ("starttls".equals(mode)) {
                ch.cmd("STARTTLS", 220);
                SSLSocket tls = (SSLSocket) ((SSLSocketFactory) SSLSocketFactory.getDefault())
                        .createSocket(socket, host, port, true);
                tls.startHandshake();
                ch = new SmtpChannel(tls);
                ch.cmd("EHLO donotpassgo.co.uk", 250);
                socket = tls;
            }

            if (!user.isBlank()) {
                ch.cmd("AUTH LOGIN", 334);
                ch.cmd(b64(user), 334);
                ch.cmd(b64(pass), 235);
            }

            ch.cmd("MAIL FROM:<" + from + ">", 250);
            ch.cmd("RCPT TO:<" + to + ">", 250);
            ch.cmd("DATA", 354);

            String date = OffsetDateTime.now().format(DateTimeFormatter.RFC_1123_DATE_TIME);
            StringBuilder msg = new StringBuilder();
            msg.append("From: ").append(from).append("\r\n");
            msg.append("To: ").append(to).append("\r\n");
            msg.append("Subject: ").append(subject).append("\r\n");
            msg.append("Date: ").append(date).append("\r\n");
            msg.append("MIME-Version: 1.0\r\n");
            msg.append("Content-Type: text/plain; charset=UTF-8\r\n");
            msg.append("\r\n");
            msg.append(dotStuff(body)).append("\r\n");
            ch.raw(msg.toString());
            ch.cmd(".", 250);
            ch.cmd("QUIT", 221);
        } finally {
            try { socket.close(); } catch (IOException ignored) {}
        }
    }

    private static String b64(String s) { return Base64.getEncoder().encodeToString(s.getBytes(StandardCharsets.UTF_8)); }

    /** Escape leading dots per RFC 5321 so a line that is just "." doesn't end DATA early. */
    private static String dotStuff(String body) {
        StringBuilder out = new StringBuilder();
        for (String line : body.replace("\r\n", "\n").split("\n", -1)) {
            if (line.startsWith(".")) out.append('.');
            out.append(line).append("\r\n");
        }
        if (out.length() >= 2) out.setLength(out.length() - 2); // trim trailing CRLF
        return out.toString();
    }

    /** Thin SMTP line protocol over a socket, with reply-code checking. */
    private static final class SmtpChannel {
        private final BufferedReader in;
        private final Writer out;
        SmtpChannel(Socket s) throws IOException {
            in = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
            out = new OutputStreamWriter(s.getOutputStream(), StandardCharsets.UTF_8);
        }
        void raw(String s) throws IOException { out.write(s); out.flush(); }
        void cmd(String line, int expected) throws IOException { raw(line + "\r\n"); expect(expected); }
        void expect(int code) throws IOException {
            String line; int last = -1;
            while ((line = in.readLine()) != null) {
                if (line.length() < 3) throw new IOException("Malformed SMTP reply: " + line);
                last = Integer.parseInt(line.substring(0, 3));
                if (line.length() < 4 || line.charAt(3) != '-') break; // last line of a multi-line reply
            }
            if (last != code) throw new IOException("Expected " + code + " but got " + last);
        }
    }
}
