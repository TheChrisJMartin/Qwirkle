package uk.co.donotpassgo.quirkle.web;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import uk.co.donotpassgo.quirkle.ai.Bots;
import uk.co.donotpassgo.quirkle.service.Achievements;

import java.io.IOException;
import java.util.Collections;

/** Public reference data for the About/Help screen: the achievement catalogue and the bot roster. */
@WebServlet("/api/info")
public final class InfoServlet extends HttpServlet {
    @Override protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String json = "{\"achievements\":" + Achievements.allJson(Collections.emptyMap())
                    + ",\"bots\":" + Bots.rosterJson() + "}";
        resp.setContentType("application/json;charset=UTF-8");
        resp.setStatus(200);
        resp.getWriter().write(json);
    }
}
