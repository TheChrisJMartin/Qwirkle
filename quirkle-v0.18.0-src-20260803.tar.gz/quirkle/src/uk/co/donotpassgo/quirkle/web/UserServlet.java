package uk.co.donotpassgo.quirkle.web;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import uk.co.donotpassgo.quirkle.auth.User;
import uk.co.donotpassgo.quirkle.service.UserService;
import java.io.IOException;

/** Aggregate stats + achievements for the logged-in user. */
@WebServlet("/api/user")
public final class UserServlet extends HttpServlet {
    @Override protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        User u = Sessions.user(req);
        resp.setContentType("application/json;charset=UTF-8");
        if (u == null) { resp.setStatus(401); resp.getWriter().write("{\"error\":\"Not logged in.\"}"); return; }
        try { resp.setStatus(200); resp.getWriter().write(UserService.readJson(u.id())); }
        catch (Exception e) { resp.setStatus(500); resp.getWriter().write("{\"error\":\"Server error.\"}"); }
    }
}
