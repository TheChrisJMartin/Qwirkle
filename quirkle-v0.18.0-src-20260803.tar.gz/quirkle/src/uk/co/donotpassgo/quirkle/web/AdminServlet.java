package uk.co.donotpassgo.quirkle.web;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import uk.co.donotpassgo.quirkle.auth.User;
import uk.co.donotpassgo.quirkle.store.Db;

import java.io.IOException;
import java.sql.*;
import java.util.*;

/** Simple admin dashboard: registered users, last login, games played, level, best score.
 *  Access is limited to emails listed in QUIRKLE_ADMIN_EMAILS (comma-separated). */
@WebServlet("/admin")
public final class AdminServlet extends HttpServlet {

    private static Set<String> admins() {
        Set<String> s = new HashSet<>();
        for (String e : System.getenv().getOrDefault("QUIRKLE_ADMIN_EMAILS", "").split(","))
            if (!e.trim().isEmpty()) s.add(e.trim().toLowerCase());
        return s;
    }

    @Override protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("text/html;charset=UTF-8");
        User u = Sessions.user(req);
        Set<String> admins = admins();
        if (u == null || admins.isEmpty() || !admins.contains(u.email().toLowerCase())) {
            resp.setStatus(403);
            resp.getWriter().write(page("<p class=\"err\">Not authorised. Sign in as an administrator.</p>"));
            return;
        }
        StringBuilder rows = new StringBuilder();
        int total = 0, verified = 0;
        String sql =
            "SELECT u.id, u.email, u.display_name, u.verified, u.created_at, u.last_login, " +
            "  COALESCE(s.games,0), COALESCE(s.wins,0), COALESCE(s.level,1), COALESCE(s.best_score,0) " +
            "FROM app_user u LEFT JOIN user_stats s ON s.user_id = u.id " +
            "ORDER BY u.last_login DESC NULLS LAST, u.id DESC";
        try (Connection c = Db.connection(); PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                total++;
                boolean ver = rs.getBoolean(4); if (ver) verified++;
                rows.append("<tr>")
                    .append(td(String.valueOf(rs.getLong(1))))
                    .append(td(esc(rs.getString(2))))
                    .append(td(esc(rs.getString(3))))
                    .append(td(ver ? "yes" : "no"))
                    .append(td(fmt(rs.getTimestamp(5))))
                    .append(td(fmt(rs.getTimestamp(6))))
                    .append(tdNum(rs.getInt(7)))
                    .append(tdNum(rs.getInt(8)))
                    .append(tdNum(rs.getInt(9)))
                    .append(tdNum(rs.getInt(10)))
                    .append("</tr>");
            }
        } catch (SQLException e) {
            resp.setStatus(500);
            resp.getWriter().write(page("<p class=\"err\">Database error: " + esc(e.getMessage()) + "</p>"));
            return;
        }
        String head = "<div class=\"sum\">" + total + " registered · " + verified + " verified</div>"
            + "<table><thead><tr><th>ID</th><th>Email</th><th>Name</th><th>Verified</th><th>Registered</th>"
            + "<th>Last login</th><th>Games</th><th>Wins</th><th>Level</th><th>Best</th></tr></thead><tbody>"
            + rows + "</tbody></table>";
        resp.setStatus(200);
        resp.getWriter().write(page(head));
    }

    private static String page(String body) {
        return "<!doctype html><html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
            + "<title>Quirkle admin</title><style>"
            + "body{font-family:-apple-system,Segoe UI,Roboto,sans-serif;background:#0c1a16;color:#e9f2ee;margin:0;padding:18px}"
            + "h1{font-size:18px;margin:0 0 4px} .sum{color:#8fa39b;font-size:13px;margin:8px 0 14px}"
            + ".err{color:#e5877f} table{border-collapse:collapse;width:100%;font-size:13px}"
            + "th,td{text-align:left;padding:7px 10px;border-bottom:1px solid #22392f;white-space:nowrap}"
            + "th{color:#8fa39b;font-weight:600;position:sticky;top:0;background:#0c1a16}"
            + "td.n{text-align:right;font-variant-numeric:tabular-nums} tr:hover td{background:rgba(255,255,255,.03)}"
            + "</style></head><body><h1>Quirkle — admin</h1>" + body + "</body></html>";
    }
    private static String td(String v) { return "<td>" + (v == null ? "" : v) + "</td>"; }
    private static String tdNum(int v) { return "<td class=\"n\">" + v + "</td>"; }
    private static String fmt(Timestamp t) { return t == null ? "—" : t.toString().substring(0, 16); }
    private static String esc(String s) {
        return s == null ? "" : s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;");
    }
}
