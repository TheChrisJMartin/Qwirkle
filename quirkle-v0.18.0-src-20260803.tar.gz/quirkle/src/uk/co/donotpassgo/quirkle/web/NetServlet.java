package uk.co.donotpassgo.quirkle.web;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import uk.co.donotpassgo.quirkle.auth.User;
import uk.co.donotpassgo.quirkle.service.GameException;
import uk.co.donotpassgo.quirkle.service.NetService;

import java.io.IOException;
import java.util.*;

/**
 * HTTP adapter for Phase-1 correspondence multiplayer.
 *   POST /api/net                    create  (bots, difficulty, invites=a@b,c@d)
 *   POST /api/net/join               join    (token)
 *   GET  /api/net/mine               my games
 *   GET  /api/net/game/{id}          state (my perspective)
 *   POST /api/net/game/{id}/move     placements=x,y,code;...
 *   POST /api/net/game/{id}/swap     tiles=code,code
 *   POST /api/net/game/{id}/pass
 */
@WebServlet(urlPatterns = {"/api/net", "/api/net/*"})
public final class NetServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        try {
            User u = Sessions.user(req);
            if (u == null) { error(resp, 401, "Please log in."); return; }
            String[] p = parts(req);
            if (p.length == 1 && p[0].equals("mine")) { write(resp, 200, NetService.mine(u.id())); return; }
            if (p.length == 2 && p[0].equals("game")) { write(resp, 200, NetService.state(Long.parseLong(p[1]), u.id())); return; }
            error(resp, 404, "Not found.");
        } catch (GameException e) { error(resp, e.status, e.getMessage()); }
        catch (NumberFormatException e) { error(resp, 400, "Bad game id."); }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        try {
            User u = Sessions.user(req);
            if (u == null) { error(resp, 401, "Please log in."); return; }
            String[] p = parts(req);
            String base = linkBase(req);

            if (p.length == 0) {   // create
                int bots = intParam(req, "bots", 0);
                List<String> invites = splitEmails(req.getParameter("invites"));
                write(resp, 200, NetService.create(u.id(), bots, req.getParameter("difficulty"), invites, base));
                return;
            }
            if (p.length == 1 && p[0].equals("join")) {
                long[] r = NetService.join(req.getParameter("token"), u.id());
                GameSockets.notifyUpdate(r[0]);
                write(resp, 200, "{\"gameId\":" + r[0] + ",\"seatIndex\":" + r[1] + "}");
                return;
            }
            if (p.length == 3 && p[0].equals("game")) {
                long id = Long.parseLong(p[1]);
                switch (p[2]) {
                    case "move" -> write(resp, 200, NetService.move(id, u.id(), req.getParameter("placements"), longParam(req, "thinkMs", 0), base));
                    case "swap" -> write(resp, 200, NetService.swap(id, u.id(), req.getParameter("tiles"), base));
                    case "pass" -> write(resp, 200, NetService.pass(id, u.id(), base));
                    default -> { error(resp, 404, "Unknown action."); return; }
                }
                GameSockets.notifyUpdate(id);   // nudge anyone watching to refresh
                return;
            }
            error(resp, 404, "Not found.");
        } catch (GameException e) { error(resp, e.status, e.getMessage()); }
        catch (NumberFormatException e) { error(resp, 400, "Bad game id."); }
    }

    private static List<String> splitEmails(String csv) {
        List<String> out = new ArrayList<>();
        if (csv != null) for (String s : csv.split(",")) { String t = s.trim(); if (!t.isEmpty()) out.add(t); }
        return out;
    }

    private static String linkBase(HttpServletRequest req) {
        String proto = firstNonBlank(req.getHeader("X-Forwarded-Proto"), req.getScheme());
        String host = firstNonBlank(req.getHeader("X-Forwarded-Host"), req.getHeader("Host"), req.getServerName());
        return proto + "://" + host + req.getContextPath() + "/";
    }
    private static String firstNonBlank(String... vs) { for (String v : vs) if (v != null && !v.isBlank()) return v; return ""; }

    private static String[] parts(HttpServletRequest req) {
        String p = req.getPathInfo();
        if (p == null || p.equals("/")) return new String[0];
        String s = p.startsWith("/") ? p.substring(1) : p;
        if (s.isEmpty()) return new String[0];
        return s.split("/");
    }
    private static int intParam(HttpServletRequest req, String n, int d) {
        try { String v = req.getParameter(n); return v == null ? d : Integer.parseInt(v.trim()); } catch (NumberFormatException e) { return d; }
    }
    private static long longParam(HttpServletRequest req, String n, long d) {
        try { String v = req.getParameter(n); return v == null ? d : Long.parseLong(v.trim()); } catch (NumberFormatException e) { return d; }
    }
    private static void write(HttpServletResponse resp, int status, String json) throws IOException {
        resp.setContentType("application/json;charset=UTF-8"); resp.setStatus(status); resp.getWriter().write(json);
    }
    private static void error(HttpServletResponse resp, int status, String msg) throws IOException {
        resp.setContentType("application/json;charset=UTF-8"); resp.setStatus(status);
        resp.getWriter().write("{\"error\":\"" + (msg == null ? "" : msg.replace("\\", "\\\\").replace("\"", "\\\"")) + "\"}");
    }
}
