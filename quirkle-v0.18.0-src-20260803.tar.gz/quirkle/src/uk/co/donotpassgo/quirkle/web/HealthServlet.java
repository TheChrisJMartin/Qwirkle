package uk.co.donotpassgo.quirkle.web;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import uk.co.donotpassgo.quirkle.Version;
import uk.co.donotpassgo.quirkle.store.Db;

import java.io.IOException;
import java.time.Instant;

/** Liveness/readiness probe: build identity plus database reachability. Dependency-free JSON. */
@WebServlet("/api/health")
public final class HealthServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        boolean db = Db.reachable();
        resp.setContentType("application/json;charset=UTF-8");
        resp.setStatus(200);
        String json = "{"
            + "\"status\":\"ok\","
            + "\"app\":\"" + Version.APP + "\","
            + "\"version\":\"" + Version.VERSION + "\","
            + "\"db\":" + db + ","
            + "\"time\":\"" + Instant.now() + "\""
            + "}";
        resp.getWriter().write(json);
    }
}
