package uk.co.donotpassgo.quirkle.web;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import uk.co.donotpassgo.quirkle.auth.Auth;
import uk.co.donotpassgo.quirkle.auth.User;
import java.io.IOException;

/** Register / login / logout / me. Guest use needs none of these. */
@WebServlet("/api/auth/*")
public final class AuthServlet extends HttpServlet {
    @Override protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        if ("/me".equals(req.getPathInfo())) {
            write(resp, 200, "{\"user\":" + Sessions.userJson(Sessions.user(req)) + "}");
        } else error(resp, 404, "Not found.");
    }
    @Override protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String p = req.getPathInfo() == null ? "" : req.getPathInfo();
        try {
            switch (p) {
                case "/register" -> {
                    Auth.register(req.getParameter("email"), req.getParameter("name"), req.getParameter("password"));
                    String token = Auth.login(req.getParameter("email"), req.getParameter("password"));
                    Sessions.set(resp, token);
                    write(resp, 200, "{\"user\":" + Sessions.userJson(Auth.resolve(token)) + "}");
                }
                case "/login" -> {
                    String token = Auth.login(req.getParameter("email"), req.getParameter("password"));
                    Sessions.set(resp, token);
                    write(resp, 200, "{\"user\":" + Sessions.userJson(Auth.resolve(token)) + "}");
                }
                case "/logout" -> { Auth.logout(Sessions.token(req)); Sessions.clear(resp); write(resp, 200, "{\"ok\":true}"); }
                case "/forgot" -> {
                    String email = req.getParameter("email");
                    String token = Auth.createResetToken(email);
                    if (token != null) {
                        String proto = firstNonBlank(req.getHeader("X-Forwarded-Proto"), req.getScheme());
                        String host = firstNonBlank(req.getHeader("X-Forwarded-Host"), req.getHeader("Host"), req.getServerName());
                        String link = proto + "://" + host + req.getContextPath() + "/?reset=" + token;
                        String body = "You asked to reset your Quirkle password.\r\n\r\n" +
                                "Open this link to choose a new one (valid for one hour):\r\n" + link +
                                "\r\n\r\nIf you didn't request this, you can ignore this email.\r\n";
                        try { uk.co.donotpassgo.quirkle.mail.Mailer.send(email.trim(), "Quirkle password reset", body); }
                        catch (Exception mailEx) { error(resp, 500, "Could not send the reset email. Please try again later."); return; }
                    }
                    write(resp, 200, "{\"ok\":true}"); // no account enumeration
                }
                case "/reset" -> {
                    Auth.resetPassword(req.getParameter("token"), req.getParameter("password"));
                    write(resp, 200, "{\"ok\":true}");
                }
                default -> error(resp, 404, "Not found.");
            }
        } catch (IllegalArgumentException e) { error(resp, 400, e.getMessage()); }
        catch (Exception e) { error(resp, 500, "Server error."); }
    }
    private static String firstNonBlank(String... vals) {
        for (String v : vals) if (v != null && !v.isBlank()) return v.split(",")[0].trim();
        return "localhost";
    }
    private static void write(HttpServletResponse r, int s, String j) throws IOException {
        r.setContentType("application/json;charset=UTF-8"); r.setStatus(s); r.getWriter().write(j);
    }
    private static void error(HttpServletResponse r, int s, String m) throws IOException {
        write(r, s, "{\"error\":\"" + uk.co.donotpassgo.quirkle.service.Json.esc(m) + "\"}");
    }
}
