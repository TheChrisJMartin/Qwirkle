package uk.co.donotpassgo.quirkle.web;

import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;
import uk.co.donotpassgo.quirkle.Version;
import uk.co.donotpassgo.quirkle.store.Migrator;
import uk.co.donotpassgo.quirkle.service.TurnNotifier;

/** Runs idempotent database migrations at context start. A DB outage is logged, not fatal, so /api/health still answers. */
@WebListener
public final class BootListener implements ServletContextListener {
    @Override
    public void contextInitialized(ServletContextEvent sce) {
        System.out.println("[quirkle] starting " + Version.APP + " v" + Version.VERSION);
        try {
            Migrator.migrate();
            System.out.println("[quirkle] database migrations applied");
        } catch (Exception e) {
            System.err.println("[quirkle] migration failed (continuing): " + e.getMessage());
        }
        try { TurnNotifier.start(); System.out.println("[quirkle] turn-notifier started"); }
        catch (Exception e) { System.err.println("[quirkle] turn-notifier failed: " + e.getMessage()); }
    }
    @Override
    public void contextDestroyed(ServletContextEvent sce) { try { TurnNotifier.stop(); } catch (Exception ignored) {} }
}
