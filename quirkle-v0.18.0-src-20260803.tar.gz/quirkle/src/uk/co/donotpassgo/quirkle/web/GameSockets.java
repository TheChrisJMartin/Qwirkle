package uk.co.donotpassgo.quirkle.web;

import jakarta.websocket.Session;

import java.io.IOException;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Registry of live WebSocket sessions grouped by game id. The push payload is deliberately tiny —
 * a {@code {"type":"update"}} ping — so no game data flows over the socket; each client then pulls
 * its own perspective-correct state over authenticated HTTP. Keeps the socket layer trivial and
 * avoids leaking another player's hand.
 */
public final class GameSockets {
    private static final Map<Long, Set<Session>> BY_GAME = new ConcurrentHashMap<>();
    private GameSockets() {}

    public static void register(long gameId, Session s) {
        BY_GAME.computeIfAbsent(gameId, k -> ConcurrentHashMap.newKeySet()).add(s);
    }

    public static void unregister(Session s) {
        for (Set<Session> set : BY_GAME.values()) set.remove(s);
    }

    /** Tell everyone watching this game that something changed; they re-fetch their own state. */
    public static void notifyUpdate(long gameId) {
        Set<Session> set = BY_GAME.get(gameId);
        if (set == null) return;
        for (Session s : set) {
            if (s.isOpen()) {
                try { s.getBasicRemote().sendText("{\"type\":\"update\"}"); }
                catch (IOException ignored) {}
            }
        }
    }
}
