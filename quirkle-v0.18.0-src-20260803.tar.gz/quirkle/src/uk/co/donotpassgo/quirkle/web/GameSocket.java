package uk.co.donotpassgo.quirkle.web;

import jakarta.websocket.*;
import jakarta.websocket.server.PathParam;
import jakarta.websocket.server.ServerEndpoint;

/**
 * Live update channel for a game: clients viewing game {id} connect here and receive a lightweight
 * "update" ping whenever the game changes, then pull their own state over HTTP. Moves still go over
 * HTTP (POST /api/net/game/{id}/...), so this endpoint is push-only and carries no game data.
 */
@ServerEndpoint("/ws/game/{id}")
public final class GameSocket {

    @OnOpen
    public void onOpen(Session session, @PathParam("id") String id) {
        try { GameSockets.register(Long.parseLong(id), session); }
        catch (NumberFormatException e) { try { session.close(); } catch (Exception ignored) {} }
    }

    @OnClose
    public void onClose(Session session) { GameSockets.unregister(session); }

    @OnError
    public void onError(Session session, Throwable t) { GameSockets.unregister(session); }

    @OnMessage
    public void onMessage(String message, Session session) {
        // Push-only channel; ignore anything the client sends (moves go over HTTP).
    }
}
