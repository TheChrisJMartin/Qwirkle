package uk.co.donotpassgo.quirkle.web;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import uk.co.donotpassgo.quirkle.service.Levels;
import uk.co.donotpassgo.quirkle.service.Json;
import java.io.IOException;

/** The full level ladder (objectives + bot tier) for the progressive-mode picker. */
@WebServlet("/api/levels")
public final class LevelsServlet extends HttpServlet {
    @Override protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        StringBuilder b = new StringBuilder("[");
        for (int i = 1; i <= Levels.MAX; i++) {
            Levels.Req q = Levels.at(i);
            if (i > 1) b.append(',');
            b.append("{\"level\":").append(i)
             .append(",\"objective\":\"").append(Json.esc(q.objective())).append('"')
             .append(",\"bots\":\"").append(q.botDifficulty()).append("\"}");
        }
        b.append(']');
        resp.setContentType("application/json;charset=UTF-8");
        resp.setStatus(200);
        resp.getWriter().write(b.toString());
    }
}
