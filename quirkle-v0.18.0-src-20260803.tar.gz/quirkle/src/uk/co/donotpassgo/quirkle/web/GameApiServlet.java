package uk.co.donotpassgo.quirkle.web;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import uk.co.donotpassgo.quirkle.service.GameException;
import uk.co.donotpassgo.quirkle.service.GameService;

import java.io.IOException;

/**
 * HTTP adapter over GameService. Requests use form parameters; responses are JSON.
 *   POST /api/game                 create (aiCount, difficulty, name)
 *   GET  /api/game/{id}            state
 *   POST /api/game/{id}/move       placements=x,y,code;...
 *   POST /api/game/{id}/swap       tiles=code,code
 *   POST /api/game/{id}/advance    run pending AI turns
 */
@WebServlet(urlPatterns = {"/api/game", "/api/game/*"})
public final class GameApiServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        try {
            String[] parts = parts(req);
            if (parts.length == 1) { write(resp, 200, GameService.state(Long.parseLong(parts[0]))); return; }
            if (parts.length == 2 && parts[1].equals("stats")) { write(resp, 200, GameService.stats(Long.parseLong(parts[0]))); return; }
            error(resp, 404, "Not found.");
        } catch (GameException e) { error(resp, e.status, e.getMessage()); }
        catch (NumberFormatException e) { error(resp, 400, "Bad game id."); }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        try {
            String[] parts = parts(req);
            if (parts.length == 0) {
                uk.co.donotpassgo.quirkle.auth.User u = Sessions.user(req);
                Long uid = u != null ? u.id() : null;
                String name = req.getParameter("name");
                if ((name == null || name.isBlank()) && u != null) name = u.displayName();
                int ai = intParam(req, "aiCount", 3);
                write(resp, 200, GameService.createGame(uid, ai, req.getParameter("difficulty"), name, req.getParameter("personas"), req.getParameter("names"), req.getParameter("mode"), intParamOrNull(req, "level")));
                return;
            }
            long id = Long.parseLong(parts[0]);
            String action = parts.length > 1 ? parts[1] : "";
            switch (action) {
                case "move" -> write(resp, 200, GameService.move(id, req.getParameter("placements"), longParam(req, "thinkMs", 0)));
                case "swap" -> write(resp, 200, GameService.swap(id, req.getParameter("tiles"), longParam(req, "thinkMs", 0)));
                case "advance" -> write(resp, 200, GameService.advance(id));
                case "pass" -> write(resp, 200, GameService.pass(id));
                default -> error(resp, 404, "Unknown action.");
            }
        } catch (GameException e) { error(resp, e.status, e.getMessage()); }
        catch (NumberFormatException e) { error(resp, 400, "Bad game id."); }
    }

    private static String[] parts(HttpServletRequest req) {
        String p = req.getPathInfo();
        if (p == null || p.equals("/")) return new String[0];
        String trimmed = p.startsWith("/") ? p.substring(1) : p;
        if (trimmed.endsWith("/")) trimmed = trimmed.substring(0, trimmed.length() - 1);
        return trimmed.isEmpty() ? new String[0] : trimmed.split("/");
    }
    private static int intParam(HttpServletRequest req, String name, int def) {
        try { String v = req.getParameter(name); return v == null ? def : Integer.parseInt(v.trim()); }
        catch (NumberFormatException e) { return def; }
    }
    private static Integer intParamOrNull(HttpServletRequest req, String name) {
        try { String v = req.getParameter(name); return (v == null || v.isBlank()) ? null : Integer.valueOf(v.trim()); }
        catch (NumberFormatException e) { return null; }
    }
    private static long longParam(HttpServletRequest req, String name, long def) {
        try { String v = req.getParameter(name); return v == null ? def : Long.parseLong(v.trim()); }
        catch (NumberFormatException e) { return def; }
    }
    private static void write(HttpServletResponse resp, int status, String json) throws IOException {
        resp.setContentType("application/json;charset=UTF-8");
        resp.setStatus(status);
        resp.getWriter().write(json);
    }
    private static void error(HttpServletResponse resp, int status, String msg) throws IOException {
        write(resp, status, "{\"error\":\"" + uk.co.donotpassgo.quirkle.service.Json.esc(msg) + "\"}");
    }
}
