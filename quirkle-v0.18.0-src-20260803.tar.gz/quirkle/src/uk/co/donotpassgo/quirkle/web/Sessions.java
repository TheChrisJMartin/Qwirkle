package uk.co.donotpassgo.quirkle.web;

import jakarta.servlet.http.*;
import uk.co.donotpassgo.quirkle.auth.Auth;
import uk.co.donotpassgo.quirkle.auth.User;

/** Session cookie helpers. */
public final class Sessions {
    public static final String COOKIE = "qk";
    private Sessions() {}

    public static String token(HttpServletRequest req) {
        if (req.getCookies() != null)
            for (Cookie c : req.getCookies()) if (COOKIE.equals(c.getName())) return c.getValue();
        return null;
    }
    public static User user(HttpServletRequest req) { return Auth.resolve(token(req)); }

    public static void set(HttpServletResponse resp, String token) {
        resp.addHeader("Set-Cookie", COOKIE + "=" + token + "; Path=/; HttpOnly; SameSite=Lax; Max-Age=" + (Auth.SESSION_DAYS * 86400));
    }
    public static void clear(HttpServletResponse resp) {
        resp.addHeader("Set-Cookie", COOKIE + "=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0");
    }
    public static String userJson(User u) {
        if (u == null) return "null";
        return "{\"id\":" + u.id() + ",\"email\":\"" + esc(u.email()) + "\",\"displayName\":\"" + esc(u.displayName()) + "\"}";
    }
    static String esc(String s) { return uk.co.donotpassgo.quirkle.service.Json.esc(s); }
}
