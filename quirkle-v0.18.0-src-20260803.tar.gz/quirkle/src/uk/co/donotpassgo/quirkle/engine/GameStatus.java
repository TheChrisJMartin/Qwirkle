package uk.co.donotpassgo.quirkle.engine;

public enum GameStatus { LOBBY, IN_PROGRESS, FINISHED }
