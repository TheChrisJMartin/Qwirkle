package uk.co.donotpassgo.quirkle.engine;

import java.util.*;

/** A player position: a human or an AI, holding a hand and a running score. */
public final class Seat {
    public final String name;
    public final boolean ai;
    public final String aiDifficulty; // null for humans
    public final List<Tile> hand = new ArrayList<>();
    public int score = 0;
    public Long userId = null;      // set for a logged-in human
    public String personality = null; // preset key for AI bots

    public Seat(String name, boolean ai, String aiDifficulty) {
        this.name = name; this.ai = ai; this.aiDifficulty = aiDifficulty;
    }
    public static Seat human(String name) { return new Seat(name, false, null); }
    public static Seat ai(String name, String difficulty) { return new Seat(name, true, difficulty); }
}
