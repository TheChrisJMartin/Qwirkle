package uk.co.donotpassgo.quirkle.engine;

import java.util.List;

/** A player's placement action: one or more tiles laid in a single turn. */
public record Move(List<Placement> placements) {
    public Move { placements = List.copyOf(placements); }
    public int size() { return placements.size(); }
    public static Move of(Placement... ps) { return new Move(List.of(ps)); }
}
