package uk.co.donotpassgo.quirkle.engine;

import java.util.*;

/** Sparse, unbounded board keyed by signed integer coordinates. */
public final class Board {
    private final Map<Coord, Tile> tiles = new HashMap<>();

    public boolean isEmpty() { return tiles.isEmpty(); }
    public int size() { return tiles.size(); }
    public boolean contains(Coord c) { return tiles.containsKey(c); }
    public Tile get(Coord c) { return tiles.get(c); }
    public Map<Coord, Tile> view() { return Collections.unmodifiableMap(tiles); }

    public void place(Coord c, Tile t) {
        if (tiles.containsKey(c)) throw new IllegalStateException("Cell occupied: " + c);
        tiles.put(c, t);
    }

    public Board copy() {
        Board b = new Board();
        b.tiles.putAll(this.tiles);
        return b;
    }

    /** The maximal contiguous run of occupied cells through c along axis a, ordered ascending. */
    public List<Coord> lineCoords(Coord c, Axis a) {
        LinkedList<Coord> run = new LinkedList<>();
        Coord cur = c;
        while (contains(cur)) { run.addFirst(cur); cur = cur.step(a, -1); }
        cur = c.step(a, 1);
        while (contains(cur)) { run.addLast(cur); cur = cur.step(a, 1); }
        return run;
    }

    public List<Tile> tilesAt(List<Coord> coords) {
        List<Tile> ts = new ArrayList<>(coords.size());
        for (Coord c : coords) ts.add(tiles.get(c));
        return ts;
    }
}
