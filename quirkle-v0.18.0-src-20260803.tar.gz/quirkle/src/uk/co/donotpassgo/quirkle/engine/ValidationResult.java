package uk.co.donotpassgo.quirkle.engine;

import java.util.List;

/** Outcome of validating a move: legality, a reason when illegal, and the lines that scored (length >= 2). */
public record ValidationResult(boolean legal, String reason, List<Line> scoringLines) {
    public static ValidationResult illegal(String reason) { return new ValidationResult(false, reason, List.of()); }
    public static ValidationResult ok(List<Line> lines) { return new ValidationResult(true, null, lines); }
}
