package uk.co.donotpassgo.quirkle.engine;

/** The six Qwirkle colours. Each carries a single-character code for compact serialisation. */
public enum Colour {
    RED('r'), ORANGE('o'), YELLOW('y'), GREEN('g'), BLUE('b'), PURPLE('p');

    public final char code;
    Colour(char code) { this.code = code; }

    public static Colour fromCode(char c) {
        for (Colour x : values()) if (x.code == c) return x;
        throw new IllegalArgumentException("Unknown colour code: " + c);
    }
}
