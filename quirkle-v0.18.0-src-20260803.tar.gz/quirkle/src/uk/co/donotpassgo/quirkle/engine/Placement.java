package uk.co.donotpassgo.quirkle.engine;

/** A single tile placed at a coordinate as part of a move. */
public record Placement(Coord coord, Tile tile) {}
