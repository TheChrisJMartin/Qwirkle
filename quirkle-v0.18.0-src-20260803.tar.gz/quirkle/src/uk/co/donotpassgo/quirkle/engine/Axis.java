package uk.co.donotpassgo.quirkle.engine;

/** HORIZONTAL = varying x at constant y (a row); VERTICAL = varying y at constant x (a column). */
public enum Axis {
    HORIZONTAL, VERTICAL;
    public Axis perpendicular() { return this == HORIZONTAL ? VERTICAL : HORIZONTAL; }
}
