package uk.co.donotpassgo.quirkle.engine;

import java.util.*;

/**
 * Enforces every Qwirkle placement rule:
 *  - a move lies on a single row or column;
 *  - placed tiles, with existing tiles, form one contiguous run (no gaps);
 *  - after the first move, the move connects to the existing board;
 *  - every line formed or extended is all one colour with distinct shapes,
 *    or all one shape with distinct colours, with no duplicate tile and no line longer than six.
 */
public final class MoveValidator {
    private static final int[][] NEIGHBOURS = {{1,0},{-1,0},{0,1},{0,-1}};
    private MoveValidator() {}

    public static ValidationResult validate(Board board, Move move, boolean firstMove) {
        List<Placement> ps = move.placements();
        if (ps.isEmpty()) return ValidationResult.illegal("Empty move");

        // Distinct, currently-empty target cells.
        Set<Coord> coords = new HashSet<>();
        for (Placement p : ps) {
            if (!coords.add(p.coord())) return ValidationResult.illegal("Duplicate target cell: " + p.coord());
            if (board.contains(p.coord())) return ValidationResult.illegal("Cell already occupied: " + p.coord());
        }

        // Apply to a scratch board.
        Board temp = board.copy();
        for (Placement p : ps) temp.place(p.coord(), p.tile());

        List<Line> allLines = new ArrayList<>();

        if (ps.size() == 1) {
            Coord c = ps.get(0).coord();
            if (!firstMove && !connected(board, c))
                return ValidationResult.illegal("Move not connected to the board");
            allLines.add(lineAt(temp, c, Axis.HORIZONTAL));
            allLines.add(lineAt(temp, c, Axis.VERTICAL));
        } else {
            boolean sameY = coords.stream().map(Coord::y).distinct().count() == 1;
            boolean sameX = coords.stream().map(Coord::x).distinct().count() == 1;
            Axis axis;
            if (sameY) axis = Axis.HORIZONTAL;
            else if (sameX) axis = Axis.VERTICAL;
            else return ValidationResult.illegal("Tiles are not in a single row or column");

            // Contiguity: no gap between the extreme placed cells along the axis.
            if (!contiguous(temp, coords, axis)) return ValidationResult.illegal("Gap in line");

            // Connection to the existing board (after the first move).
            if (!firstMove) {
                boolean connected = false;
                for (Coord c : coords) if (connected(board, c)) { connected = true; break; }
                if (!connected) return ValidationResult.illegal("Move not connected to the board");
            }

            // Primary line plus each placed tile's perpendicular line.
            allLines.add(lineAt(temp, ps.get(0).coord(), axis));
            for (Placement p : ps) allLines.add(lineAt(temp, p.coord(), axis.perpendicular()));
        }

        // Validate lines; collect scoring lines (length >= 2), de-duplicated.
        Map<String, Line> scoring = new LinkedHashMap<>();
        for (Line line : allLines) {
            String bad = lineProblem(line.tiles());
            if (bad != null) return ValidationResult.illegal(bad + " in line " + line.tiles());
            if (line.length() >= 2) scoring.putIfAbsent(line.key(), line);
        }
        return ValidationResult.ok(new ArrayList<>(scoring.values()));
    }

    private static Line lineAt(Board b, Coord c, Axis a) {
        List<Coord> cs = b.lineCoords(c, a);
        return new Line(a, cs, b.tilesAt(cs));
    }

    private static boolean connected(Board board, Coord c) {
        for (int[] d : NEIGHBOURS) if (board.contains(new Coord(c.x() + d[0], c.y() + d[1]))) return true;
        return false;
    }

    private static boolean contiguous(Board temp, Set<Coord> placed, Axis axis) {
        int lo = Integer.MAX_VALUE, hi = Integer.MIN_VALUE, fixed = 0;
        for (Coord c : placed) {
            int along = axis == Axis.HORIZONTAL ? c.x() : c.y();
            fixed = axis == Axis.HORIZONTAL ? c.y() : c.x();
            lo = Math.min(lo, along); hi = Math.max(hi, along);
        }
        for (int v = lo; v <= hi; v++) {
            Coord cc = axis == Axis.HORIZONTAL ? new Coord(v, fixed) : new Coord(fixed, v);
            if (!temp.contains(cc)) return false;
        }
        return true;
    }

    /** Returns a problem description, or null if the line is valid. Lines of length <= 1 are trivially valid. */
    private static String lineProblem(List<Tile> ts) {
        if (ts.size() <= 1) return null;
        if (ts.size() > 6) return "Line exceeds six tiles";
        Set<String> seen = new HashSet<>();
        boolean sameColour = true, sameShape = true;
        Colour c0 = ts.get(0).colour();
        Shape s0 = ts.get(0).shape();
        for (Tile t : ts) {
            if (!seen.add(t.code())) return "Duplicate tile";
            if (t.colour() != c0) sameColour = false;
            if (t.shape() != s0) sameShape = false;
        }
        if (!sameColour && !sameShape) return "Line mixes colour and shape";
        return null;
    }
}
