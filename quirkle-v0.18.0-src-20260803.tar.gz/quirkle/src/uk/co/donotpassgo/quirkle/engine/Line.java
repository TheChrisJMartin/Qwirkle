package uk.co.donotpassgo.quirkle.engine;

import java.util.List;

/** A contiguous run of tiles along one axis, used for validation and scoring. */
public record Line(Axis axis, List<Coord> coords, List<Tile> tiles) {
    public int length() { return coords.size(); }

    /** Canonical identity: axis plus the two endpoints. Used to de-duplicate lines. */
    public String key() {
        Coord a = coords.get(0), b = coords.get(coords.size() - 1);
        return axis + ":" + a.x() + "," + a.y() + "->" + b.x() + "," + b.y();
    }
}
