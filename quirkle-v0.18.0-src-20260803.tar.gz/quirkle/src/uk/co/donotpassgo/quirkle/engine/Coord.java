package uk.co.donotpassgo.quirkle.engine;

/** A board coordinate on an unbounded, signed integer grid. */
public record Coord(int x, int y) {
    /** Step d cells along the given axis. */
    public Coord step(Axis a, int d) {
        return a == Axis.HORIZONTAL ? new Coord(x + d, y) : new Coord(x, y + d);
    }
    @Override public String toString() { return "(" + x + "," + y + ")"; }
}
