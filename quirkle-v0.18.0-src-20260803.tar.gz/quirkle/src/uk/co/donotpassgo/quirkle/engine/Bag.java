package uk.co.donotpassgo.quirkle.engine;

import java.util.*;

/** The bag of 108 tiles (6 colours x 6 shapes x 3 copies), shuffled from a seed for reproducibility. */
public final class Bag {
    private final List<Tile> tiles = new ArrayList<>();
    private final Random random;

    public Bag(long seed) {
        for (Colour c : Colour.values())
            for (Shape s : Shape.values())
                for (int i = 0; i < 3; i++) tiles.add(new Tile(c, s));
        random = new Random(seed);
        Collections.shuffle(tiles, random);
    }

    public int size() { return tiles.size(); }
    public boolean isEmpty() { return tiles.isEmpty(); }

    public List<Tile> draw(int n) {
        List<Tile> out = new ArrayList<>();
        int k = Math.max(0, Math.min(n, tiles.size()));
        for (int i = 0; i < k; i++) out.add(tiles.remove(tiles.size() - 1));
        return out;
    }

    public void returnTiles(Collection<Tile> t) {
        tiles.addAll(t);
        Collections.shuffle(tiles, random);
    }
}
