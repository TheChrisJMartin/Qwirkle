package uk.co.donotpassgo.quirkle.engine;

/** Result of applying a move: points scored and whether the game ended. */
public record MoveOutcome(int points, boolean gameOver) {}
