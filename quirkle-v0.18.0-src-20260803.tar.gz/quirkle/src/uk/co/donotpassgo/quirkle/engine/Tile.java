package uk.co.donotpassgo.quirkle.engine;

/** An immutable tile: one colour and one shape. Two tiles are equal iff both match. */
public record Tile(Colour colour, Shape shape) {
    /** Two-character code, e.g. "rc" = red circle. */
    public String code() { return "" + colour.code + shape.code; }

    public static Tile parse(String s) {
        if (s == null || s.length() != 2) throw new IllegalArgumentException("Bad tile code: " + s);
        return new Tile(Colour.fromCode(s.charAt(0)), Shape.fromCode(s.charAt(1)));
    }

    @Override public String toString() { return code(); }
}
