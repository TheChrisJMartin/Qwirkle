package uk.co.donotpassgo.quirkle.engine;

import java.util.*;

/** Compact, reversible text encoding of moves and tile lists for the event log. */
public final class EventCodec {
    private EventCodec() {}

    /** Placements as "x,y,code" joined by ';', e.g. "0,0,rc;1,0,rq". */
    public static String encodeMove(Move move) {
        StringBuilder sb = new StringBuilder();
        for (Placement p : move.placements()) {
            if (sb.length() > 0) sb.append(';');
            sb.append(p.coord().x()).append(',').append(p.coord().y()).append(',').append(p.tile().code());
        }
        return sb.toString();
    }

    public static Move decodeMove(String s) {
        List<Placement> ps = new ArrayList<>();
        for (String part : s.split(";")) {
            if (part.isBlank()) continue;
            String[] f = part.split(",");
            ps.add(new Placement(new Coord(Integer.parseInt(f[0]), Integer.parseInt(f[1])), Tile.parse(f[2])));
        }
        return new Move(ps);
    }

    /** Tile codes joined by ',', e.g. "rc,bq". */
    public static String encodeTiles(List<Tile> tiles) {
        StringBuilder sb = new StringBuilder();
        for (Tile t : tiles) { if (sb.length() > 0) sb.append(','); sb.append(t.code()); }
        return sb.toString();
    }

    public static List<Tile> decodeTiles(String s) {
        List<Tile> tiles = new ArrayList<>();
        for (String c : s.split(",")) if (!c.isBlank()) tiles.add(Tile.parse(c.trim()));
        return tiles;
    }
}
