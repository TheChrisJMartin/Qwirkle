package uk.co.donotpassgo.quirkle.engine;

/** Scores a validated move from the lines it forms or extends. */
public final class Scorer {
    private Scorer() {}

    public static int score(ValidationResult vr, Move move) {
        if (vr.scoringLines().isEmpty()) {
            // Lone placement with no line of length >= 2 (only the opening single tile).
            return move.size();
        }
        int points = 0;
        for (Line line : vr.scoringLines()) {
            points += line.length();
            if (line.length() == 6) points += 6; // Qwirkle bonus
        }
        return points;
    }
}
