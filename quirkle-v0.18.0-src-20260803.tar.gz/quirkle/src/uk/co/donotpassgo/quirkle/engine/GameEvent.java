package uk.co.donotpassgo.quirkle.engine;

/** An ordered, replayable record of one action. kind is MOVE, SWAP or PASS; detail encodes the specifics. */
public record GameEvent(int seq, int seatIndex, String kind, String detail) {
    public static final String MOVE = "MOVE";
    public static final String SWAP = "SWAP";
    public static final String PASS = "PASS";
}
