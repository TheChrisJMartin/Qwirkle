package uk.co.donotpassgo.quirkle.engine;

import java.util.*;

/**
 * The full state of a game and the operations that drive it: placing, swapping and passing.
 * The engine is headless and deterministic given a seed; the web layer and AI sit on top of it.
 */
public final class GameState {
    public final long seed;
    public final Board board = new Board();
    public final Bag bag;
    public final List<Seat> seats;
    public int current = 0;
    public GameStatus status = GameStatus.LOBBY;
    public final List<String> log = new ArrayList<>();
    public final List<GameEvent> events = new ArrayList<>();
    public Long id = null; // persistence handle, set once stored
    public long humanThinkMs = 0;
    public int humanThinkMoves = 0;
    public String mode = "free";
    public int level = 0;
    public String kind = "SOLO";        // SOLO | CORRESPONDENCE | LIVE
    public Long hostUserId = null;
    private int seq = 0;
    private int consecutivePasses = 0;

    private void record(int seatIndex, String kind, String detail) {
        events.add(new GameEvent(seq++, seatIndex, kind, detail));
    }

    private GameState(long seed, List<Seat> seats) {
        this.seed = seed;
        this.seats = seats;
        this.bag = new Bag(seed);
    }

    public static GameState newGame(long seed, List<Seat> seats) {
        if (seats == null || seats.size() < 2 || seats.size() > 4)
            throw new IllegalArgumentException("A game needs 2 to 4 seats");
        GameState g = new GameState(seed, seats);
        for (Seat s : seats) s.hand.addAll(g.bag.draw(6));
        g.status = GameStatus.IN_PROGRESS;
        g.current = openingStarter(seats); // Qwirkle rule: whoever can open the longest line starts
        g.log.add("Game started with " + seats.size() + " seats (seed " + seed + ").");
        return g;
    }

    /** Largest opening line playable from a hand (most tiles sharing one attribute). */
    public static int openingCount(java.util.List<Tile> hand) {
        if (hand == null || hand.isEmpty()) return 0;
        int best = 1;
        for (Colour c : Colour.values()) {
            java.util.EnumSet<Shape> sh = java.util.EnumSet.noneOf(Shape.class);
            for (Tile t : hand) if (t.colour() == c) sh.add(t.shape());
            if (sh.size() > best) best = sh.size();
        }
        for (Shape sp : Shape.values()) {
            java.util.EnumSet<Colour> co = java.util.EnumSet.noneOf(Colour.class);
            for (Tile t : hand) if (t.shape() == sp) co.add(t.colour());
            if (co.size() > best) best = co.size();
        }
        return best;
    }
    /** Seat that can open the longest line; ties break to the lowest seat index. */
    public static int openingStarter(java.util.List<Seat> seats) {
        int best = -1, idx = 0;
        for (int i = 0; i < seats.size(); i++) {
            int c = openingCount(seats.get(i).hand);
            if (c > best) { best = c; idx = i; }
        }
        return idx;
    }

    public boolean isFirstMove() { return board.isEmpty(); }
    public Seat currentSeat() { return seats.get(current); }

    /** Total tiles across board, hands and bag. Must always equal 108 (an invariant). */
    public int tileCount() {
        int n = board.size() + bag.size();
        for (Seat s : seats) n += s.hand.size();
        return n;
    }

    public MoveOutcome applyMove(int seatIndex, Move move) {
        requireTurn(seatIndex);
        Seat seat = seats.get(seatIndex);
        if (!handHas(seat.hand, move)) throw new IllegalArgumentException("Tiles not in hand");

        ValidationResult vr = MoveValidator.validate(board, move, isFirstMove());
        if (!vr.legal()) throw new IllegalArgumentException("Illegal move: " + vr.reason());

        int points = Scorer.score(vr, move);
        for (Placement p : move.placements()) board.place(p.coord(), p.tile());
        removeFromHand(seat.hand, move);
        seat.score += points;
        consecutivePasses = 0;
        log.add(seat.name + " scored " + points + " (" + move.size() + " tiles).");
        record(seatIndex, GameEvent.MOVE, EventCodec.encodeMove(move));

        seat.hand.addAll(bag.draw(6 - seat.hand.size()));

        boolean over = false;
        if (bag.isEmpty() && seat.hand.isEmpty()) {
            seat.score += 6;
            over = true;
            status = GameStatus.FINISHED;
            log.add(seat.name + " went out (+6). Game over.");
        }
        if (!over) advance();
        return new MoveOutcome(points, over);
    }

    public void swap(int seatIndex, List<Tile> tiles) {
        requireTurn(seatIndex);
        if (bag.isEmpty()) throw new IllegalStateException("Cannot swap: bag is empty");
        Seat seat = seats.get(seatIndex);
        if (tiles.isEmpty()) throw new IllegalArgumentException("Nothing to swap");
        if (!handHasTiles(seat.hand, tiles)) throw new IllegalArgumentException("Tiles not in hand");
        removeTiles(seat.hand, tiles);
        bag.returnTiles(tiles);
        seat.hand.addAll(bag.draw(tiles.size()));
        consecutivePasses = 0;
        log.add(seat.name + " swapped " + tiles.size() + " tiles.");
        record(seatIndex, GameEvent.SWAP, EventCodec.encodeTiles(tiles));
        advance();
    }

    public void pass(int seatIndex) {
        requireTurn(seatIndex);
        consecutivePasses++;
        log.add(seats.get(seatIndex).name + " passed.");
        record(seatIndex, GameEvent.PASS, "");
        if (consecutivePasses >= seats.size()) {
            status = GameStatus.FINISHED;
            log.add("All players passed. Game over.");
            return;
        }
        advance();
    }

    public List<Seat> standings() {
        List<Seat> s = new ArrayList<>(seats);
        s.sort((a, b) -> Integer.compare(b.score, a.score));
        return s;
    }

    private void advance() { current = (current + 1) % seats.size(); }

    private void requireTurn(int seatIndex) {
        if (status != GameStatus.IN_PROGRESS) throw new IllegalStateException("Game is not in progress");
        if (seatIndex != current) throw new IllegalStateException("Not seat " + seatIndex + "'s turn");
    }

    private static boolean handHas(List<Tile> hand, Move move) {
        List<Tile> pool = new ArrayList<>(hand);
        for (Placement p : move.placements()) if (!pool.remove(p.tile())) return false;
        return true;
    }
    private static boolean handHasTiles(List<Tile> hand, List<Tile> tiles) {
        List<Tile> pool = new ArrayList<>(hand);
        for (Tile t : tiles) if (!pool.remove(t)) return false;
        return true;
    }
    private static void removeFromHand(List<Tile> hand, Move move) {
        for (Placement p : move.placements()) hand.remove(p.tile());
    }
    private static void removeTiles(List<Tile> hand, List<Tile> tiles) {
        for (Tile t : tiles) hand.remove(t);
    }
}
