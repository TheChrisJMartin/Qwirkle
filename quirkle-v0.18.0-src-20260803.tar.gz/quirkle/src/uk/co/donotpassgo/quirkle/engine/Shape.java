package uk.co.donotpassgo.quirkle.engine;

/** The six Qwirkle shapes. Codes are distinct single characters for serialisation. */
public enum Shape {
    CIRCLE('c'), SQUARE('q'), DIAMOND('d'), CLOVER('l'), STAR4('x'), STAR8('e');

    public final char code;
    Shape(char code) { this.code = code; }

    public static Shape fromCode(char c) {
        for (Shape x : values()) if (x.code == c) return x;
        throw new IllegalArgumentException("Unknown shape code: " + c);
    }
}
