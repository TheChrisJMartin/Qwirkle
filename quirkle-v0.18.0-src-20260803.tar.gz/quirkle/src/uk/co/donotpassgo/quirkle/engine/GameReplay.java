package uk.co.donotpassgo.quirkle.engine;

import java.util.*;

/** Rebuilds a game from its seed, seat metadata and ordered event log. The event log is the source of truth. */
public final class GameReplay {
    private GameReplay() {}

    /** seats must be fresh (empty hands); their names/ai/difficulty are preserved, hands and scores are derived. */
    public static GameState rebuild(long seed, List<Seat> seats, List<GameEvent> events) {
        GameState g = GameState.newGame(seed, seats);
        List<GameEvent> ordered = new ArrayList<>(events);
        ordered.sort(Comparator.comparingInt(GameEvent::seq));
        if (!ordered.isEmpty()) g.current = ordered.get(0).seatIndex(); // align to the recorded first mover
        for (GameEvent e : ordered) {
            switch (e.kind()) {
                case GameEvent.MOVE -> g.applyMove(e.seatIndex(), EventCodec.decodeMove(e.detail()));
                case GameEvent.SWAP -> g.swap(e.seatIndex(), EventCodec.decodeTiles(e.detail()));
                case GameEvent.PASS -> g.pass(e.seatIndex());
                default -> throw new IllegalStateException("Unknown event kind: " + e.kind());
            }
        }
        return g;
    }
}
