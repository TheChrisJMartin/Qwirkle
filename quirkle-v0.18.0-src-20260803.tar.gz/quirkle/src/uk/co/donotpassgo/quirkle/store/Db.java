package uk.co.donotpassgo.quirkle.store;

import uk.co.donotpassgo.quirkle.config.Config;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/** JDBC access. The PostgreSQL driver lives in Tomcat's lib/ (never in the WAR). */
public final class Db {
    private Db() {}

    public static Connection connection() throws SQLException {
        return DriverManager.getConnection(Config.dbUrl(), Config.dbUser(), Config.dbPass());
    }

    public static boolean reachable() {
        try (Connection c = connection()) { return c.isValid(3); }
        catch (Exception e) { return false; }
    }
}
