package uk.co.donotpassgo.quirkle.store;

import uk.co.donotpassgo.quirkle.engine.*;

import java.sql.*;
import java.util.*;

/**
 * Persists games to PostgreSQL and reconstructs them. The event log is the source of truth:
 * a game is rebuilt by replaying its events over the seeded bag, so resume is exact.
 * The game/seat snapshot columns are stored for inspection and listing.
 */
public final class GameStore {
    private GameStore() {}

    /** A lightweight row for listing games. */
    public record Summary(long id, String status, int seats, String updated) {}

    /** Persist a fresh game and return its new id (also set on the GameState). */
    public static long create(GameState g) throws SQLException {
        try (Connection c = Db.connection()) {
            c.setAutoCommit(false);
            long id;
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO game(status, seed, current_seat, mode, level, kind, host_user_id) VALUES (?,?,?,?,?,?,?) RETURNING id")) {
                ps.setString(1, g.status.name());
                ps.setLong(2, g.seed);
                ps.setInt(3, g.current);
                ps.setString(4, g.mode);
                ps.setInt(5, g.level);
                ps.setString(6, g.kind);
                if (g.hostUserId == null) ps.setNull(7, java.sql.Types.BIGINT); else ps.setLong(7, g.hostUserId);
                try (ResultSet rs = ps.executeQuery()) { rs.next(); id = rs.getLong(1); }
            }
            insertSeats(c, id, g);
            insertEvents(c, id, g.events, 0);
            c.commit();
            g.id = id;
            return id;
        }
    }

    /** Update the snapshot and append any new events since the given count. */
    public static void save(GameState g) throws SQLException {
        if (g.id == null) { create(g); return; }
        try (Connection c = Db.connection()) {
            c.setAutoCommit(false);
            try (PreparedStatement ps = c.prepareStatement(
                    "UPDATE game SET status=?, current_seat=?, human_think_ms=?, human_think_moves=?, updated_at=now() WHERE id=?")) {
                ps.setString(1, g.status.name());
                ps.setInt(2, g.current);
                ps.setLong(3, g.humanThinkMs);
                ps.setInt(4, g.humanThinkMoves);
                ps.setLong(5, g.id);
                ps.executeUpdate();
            }
            int have;
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT COALESCE(MAX(seq)+1,0) FROM game_event WHERE game_id=?")) {
                ps.setLong(1, g.id);
                try (ResultSet rs = ps.executeQuery()) { rs.next(); have = rs.getInt(1); }
            }
            insertEvents(c, g.id, g.events, have);
            updateSeatSnapshot(c, g.id, g);
            c.commit();
        }
    }

    /** Load and reconstruct a game by id, or null if it does not exist. */
    public static GameState load(long id) throws SQLException {
        try (Connection c = Db.connection()) {
            long seed; long thinkMs; int thinkMoves; String gMode; int gLevel; String gKind; Long gHost;
            try (PreparedStatement ps = c.prepareStatement("SELECT seed, human_think_ms, human_think_moves, mode, level, kind, host_user_id FROM game WHERE id=?")) {
                ps.setLong(1, id);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) return null;
                    seed = rs.getLong(1); thinkMs = rs.getLong(2); thinkMoves = rs.getInt(3);
                    gMode = rs.getString(4); gLevel = rs.getInt(5);
                    gKind = rs.getString(6); long hu = rs.getLong(7); gHost = rs.wasNull() ? null : hu;
                }
            }
            List<Seat> seats = new ArrayList<>();
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT seat_index, name, ai, ai_difficulty, user_id, personality FROM game_seat WHERE game_id=? ORDER BY seat_index")) {
                ps.setLong(1, id);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        String name = rs.getString("name");
                        boolean ai = rs.getBoolean("ai");
                        String diff = rs.getString("ai_difficulty");
                        Seat seat = ai ? Seat.ai(name, diff) : Seat.human(name);
                        long uid = rs.getLong("user_id"); if (!rs.wasNull()) seat.userId = uid;
                        seat.personality = rs.getString("personality");
                        seats.add(seat);
                    }
                }
            }
            List<GameEvent> events = new ArrayList<>();
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT seq, seat_index, kind, detail FROM game_event WHERE game_id=? ORDER BY seq")) {
                ps.setLong(1, id);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        events.add(new GameEvent(rs.getInt("seq"), rs.getInt("seat_index"),
                                rs.getString("kind"), rs.getString("detail") == null ? "" : rs.getString("detail")));
                    }
                }
            }
            GameState g = GameReplay.rebuild(seed, seats, events);
            g.id = id;
            g.humanThinkMs = thinkMs; g.humanThinkMoves = thinkMoves;
            g.mode = gMode == null ? "free" : gMode; g.level = gLevel;
            g.kind = gKind == null ? "SOLO" : gKind; g.hostUserId = gHost;
            return g;
        }
    }

    public static List<Summary> list() throws SQLException {
        List<Summary> out = new ArrayList<>();
        try (Connection c = Db.connection();
             PreparedStatement ps = c.prepareStatement(
                 "SELECT g.id, g.status, g.updated_at, COUNT(s.id) AS seats " +
                 "FROM game g LEFT JOIN game_seat s ON s.game_id=g.id " +
                 "GROUP BY g.id, g.status, g.updated_at ORDER BY g.id DESC");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next())
                out.add(new Summary(rs.getLong("id"), rs.getString("status"),
                        rs.getInt("seats"), String.valueOf(rs.getObject("updated_at"))));
        }
        return out;
    }

    // --- helpers ---------------------------------------------------------
    private static void insertSeats(Connection c, long id, GameState g) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(
                "INSERT INTO game_seat(game_id, seat_index, name, ai, ai_difficulty, hand, score, user_id, personality) " +
                "VALUES (?,?,?,?,?,?,?,?,?)")) {
            for (int i = 0; i < g.seats.size(); i++) {
                Seat s = g.seats.get(i);
                ps.setLong(1, id); ps.setInt(2, i); ps.setString(3, s.name);
                ps.setBoolean(4, s.ai); ps.setString(5, s.aiDifficulty);
                ps.setString(6, EventCodec.encodeTiles(s.hand)); ps.setInt(7, s.score);
                if (s.userId == null) ps.setNull(8, java.sql.Types.BIGINT); else ps.setLong(8, s.userId);
                ps.setString(9, s.personality);
                ps.addBatch();
            }
            ps.executeBatch();
        }
    }

    private static void updateSeatSnapshot(Connection c, long id, GameState g) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(
                "UPDATE game_seat SET hand=?, score=? WHERE game_id=? AND seat_index=?")) {
            for (int i = 0; i < g.seats.size(); i++) {
                Seat s = g.seats.get(i);
                ps.setString(1, EventCodec.encodeTiles(s.hand)); ps.setInt(2, s.score);
                ps.setLong(3, id); ps.setInt(4, i);
                ps.addBatch();
            }
            ps.executeBatch();
        }
    }

    private static void insertEvents(Connection c, long id, List<GameEvent> events, int fromSeq) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(
                "INSERT INTO game_event(game_id, seq, seat_index, kind, detail) VALUES (?,?,?,?,?) " +
                "ON CONFLICT (game_id, seq) DO NOTHING")) {
            for (GameEvent e : events) {
                if (e.seq() < fromSeq) continue;
                ps.setLong(1, id); ps.setInt(2, e.seq()); ps.setInt(3, e.seatIndex());
                ps.setString(4, e.kind()); ps.setString(5, e.detail());
                ps.addBatch();
            }
            ps.executeBatch();
        }
    }
}
