package uk.co.donotpassgo.quirkle.store;

import java.sql.*;

/**
 * Idempotent boot migrations. Each step is guarded by IF NOT EXISTS and recorded in schema_version,
 * so a clean database is fully provisioned on first boot and re-running is a no-op.
 */
public final class Migrator {
    private Migrator() {}

    private static final String[][] STEPS = {
        {"0001_schema_version",
            "CREATE TABLE IF NOT EXISTS schema_version(" +
            "step VARCHAR(64) PRIMARY KEY, applied_at TIMESTAMPTZ NOT NULL DEFAULT now())"},
        {"0002_app_user",
            "CREATE TABLE IF NOT EXISTS app_user(" +
            "id BIGSERIAL PRIMARY KEY, email TEXT UNIQUE NOT NULL, display_name TEXT NOT NULL, " +
            "pw_hash TEXT, pw_salt TEXT, pw_iterations INT, verified BOOLEAN NOT NULL DEFAULT FALSE, " +
            "created_at TIMESTAMPTZ NOT NULL DEFAULT now())"},
        {"0003_game",
            "CREATE TABLE IF NOT EXISTS game(" +
            "id BIGSERIAL PRIMARY KEY, status TEXT NOT NULL, seed BIGINT NOT NULL, " +
            "current_seat INT NOT NULL DEFAULT 0, ruleset JSONB, " +
            "created_at TIMESTAMPTZ NOT NULL DEFAULT now(), updated_at TIMESTAMPTZ NOT NULL DEFAULT now())"},
        {"0004_game_seat",
            "CREATE TABLE IF NOT EXISTS game_seat(" +
            "id BIGSERIAL PRIMARY KEY, game_id BIGINT NOT NULL REFERENCES game(id) ON DELETE CASCADE, " +
            "seat_index INT NOT NULL, user_id BIGINT REFERENCES app_user(id), " +
            "ai BOOLEAN NOT NULL DEFAULT FALSE, ai_difficulty TEXT, hand TEXT, score INT NOT NULL DEFAULT 0, " +
            "UNIQUE(game_id, seat_index))"},
        {"0005_game_event",
            "CREATE TABLE IF NOT EXISTS game_event(" +
            "id BIGSERIAL PRIMARY KEY, game_id BIGINT NOT NULL REFERENCES game(id) ON DELETE CASCADE, " +
            "seq INT NOT NULL, seat_index INT, kind TEXT NOT NULL, payload JSONB, " +
            "created_at TIMESTAMPTZ NOT NULL DEFAULT now(), UNIQUE(game_id, seq))"},
        {"0006_session_token",
            "CREATE TABLE IF NOT EXISTS session_token(" +
            "token TEXT PRIMARY KEY, user_id BIGINT NOT NULL REFERENCES app_user(id) ON DELETE CASCADE, " +
            "expires_at TIMESTAMPTZ NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT now())"},
        {"0007_game_seat_name",
            "ALTER TABLE game_seat ADD COLUMN IF NOT EXISTS name TEXT"},
        {"0008_game_event_detail",
            "ALTER TABLE game_event ADD COLUMN IF NOT EXISTS detail TEXT"},
        {"0009_user_stats",
            "CREATE TABLE IF NOT EXISTS user_stats(" +
            "user_id BIGINT PRIMARY KEY REFERENCES app_user(id) ON DELETE CASCADE, " +
            "games INT NOT NULL DEFAULT 0, wins INT NOT NULL DEFAULT 0, win_streak INT NOT NULL DEFAULT 0, " +
            "best_streak INT NOT NULL DEFAULT 0, tiles_placed INT NOT NULL DEFAULT 0, " +
            "quirkles INT NOT NULL DEFAULT 0, missed_quirkles INT NOT NULL DEFAULT 0, " +
            "best_score INT NOT NULL DEFAULT 0, best_move INT NOT NULL DEFAULT 0, " +
            "updated_at TIMESTAMPTZ NOT NULL DEFAULT now())"},
        {"0010_user_achievement",
            "CREATE TABLE IF NOT EXISTS user_achievement(" +
            "user_id BIGINT NOT NULL REFERENCES app_user(id) ON DELETE CASCADE, " +
            "code TEXT NOT NULL, unlocked_at TIMESTAMPTZ NOT NULL DEFAULT now(), " +
            "PRIMARY KEY(user_id, code))"},
        {"0011_game_think",
            "ALTER TABLE game ADD COLUMN IF NOT EXISTS human_think_ms BIGINT NOT NULL DEFAULT 0, " +
            "ADD COLUMN IF NOT EXISTS human_think_moves INT NOT NULL DEFAULT 0"},
        {"0012_game_seat_personality",
            "ALTER TABLE game_seat ADD COLUMN IF NOT EXISTS personality TEXT"},
        {"0013_game_finalized",
            "ALTER TABLE game ADD COLUMN IF NOT EXISTS finalized BOOLEAN NOT NULL DEFAULT FALSE"},
        {"0014_password_reset",
            "CREATE TABLE IF NOT EXISTS password_reset(" +
            "token TEXT PRIMARY KEY, user_id BIGINT NOT NULL REFERENCES app_user(id) ON DELETE CASCADE, " +
            "expires_at TIMESTAMPTZ NOT NULL, used BOOLEAN NOT NULL DEFAULT FALSE, " +
            "created_at TIMESTAMPTZ NOT NULL DEFAULT now())"},
        {"0015_levels",
            "ALTER TABLE user_stats ADD COLUMN IF NOT EXISTS level INT NOT NULL DEFAULT 1"},
        {"0016_game_mode",
            "ALTER TABLE game ADD COLUMN IF NOT EXISTS mode TEXT, ADD COLUMN IF NOT EXISTS level INT"},
        {"0017_game_kind",
            "ALTER TABLE game ADD COLUMN IF NOT EXISTS kind TEXT, ADD COLUMN IF NOT EXISTS host_user_id BIGINT"},
        {"0018_game_invite",
            "CREATE TABLE IF NOT EXISTS game_invite(" +
            "id BIGSERIAL PRIMARY KEY, game_id BIGINT NOT NULL REFERENCES game(id) ON DELETE CASCADE, " +
            "seat_index INT NOT NULL, email TEXT, token TEXT UNIQUE NOT NULL, " +
            "status TEXT NOT NULL DEFAULT 'PENDING', invited_user_id BIGINT, " +
            "created_at TIMESTAMPTZ NOT NULL DEFAULT now())"},
        {"0019_game_notified",
            "ALTER TABLE game ADD COLUMN IF NOT EXISTS notified_seq INT NOT NULL DEFAULT -1"},
        {"0020_user_last_login",
            "ALTER TABLE app_user ADD COLUMN IF NOT EXISTS last_login TIMESTAMPTZ"}
    };

    public static void migrate() throws SQLException {
        try (Connection c = Db.connection()) {
            c.setAutoCommit(false);
            try (Statement s = c.createStatement()) { s.execute(STEPS[0][1]); } // ensure ledger exists
            for (String[] step : STEPS) {
                if (!applied(c, step[0])) {
                    try (Statement s = c.createStatement()) { s.execute(step[1]); }
                    try (PreparedStatement ps = c.prepareStatement(
                            "INSERT INTO schema_version(step) VALUES(?) ON CONFLICT DO NOTHING")) {
                        ps.setString(1, step[0]);
                        ps.executeUpdate();
                    }
                }
            }
            c.commit();
        }
    }

    private static boolean applied(Connection c, String step) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("SELECT 1 FROM schema_version WHERE step = ?")) {
            ps.setString(1, step);
            try (ResultSet rs = ps.executeQuery()) { return rs.next(); }
        }
    }
}
