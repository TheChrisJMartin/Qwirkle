package uk.co.donotpassgo.quirkle.service;

import uk.co.donotpassgo.quirkle.engine.*;
import uk.co.donotpassgo.quirkle.store.*;
import uk.co.donotpassgo.quirkle.ai.LegalMoves;
import java.util.*;

/** End-to-end API flow against a live DB: create, single-step AI advance, stats, forced pass. */
public final class ServiceTest {
    static int checks = 0;
    static void check(boolean c, String m) { checks++; if (!c) throw new AssertionError("FAILED: " + m); }

    public static void main(String[] args) throws Exception {
        Migrator.migrate();

        String s = GameService.createGame(null, 3, "medium", "Chris", null, null, null, null);
        long id = extractId(s);
        check(id > 0, "created id");
        check(count(s, "\"index\":") == 4, "4 seats");
        check(s.contains("\"starter\":{"), "state announces the starting player");
        System.out.println("[ok] createGame id=" + id + ", 4 seats, starter announced");

        int humanMoves = 0, botSteps = 0, guard = 0;
        while (guard++ < 1000) {
            GameState g = GameStore.load(id);
            if (g.status != GameStatus.IN_PROGRESS) break;
            if (g.current == 0) {
                List<Move> moves = LegalMoves.enumerate(g.board, g.seats.get(0).hand);
                if (!moves.isEmpty()) { GameService.move(id, EventCodec.encodeMove(moves.get(0)), 0); humanMoves++; }
                else if (!g.bag.isEmpty()) GameService.swap(id, g.seats.get(0).hand.get(0).code(), 0);
                else { String r = GameService.pass(id); check(r.contains("\"kind\":\"PASS\""), "forced pass reported"); }
            } else {
                String r = GameService.advance(id);           // exactly one bot
                check(r.contains("\"lastMove\":{"), "advance returns lastMove");
                botSteps++;
            }
        }
        GameState fin = GameStore.load(id);
        System.out.println("[ok] " + humanMoves + " human moves, " + botSteps + " single bot steps, status=" + fin.status);

        String st = GameService.stats(id);
        check(st.contains("\"quirkles\":"), "stats has quirkles");
        check(st.contains("\"opensLeader\":"), "stats has opens leader");
        check(st.contains("\"closesLeader\":"), "stats has closes leader");
        System.out.println("[ok] stats: " + st.replaceAll("\\s+", ""));

        // advance is a single step: from a fresh game, one advance moves exactly one bot.
        String fresh = GameService.createGame(null, 3, "easy", "T", null, null, null, null);
        long id2 = extractId(fresh);
        GameState g2 = GameStore.load(id2);
        int g2guard = 0;
        while (g2.current != 0 && g2.status == GameStatus.IN_PROGRESS && g2guard++ < 20) {
            GameService.advance(id2); g2 = GameStore.load(id2);   // bring the turn round to the human
        }
        if (g2.current == 0 && g2.status == GameStatus.IN_PROGRESS) {
            List<Move> hm = LegalMoves.enumerate(g2.board, g2.seats.get(0).hand);
            if (!hm.isEmpty()) {
                GameService.move(id2, EventCodec.encodeMove(hm.get(0)), 0);
                GameState afterMove = GameStore.load(id2);
                check(afterMove.current == 1, "after human move it is bot 1's turn (no auto-advance)");
                GameService.advance(id2);
                GameState afterOne = GameStore.load(id2);
                check(afterOne.current == 2 || afterOne.status == GameStatus.FINISHED, "one advance steps exactly one bot");
                System.out.println("[ok] advance steps exactly one bot at a time");
            }
        }

        System.out.println("\nALL SERVICE TESTS PASSED (" + checks + " checks).");
    }

    static long extractId(String j){int i=j.indexOf("\"id\":")+5,k=i;while(k<j.length()&&(Character.isDigit(j.charAt(k))||j.charAt(k)=='-'))k++;return Long.parseLong(j.substring(i,k));}
    static int count(String s,String sub){int n=0,i=0;while((i=s.indexOf(sub,i))>=0){n++;i+=sub.length();}return n;}
}
