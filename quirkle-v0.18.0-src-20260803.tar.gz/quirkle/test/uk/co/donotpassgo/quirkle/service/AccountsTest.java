package uk.co.donotpassgo.quirkle.service;

import uk.co.donotpassgo.quirkle.auth.*;
import uk.co.donotpassgo.quirkle.store.*;
import uk.co.donotpassgo.quirkle.engine.*;
import uk.co.donotpassgo.quirkle.ai.LegalMoves;
import java.util.*;

public class AccountsTest {
    static int checks = 0;
    static void ok(boolean c, String m) { checks++; if (!c) throw new AssertionError("FAILED: " + m); System.out.println("[ok] " + m); }

    public static void main(String[] args) throws Exception {
        Migrator.migrate();

        // 1) register + login + resolve
        String email = "chris+" + System.nanoTime() + "@example.com";
        User u = Auth.register(email, "Chris", "hunter2");
        ok(u.id() > 0, "registered user id=" + u.id());
        String token = Auth.login(email, "hunter2");
        ok(token != null && Auth.resolve(token) != null, "login + session resolves");
        ok(Auth.resolve("bogus") == null, "bogus token resolves to guest");
        boolean rejected = false;
        try { Auth.login(email, "wrong"); } catch (IllegalArgumentException e) { rejected = true; }
        ok(rejected, "wrong password rejected");

        // 2) create a game as the logged-in user, named bots + personalities
        String created = GameService.createGame(u.id(), 3, "medium", "Chris", "sharp,steady,casual", null, null, null);
        long id = Long.parseLong(created.replaceAll(".*\"id\":(\\d+).*", "$1"));
        GameState g0 = GameStore.load(id);
        ok(g0.seats.get(0).userId != null && g0.seats.get(0).userId == u.id(), "seat 0 carries userId");
        java.util.Set<String> roster = new java.util.HashSet<>(java.util.Arrays.asList("Lexi","Tilly","Bob","Indigo","Edward","Freda","Nia"));
        java.util.Set<String> got = new java.util.HashSet<>();
        for (int i = 1; i <= 3; i++) { ok(roster.contains(g0.seats.get(i).name), "bot " + i + " has a roster name: " + g0.seats.get(i).name); got.add(g0.seats.get(i).name); }
        ok(got.size() == 3, "bot names are distinct");
        ok("sharp".equals(g0.seats.get(1).personality), "custom bot 1 persona = sharp (" + g0.seats.get(1).personality + ")");

        // 3) play to the end (human plays greedily, bots advance)
        int humanMoves = 0, botSteps = 0;
        for (int guard = 0; guard < 4000; guard++) {
            GameState g = GameStore.load(id);
            if (g.status == GameStatus.FINISHED) break;
            if (g.current == 0) {
                List<Move> mv = LegalMoves.enumerate(g.board, g.seats.get(0).hand);
                if (!mv.isEmpty()) { GameService.move(id, EventCodec.encodeMove(mv.get(0)), 5000); humanMoves++; }
                else if (!g.bag.isEmpty()) GameService.swap(id, g.seats.get(0).hand.get(0).code(), 3000);
                else GameService.pass(id);
            } else { GameService.advance(id); botSteps++; }
        }
        GameState gf = GameStore.load(id);
        ok(gf.status == GameStatus.FINISHED, "game finished (" + humanMoves + " human moves)");
        ok(gf.humanThinkMoves > 0 && gf.humanThinkMs > 0, "human think time persisted: " + gf.humanThinkMs + "ms over " + gf.humanThinkMoves + " moves");

        // 4) user stats + achievements recorded once
        String uj = UserService.readJson(u.id());
        ok(uj.contains("\"games\":1"), "user_stats games=1");
        ok(uj.contains("\"achievements\":["), "achievements list present");
        int unlockedCount = Integer.parseInt(uj.replaceAll(".*\"unlocked\":(\\d+).*", "$1"));
        ok(unlockedCount >= 1, "at least one achievement unlocked (" + unlockedCount + ")");

        // finalize is idempotent — calling advance again must not double count
        GameService.advance(id);
        String uj2 = UserService.readJson(u.id());
        ok(uj2.contains("\"games\":1"), "finalize is idempotent (still games=1)");

        // 5) stats endpoint carries missedQwirkles-capable analytics
        String stats = GameService.stats(id);
        ok(stats.contains("\"quirkles\":"), "stats include quirkles");

        // 6) guest game does not touch user stats
        String gGuest = GameService.createGame(null, 1, "easy", "Guest", null, null, null, null);
        ok(gGuest.contains("\"seats\""), "guest game created without login");

        System.out.println("\nALL ACCOUNTS TESTS PASSED (" + checks + " checks). unlocked=" + unlockedCount);
    }
}
