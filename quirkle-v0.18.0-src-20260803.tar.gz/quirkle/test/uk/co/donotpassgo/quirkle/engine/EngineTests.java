package uk.co.donotpassgo.quirkle.engine;

import java.util.*;

/** Dependency-free assertion harness for the game engine. Run via main(); throws on failure. */
public final class EngineTests {
    private static int checks = 0;

    public static void main(String[] args) {
        testBagComposition();
        testDeterminism();
        testValidationAccepts();
        testValidationRejects();
        testScoreSimpleLine();
        testScoreIntersection();
        testScoreQwirkle();
        testSwapConserves();
        testReplayReconstruction();
        testSelfPlayFullGame();
        System.out.println("\nALL ENGINE TESTS PASSED (" + checks + " checks).");
    }

    // --- helpers ---------------------------------------------------------
    private static void check(boolean cond, String msg) {
        checks++;
        if (!cond) throw new AssertionError("FAILED: " + msg);
    }
    private static Tile t(Colour c, Shape s) { return new Tile(c, s); }
    private static Placement p(int x, int y, Colour c, Shape s) { return new Placement(new Coord(x, y), t(c, s)); }
    private static int scoreOf(Board b, Move m, boolean first) {
        ValidationResult vr = MoveValidator.validate(b, m, first);
        check(vr.legal(), "expected legal move but got: " + vr.reason());
        return Scorer.score(vr, m);
    }

    // --- tests -----------------------------------------------------------
    private static void testBagComposition() {
        Bag bag = new Bag(1L);
        check(bag.size() == 108, "bag should hold 108 tiles, was " + bag.size());
        Map<String, Integer> counts = new HashMap<>();
        for (Tile tile : bag.draw(108)) counts.merge(tile.code(), 1, Integer::sum);
        check(counts.size() == 36, "should be 36 distinct tiles, was " + counts.size());
        for (var e : counts.entrySet()) check(e.getValue() == 3, "expected 3 of " + e.getKey());
        System.out.println("[ok] bag composition: 108 tiles, 36 kinds x 3");
    }

    private static void testDeterminism() {
        List<Tile> a = new Bag(42L).draw(108);
        List<Tile> b = new Bag(42L).draw(108);
        check(a.equals(b), "same seed must give identical bag order");
        List<Tile> c = new Bag(43L).draw(108);
        check(!a.equals(c), "different seeds should (almost surely) differ");
        System.out.println("[ok] deterministic shuffle by seed");
    }

    private static void testValidationAccepts() {
        Board b = new Board();
        // Opening line: three reds with distinct shapes.
        Move m = new Move(List.of(
            p(0, 0, Colour.RED, Shape.CIRCLE),
            p(1, 0, Colour.RED, Shape.SQUARE),
            p(2, 0, Colour.RED, Shape.DIAMOND)));
        ValidationResult vr = MoveValidator.validate(b, m, true);
        check(vr.legal(), "valid opening line rejected: " + vr.reason());
        System.out.println("[ok] validation accepts a valid opening line");
    }

    private static void testValidationRejects() {
        Board b = new Board();
        b.place(new Coord(0, 0), t(Colour.RED, Shape.CIRCLE));
        // Duplicate tile in a line.
        check(!MoveValidator.validate(b, Move.of(p(1, 0, Colour.RED, Shape.CIRCLE)), false).legal(),
                "should reject duplicate tile");
        // Mixed colour and shape.
        check(!MoveValidator.validate(b, Move.of(p(1, 0, Colour.BLUE, Shape.SQUARE)), false).legal(),
                "should reject colour+shape mix");
        // Gap in the line.
        check(!MoveValidator.validate(b, new Move(List.of(
                p(1, 0, Colour.RED, Shape.SQUARE),
                p(3, 0, Colour.RED, Shape.DIAMOND))), false).legal(),
                "should reject a gap");
        // Not a single row or column (cells differ in both x and y).
        check(!MoveValidator.validate(b, new Move(List.of(
                p(1, 0, Colour.RED, Shape.SQUARE),
                p(2, 1, Colour.RED, Shape.DIAMOND))), false).legal(),
                "should reject a non-colinear move");
        // Disconnected from the board.
        check(!MoveValidator.validate(b, Move.of(p(5, 5, Colour.RED, Shape.SQUARE)), false).legal(),
                "should reject a disconnected move");
        System.out.println("[ok] validation rejects duplicate/mix/gap/L-shape/disconnected");
    }

    private static void testScoreSimpleLine() {
        Board b = new Board();
        Move m = new Move(List.of(
            p(0, 0, Colour.RED, Shape.CIRCLE),
            p(1, 0, Colour.RED, Shape.SQUARE),
            p(2, 0, Colour.RED, Shape.DIAMOND)));
        check(scoreOf(b, m, true) == 3, "three-tile opening line should score 3");
        System.out.println("[ok] scoring: opening line of 3 -> 3");
    }

    private static void testScoreIntersection() {
        // Pre-board: a red row and a circle column meeting at (0,0).
        Board b = new Board();
        b.place(new Coord(0, 0), t(Colour.RED, Shape.CIRCLE));   // shared origin
        b.place(new Coord(1, 0), t(Colour.RED, Shape.SQUARE));   // red row: (0,0),(1,0)
        b.place(new Coord(0, 1), t(Colour.BLUE, Shape.CIRCLE));  // circle column: (0,0),(0,1)
        // Placing BLUE SQUARE at (1,1) completes two length-2 lines: 2 + 2 = 4.
        Move m = Move.of(p(1, 1, Colour.BLUE, Shape.SQUARE));
        check(scoreOf(b, m, false) == 4, "intersection tile should score 4 (2+2)");
        System.out.println("[ok] scoring: intersecting tile counts in both lines -> 4");
    }

    private static void testScoreQwirkle() {
        Board b = new Board();
        // Five blues already down (distinct shapes); the sixth completes a Qwirkle.
        Shape[] first5 = { Shape.CIRCLE, Shape.SQUARE, Shape.DIAMOND, Shape.CLOVER, Shape.STAR4 };
        for (int i = 0; i < 5; i++) b.place(new Coord(i, 0), t(Colour.BLUE, first5[i]));
        Move m = Move.of(p(5, 0, Colour.BLUE, Shape.STAR8));
        // Line of six -> 6 + 6 bonus = 12.
        check(scoreOf(b, m, false) == 12, "Qwirkle should score 12");
        System.out.println("[ok] scoring: completing a line of six -> 12 (Qwirkle bonus)");
    }

    private static void testSwapConserves() {
        GameState g = GameState.newGame(7L, List.of(Seat.human("A"), Seat.ai("B", "medium")));
        check(g.tileCount() == 108, "conservation before swap");
        int si = g.current;
        Tile one = g.currentSeat().hand.get(0);
        g.swap(si, List.of(one));
        check(g.tileCount() == 108, "conservation after swap");
        System.out.println("[ok] swap conserves the 108-tile invariant");
    }

    private static void testReplayReconstruction() {
        long seed = 99L;
        GameState g = GameState.newGame(seed,
            List.of(Seat.human("You"), Seat.ai("Bot-1", "medium"), Seat.ai("Bot-2", "medium")));
        int steps = 0;
        while (g.status == GameStatus.IN_PROGRESS && steps < 20000) {
            int si = g.current;
            Seat seat = g.currentSeat();
            Optional<Move> mv = findBestSingleTileMove(g, seat);
            if (mv.isPresent()) g.applyMove(si, mv.get());
            else if (!g.bag.isEmpty() && !seat.hand.isEmpty()) g.swap(si, List.of(seat.hand.get(0)));
            else g.pass(si);
            steps++;
        }
        // Rebuild purely from seed + fresh seat metadata + the event log.
        GameState r = GameReplay.rebuild(seed,
            List.of(Seat.human("You"), Seat.ai("Bot-1", "medium"), Seat.ai("Bot-2", "medium")),
            g.events);
        check(r.board.view().equals(g.board.view()), "replayed board must match original");
        check(r.status == g.status, "replayed status must match");
        check(r.current == g.current, "replayed current seat must match");
        for (int i = 0; i < g.seats.size(); i++)
            check(r.seats.get(i).score == g.seats.get(i).score, "replayed score[" + i + "] must match");
        check(r.events.size() == g.events.size(), "replayed event count must match");
        System.out.println("[ok] replay reconstructs identical board/scores/status from the event log ("
            + g.events.size() + " events)");
    }

    private static void testSelfPlayFullGame() {
        GameState g = GameState.newGame(2026L,
            List.of(Seat.human("You"), Seat.ai("Bot-1", "medium"),
                    Seat.ai("Bot-2", "medium"), Seat.ai("Bot-3", "medium")));
        int steps = 0;
        while (g.status == GameStatus.IN_PROGRESS && steps < 20000) {
            int si = g.current;
            Seat seat = g.currentSeat();
            Optional<Move> mv = findBestSingleTileMove(g, seat);
            if (mv.isPresent()) {
                g.applyMove(si, mv.get());
            } else if (!g.bag.isEmpty() && !seat.hand.isEmpty()) {
                g.swap(si, List.of(seat.hand.get(0)));
            } else {
                g.pass(si);
            }
            check(g.tileCount() == 108, "conservation during self-play at step " + steps);
            steps++;
        }
        check(g.status == GameStatus.FINISHED, "game should finish; status=" + g.status);
        List<Seat> table = g.standings();
        System.out.println("[ok] self-play finished in " + steps + " turns. Final standings:");
        for (Seat s : table) System.out.println("       " + s.name + ": " + s.score);
    }

    /** A minimal single-tile legal-move finder used only to drive the self-play test (not the real AI). */
    private static Optional<Move> findBestSingleTileMove(GameState g, Seat seat) {
        Set<Coord> anchors = new LinkedHashSet<>();
        if (g.board.isEmpty()) {
            anchors.add(new Coord(0, 0));
        } else {
            for (Coord c : g.board.view().keySet())
                for (int[] d : new int[][]{{1,0},{-1,0},{0,1},{0,-1}}) {
                    Coord n = new Coord(c.x() + d[0], c.y() + d[1]);
                    if (!g.board.contains(n)) anchors.add(n);
                }
        }
        Move best = null; int bestScore = -1;
        Set<String> triedTiles = new HashSet<>();
        for (Tile tile : seat.hand) {
            if (!triedTiles.add(tile.code())) continue; // skip duplicate hand tiles
            for (Coord a : anchors) {
                Move m = Move.of(new Placement(a, tile));
                ValidationResult vr = MoveValidator.validate(g.board, m, g.board.isEmpty());
                if (vr.legal()) {
                    int sc = Scorer.score(vr, m);
                    if (sc > bestScore) { bestScore = sc; best = m; }
                }
            }
        }
        return Optional.ofNullable(best);
    }
}
