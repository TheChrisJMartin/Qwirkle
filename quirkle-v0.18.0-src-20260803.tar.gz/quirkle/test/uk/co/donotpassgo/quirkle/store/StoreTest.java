package uk.co.donotpassgo.quirkle.store;

import uk.co.donotpassgo.quirkle.engine.*;
import java.sql.*;
import java.util.*;

/** Live round-trip test against PostgreSQL: migrate, persist a played game, resume it, verify equality. */
public final class StoreTest {
    static int checks = 0;
    static void check(boolean c, String m) { checks++; if (!c) throw new AssertionError("FAILED: " + m); }

    public static void main(String[] args) throws Exception {
        Migrator.migrate();
        Migrator.migrate(); // idempotent second run
        try (Connection c = Db.connection();
             Statement s = c.createStatement();
             ResultSet rs = s.executeQuery("SELECT count(*) FROM schema_version")) {
            rs.next();
            check(rs.getInt(1) == 20, "expected 20 migration steps, got " + rs.getInt(1));
        }
        System.out.println("[ok] migrations applied (20 steps), idempotent on re-run");

        // Play a full game.
        GameState g = GameState.newGame(31337L,
            List.of(Seat.human("You"), Seat.ai("Bot-1","medium"),
                    Seat.ai("Bot-2","medium"), Seat.ai("Bot-3","medium")));
        selfPlay(g);
        check(g.status == GameStatus.FINISHED, "game should finish");

        long id = GameStore.create(g);
        System.out.println("[ok] persisted finished game id=" + id + " (" + g.events.size() + " events)");

        GameState r = GameStore.load(id);
        check(r != null, "load must return a game");
        check(r.board.view().equals(g.board.view()), "resumed board must match");
        check(r.current == g.current, "resumed current seat must match");
        check(r.status == g.status, "resumed status must match");
        check(r.events.size() == g.events.size(), "resumed event count must match");
        for (int i = 0; i < g.seats.size(); i++)
            check(r.seats.get(i).score == g.seats.get(i).score, "resumed score[" + i + "] must match");
        System.out.println("[ok] resumed game matches original board/scores/status exactly");

        // Incremental: persist a partial game, play on, append, reload.
        GameState g2 = GameState.newGame(2L,
            List.of(Seat.human("A"), Seat.ai("B","medium")));
        for (int i = 0; i < 8 && g2.status == GameStatus.IN_PROGRESS; i++) oneTurn(g2);
        long id2 = GameStore.create(g2);
        int firstBatch = g2.events.size();
        selfPlay(g2);
        GameStore.save(g2); // append the rest
        GameState r2 = GameStore.load(id2);
        check(r2.events.size() == g2.events.size(), "appended event count must match (was " + firstBatch + ", now " + g2.events.size() + ")");
        check(r2.board.view().equals(g2.board.view()), "incremental resume board must match");
        System.out.println("[ok] incremental append + resume works (" + firstBatch + " -> " + g2.events.size() + " events)");

        List<GameStore.Summary> games = GameStore.list();
        check(games.size() >= 2, "list should return the persisted games");
        System.out.println("[ok] list() returned " + games.size() + " games");

        System.out.println("\nALL STORE TESTS PASSED (" + checks + " checks).");
    }

    static void selfPlay(GameState g) {
        int steps = 0;
        while (g.status == GameStatus.IN_PROGRESS && steps < 20000) { oneTurn(g); steps++; }
    }
    static void oneTurn(GameState g) {
        int si = g.current; Seat seat = g.currentSeat();
        Optional<Move> mv = find(g, seat);
        if (mv.isPresent()) g.applyMove(si, mv.get());
        else if (!g.bag.isEmpty() && !seat.hand.isEmpty()) g.swap(si, List.of(seat.hand.get(0)));
        else g.pass(si);
    }
    static Optional<Move> find(GameState g, Seat seat) {
        Set<Coord> anchors = new LinkedHashSet<>();
        if (g.board.isEmpty()) anchors.add(new Coord(0,0));
        else for (Coord c : g.board.view().keySet())
            for (int[] d : new int[][]{{1,0},{-1,0},{0,1},{0,-1}}) {
                Coord n = new Coord(c.x()+d[0], c.y()+d[1]);
                if (!g.board.contains(n)) anchors.add(n);
            }
        Move best = null; int bestScore = -1; Set<String> tried = new HashSet<>();
        for (Tile t : seat.hand) {
            if (!tried.add(t.code())) continue;
            for (Coord a : anchors) {
                Move m = Move.of(new Placement(a, t));
                ValidationResult vr = MoveValidator.validate(g.board, m, g.board.isEmpty());
                if (vr.legal()) { int sc = Scorer.score(vr, m); if (sc > bestScore) { bestScore = sc; best = m; } }
            }
        }
        return Optional.ofNullable(best);
    }
}
