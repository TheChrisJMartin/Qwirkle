package uk.co.donotpassgo.quirkle.ai;

import uk.co.donotpassgo.quirkle.engine.*;
import java.util.*;

public final class AiTest {
    static int checks = 0;
    static void check(boolean c, String m) { checks++; if (!c) throw new AssertionError("FAILED: " + m); }

    public static void main(String[] args) {
        testAllEnumeratedLegal();
        testEnumeratorCompleteness();
        testAiGameCompletes();
        testDifficultyOrdering();
        System.out.println("\nALL AI TESTS PASSED (" + checks + " checks).");
    }

    /** Every move the enumerator returns must validate, and be distinct. */
    private static void testAllEnumeratedLegal() {
        for (long seed : new long[]{1, 7, 42, 100}) {
            GameState g = midGame(seed, 18);
            Seat seat = g.currentSeat();
            List<Move> moves = LegalMoves.enumerate(g.board, seat.hand);
            Set<String> keys = new HashSet<>();
            for (Move m : moves) {
                check(MoveValidator.validate(g.board, m, g.board.isEmpty()).legal(), "enumerated move must be legal");
                check(keys.add(canon(m)), "enumerated moves must be distinct");
            }
        }
        System.out.println("[ok] all enumerated moves are legal and distinct");
    }

    /** Enumerator must include every legal 1- and 2-tile move found by brute force in a window. */
    private static void testEnumeratorCompleteness() {
        for (long seed : new long[]{3, 11, 55, 123}) {
            GameState g = midGame(seed, 12);
            Board b = g.board;
            List<Tile> hand = distinct(g.currentSeat().hand);
            Set<String> enumerated = new HashSet<>();
            for (Move m : LegalMoves.enumerate(b, hand)) enumerated.add(canon(m));

            // window = occupied bounding box expanded by 1
            int minx = Integer.MAX_VALUE, miny = Integer.MAX_VALUE, maxx = Integer.MIN_VALUE, maxy = Integer.MIN_VALUE;
            for (Coord c : b.view().keySet()) {
                minx = Math.min(minx, c.x()); maxx = Math.max(maxx, c.x());
                miny = Math.min(miny, c.y()); maxy = Math.max(maxy, c.y());
            }
            List<Coord> empties = new ArrayList<>();
            for (int x = minx - 1; x <= maxx + 1; x++)
                for (int y = miny - 1; y <= maxy + 1; y++) {
                    Coord c = new Coord(x, y);
                    if (!b.contains(c)) empties.add(c);
                }

            int bruteCount = 0;
            // 1-tile
            for (Coord c : empties) for (Tile t : hand) {
                Move m = Move.of(new Placement(c, t));
                if (MoveValidator.validate(b, m, false).legal()) {
                    bruteCount++;
                    check(enumerated.contains(canon(m)), "missing legal 1-tile move at " + c + " " + t);
                }
            }
            // 2-tile, colinear pairs, distinct tile codes, both assignments
            for (int i = 0; i < empties.size(); i++)
                for (int j = i + 1; j < empties.size(); j++) {
                    Coord a = empties.get(i), d = empties.get(j);
                    if (a.x() != d.x() && a.y() != d.y()) continue; // not colinear
                    for (Tile t1 : hand) for (Tile t2 : hand) {
                        if (t1.code().equals(t2.code())) continue;
                        Move m = new Move(List.of(new Placement(a, t1), new Placement(d, t2)));
                        if (MoveValidator.validate(b, m, false).legal()) {
                            bruteCount++;
                            check(enumerated.contains(canon(m)), "missing legal 2-tile move " + a + t1 + " " + d + t2);
                        }
                    }
                }
        }
        System.out.println("[ok] enumerator is complete for all legal 1- and 2-tile moves (brute-force checked)");
    }

    private static void testAiGameCompletes() {
        long t0 = System.currentTimeMillis();
        GameState g = GameState.newGame(2026L, List.of(
            Seat.ai("Bot-1","medium"), Seat.ai("Bot-2","medium"),
            Seat.ai("Bot-3","hard"), Seat.ai("Bot-4","easy")));
        int guard = 0;
        while (g.status == GameStatus.IN_PROGRESS && guard++ < 10000) {
            check(g.tileCount() == 108, "conservation during AI game");
            AiTurns.playOne(g);
        }
        check(g.status == GameStatus.FINISHED, "AI game should finish");
        long ms = System.currentTimeMillis() - t0;
        System.out.println("[ok] full 4-AI game completed in " + guard + " turns (" + ms + " ms). Standings:");
        for (Seat s : g.standings()) System.out.println("       " + s.name + " (" + s.aiDifficulty + "): " + s.score);
    }

    private static void testDifficultyOrdering() {
        int games = 20, mediumWins = 0, easyWins = 0;
        long t0 = System.currentTimeMillis();
        for (int i = 0; i < games; i++) {
            GameState g = GameState.newGame(1000L + i, List.of(Seat.ai("M","medium"), Seat.ai("E","easy")));
            int guard = 0;
            while (g.status == GameStatus.IN_PROGRESS && guard++ < 10000) AiTurns.playOne(g);
            int m = g.seats.get(0).score, e = g.seats.get(1).score;
            if (m > e) mediumWins++; else if (e > m) easyWins++;
        }
        long ms = System.currentTimeMillis() - t0;
        System.out.println("[info] medium vs easy over " + games + " games: medium " + mediumWins + ", easy " + easyWins + " (" + ms + " ms)");
        check(mediumWins > easyWins, "medium should beat easy over many games");
        System.out.println("[ok] difficulty ordering holds (medium beats easy)");
    }

    // --- helpers ---
    private static GameState midGame(long seed, int turns) {
        GameState g = GameState.newGame(seed, List.of(
            Seat.ai("A","medium"), Seat.ai("B","medium"), Seat.ai("C","medium")));
        int i = 0;
        while (g.status == GameStatus.IN_PROGRESS && i++ < turns) AiTurns.playOne(g);
        return g;
    }
    private static String canon(Move m) {
        List<Placement> s = new ArrayList<>(m.placements());
        s.sort((a, b) -> a.coord().x() != b.coord().x()
                ? Integer.compare(a.coord().x(), b.coord().x())
                : Integer.compare(a.coord().y(), b.coord().y()));
        StringBuilder sb = new StringBuilder();
        for (Placement p : s) sb.append(p.coord().x()).append(',').append(p.coord().y()).append(',').append(p.tile().code()).append(';');
        return sb.toString();
    }
    private static List<Tile> distinct(List<Tile> hand) {
        Map<String, Tile> m = new LinkedHashMap<>();
        for (Tile t : hand) m.putIfAbsent(t.code(), t);
        return new ArrayList<>(m.values());
    }
}
