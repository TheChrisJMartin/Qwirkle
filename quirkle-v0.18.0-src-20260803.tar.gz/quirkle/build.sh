#!/usr/bin/env bash
# Quirkle build: compile the Jakarta servlet WAR with plain javac/jar (no Maven).
# The Jakarta Servlet API is compile-only; override its location with SERVLET_API=/path/to/jar.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
SRC="$HERE/src"
WEB="$HERE/web"
OUT="$HERE/build"
CLASSES="$OUT/classes"

SERVLET_API="${SERVLET_API:-}"
if [ -z "$SERVLET_API" ]; then
  for cand in \
    "${CATALINA_HOME:-/opt/tomcat}/lib/servlet-api.jar" \
    "${CATALINA_HOME:-/opt/tomcat}/lib/jakarta.servlet-api.jar" \
    /usr/share/java/tomcat10-servlet-api.jar \
    /usr/share/java/jakarta.servlet-api.jar ; do
    [ -f "$cand" ] && SERVLET_API="$cand" && break
  done
fi
[ -n "$SERVLET_API" ] || { echo "ERROR: Jakarta Servlet API jar not found. Set SERVLET_API=/path/to/jar"; exit 1; }
echo "Using Servlet API: $SERVLET_API"

# Jakarta WebSocket API (compile-only) for the live multiplayer endpoint.
WS_API="${WS_API:-}"
if [ -z "$WS_API" ]; then
  for cand in \
    "${CATALINA_HOME:-/opt/tomcat}/lib/websocket-api.jar" \
    "${CATALINA_HOME:-/opt/tomcat}/lib/jakarta.websocket-api.jar" \
    /usr/share/java/tomcat10-websocket-api.jar \
    /usr/share/java/tomcat10-websocket-api-10.1.16.jar \
    /usr/share/java/jakarta.websocket-api.jar ; do
    [ -f "$cand" ] && WS_API="$cand" && break
  done
fi
[ -n "$WS_API" ] || { echo "ERROR: Jakarta WebSocket API jar not found. Set WS_API=/path/to/jar"; exit 1; }
# Some distros split the base jakarta.websocket.* classes into a separate client-api jar; include it if present.
WS_CP="$WS_API"
for c in "${CATALINA_HOME:-/opt/tomcat}/lib/websocket-client-api.jar" \
         /usr/share/java/tomcat10-websocket-client-api.jar \
         /usr/share/java/tomcat10-websocket-client-api-10.1.16.jar ; do
  [ -f "$c" ] && WS_CP="$WS_CP:$c" && break
done
echo "Using WebSocket API: $WS_CP"

rm -rf "$OUT"
mkdir -p "$CLASSES"
find "$SRC" -name '*.java' > "$OUT/sources.txt"
javac --release 17 -classpath "$SERVLET_API:$WS_CP" -d "$CLASSES" @"$OUT/sources.txt"

WARROOT="$OUT/war"
mkdir -p "$WARROOT/WEB-INF/classes"
cp -r "$WEB"/. "$WARROOT"/
cp -r "$CLASSES"/. "$WARROOT/WEB-INF/classes"/
( cd "$WARROOT" && jar -cf "$OUT/quirkle.war" . )
echo "Built: $OUT/quirkle.war"
